declare const Il2Cpp: any;
declare const console: any;
declare const XRNode: any;

const getIl2Cpp = () => typeof Il2Cpp !== "undefined"
    ? Il2Cpp
    : (globalThis as any).Il2Cpp;
const Il2CppRef: any = getIl2Cpp() ?? ((globalThis as any).Il2Cpp = { $config: {} });
Il2CppRef.$config = Il2CppRef.$config ?? {};
Il2CppRef.$config.exports = {
    il2cpp_init: () => getIl2Cpp()?.module?.findExportByName("zmJRSNIqydu"),
    il2cpp_init_utf16: () => getIl2Cpp()?.module?.findExportByName("mZPaUxmODmO"),
    il2cpp_shutdown: () => getIl2Cpp()?.module?.findExportByName("nfjxkWtDquC"),
    il2cpp_set_config_dir: () => getIl2Cpp()?.module?.findExportByName("vdbUJfqM_os"),
    il2cpp_set_data_dir: () => getIl2Cpp()?.module?.findExportByName("aYOZGimxgRa"),
    il2cpp_set_temp_dir: () => getIl2Cpp()?.module?.findExportByName("uixaveuuLlh"),
    il2cpp_set_commandline_arguments: () => getIl2Cpp()?.module?.findExportByName("NNqsdVikLSi"),
    il2cpp_set_commandline_arguments_utf16: () => getIl2Cpp()?.module?.findExportByName("SLODayUosvy"),
    il2cpp_set_config_utf16: () => getIl2Cpp()?.module?.findExportByName("rGWBpmVLcFj"),
    il2cpp_set_config: () => getIl2Cpp()?.module?.findExportByName("RFdGJCqAOSU"),
    il2cpp_set_memory_callbacks: () => getIl2Cpp()?.module?.findExportByName("fydULZ_vSQe"),
    il2cpp_memory_pool_set_region_size: () => getIl2Cpp()?.module?.findExportByName("ZZmuIPzkLNE"),
    il2cpp_memory_pool_get_region_size: () => getIl2Cpp()?.module?.findExportByName("FlcwPZhEbjF"),
    il2cpp_get_corlib: () => getIl2Cpp()?.module?.findExportByName("seJcVBFUUEB"),
    il2cpp_add_internal_call: () => getIl2Cpp()?.module?.findExportByName("jmjYiVsewDX"),
    il2cpp_resolve_icall: () => getIl2Cpp()?.module?.findExportByName("dSqkkjkfHzZ"),
    il2cpp_alloc: () => getIl2Cpp()?.module?.findExportByName("wTrcJGCbLrG"),
    il2cpp_free: () => getIl2Cpp()?.module?.findExportByName("wACScOgFmSc"),
    il2cpp_array_class_get: () => getIl2Cpp()?.module?.findExportByName("DVVIpShClAu"),
    il2cpp_array_length: () => getIl2Cpp()?.module?.findExportByName("YzZsogBTiH_"),
    il2cpp_array_get_byte_length: () => getIl2Cpp()?.module?.findExportByName("EciVkcQLWte"),
    il2cpp_array_new: () => getIl2Cpp()?.module?.findExportByName("oHkTlhg_PBC"),
    il2cpp_array_new_specific: () => getIl2Cpp()?.module?.findExportByName("uBMlChOccWP"),
    il2cpp_array_new_full: () => getIl2Cpp()?.module?.findExportByName("cWAmtvLcOVk"),
    il2cpp_bounded_array_class_get: () => getIl2Cpp()?.module?.findExportByName("k_ZpXFXDBif"),
    il2cpp_array_element_size: () => getIl2Cpp()?.module?.findExportByName("eQwIQTYNABm"),
    il2cpp_assembly_get_image: () => getIl2Cpp()?.module?.findExportByName("WcWXQbYZWBD"),
    il2cpp_class_enum_basetype: () => getIl2Cpp()?.module?.findExportByName("VEmHKVoFrtM"),
    il2cpp_class_from_system_type: () => getIl2Cpp()?.module?.findExportByName("uMeWxvkkoef"),
    il2cpp_class_is_inited: () => getIl2Cpp()?.module?.findExportByName("fDywFSfETbx"),
    il2cpp_class_is_generic: () => getIl2Cpp()?.module?.findExportByName("FPALFCXcxDG"),
    il2cpp_class_is_inflated: () => getIl2Cpp()?.module?.findExportByName("uGKquuiYfAx"),
    il2cpp_class_is_assignable_from: () => getIl2Cpp()?.module?.findExportByName("RJHzVihJQKW"),
    il2cpp_class_is_subclass_of: () => getIl2Cpp()?.module?.findExportByName("CJivbAZqnNa"),
    il2cpp_class_has_parent: () => getIl2Cpp()?.module?.findExportByName("fPoOmUNUzkw"),
    il2cpp_class_from_il2cpp_type: () => getIl2Cpp()?.module?.findExportByName("YfACfNAQlvF"),
    il2cpp_class_from_name: () => getIl2Cpp()?.module?.findExportByName("URNGKmzxuzA"),
    il2cpp_class_get_element_class: () => getIl2Cpp()?.module?.findExportByName("nTNXyrIAoIz"),
    il2cpp_class_get_events: () => getIl2Cpp()?.module?.findExportByName("G_bfZebGryE"),
    il2cpp_class_get_fields: () => getIl2Cpp()?.module?.findExportByName("AUAuGDcVStQ"),
    il2cpp_class_get_nested_types: () => getIl2Cpp()?.module?.findExportByName("yrbOKgyrtFw"),
    il2cpp_class_get_interfaces: () => getIl2Cpp()?.module?.findExportByName("PohxfEudIQz"),
    il2cpp_class_get_properties: () => getIl2Cpp()?.module?.findExportByName("AjENpfUedxm"),
    il2cpp_class_get_property_from_name: () => getIl2Cpp()?.module?.findExportByName("IcX_JRyTQtO"),
    il2cpp_class_get_field_from_name: () => getIl2Cpp()?.module?.findExportByName("aLmiFybPDPt"),
    il2cpp_class_get_methods: () => getIl2Cpp()?.module?.findExportByName("KTVGmAkNlrq"),
    il2cpp_class_get_method_from_name: () => getIl2Cpp()?.module?.findExportByName("uVsjNObULDU"),
    il2cpp_class_get_name: () => getIl2Cpp()?.module?.findExportByName("XySzOpdIIlh"),
    il2cpp_class_get_namespace: () => getIl2Cpp()?.module?.findExportByName("xNhsyPmlAke"),
    il2cpp_class_get_parent: () => getIl2Cpp()?.module?.findExportByName("Nc_VUFZFdJb"),
    il2cpp_class_get_declaring_type: () => getIl2Cpp()?.module?.findExportByName("dUDeQpcZjoK"),
    il2cpp_class_instance_size: () => getIl2Cpp()?.module?.findExportByName("pnaPiIEphPs"),
    il2cpp_class_num_fields: () => getIl2Cpp()?.module?.findExportByName("VkTKVIqGDAq"),
    il2cpp_class_is_valuetype: () => getIl2Cpp()?.module?.findExportByName("XHPLZDTYoGA"),
    il2cpp_class_is_blittable: () => getIl2Cpp()?.module?.findExportByName("_cgofePnOJD"),
    il2cpp_class_value_size: () => getIl2Cpp()?.module?.findExportByName("OcdOsRgGych"),
    il2cpp_class_get_flags: () => getIl2Cpp()?.module?.findExportByName("IrxuGPrUhpj"),
    il2cpp_class_is_abstract: () => getIl2Cpp()?.module?.findExportByName("eMHJ_WQDksF"),
    il2cpp_class_is_interface: () => getIl2Cpp()?.module?.findExportByName("PPYEKIMGdbL"),
    il2cpp_class_array_element_size: () => getIl2Cpp()?.module?.findExportByName("QBVQpgkkYAb"),
    il2cpp_class_from_type: () => getIl2Cpp()?.module?.findExportByName("ixrkZVESEwh"),
    il2cpp_class_get_type: () => getIl2Cpp()?.module?.findExportByName("uOxRuBrzFuV"),
    il2cpp_class_get_type_token: () => getIl2Cpp()?.module?.findExportByName("WxglnkEAcOk"),
    il2cpp_class_has_attribute: () => getIl2Cpp()?.module?.findExportByName("PJSp_CjyGgS"),
    il2cpp_class_has_references: () => getIl2Cpp()?.module?.findExportByName("nazuXbpnfAQ"),
    il2cpp_class_is_enum: () => getIl2Cpp()?.module?.findExportByName("rnDDqfJNfUE"),
    il2cpp_class_get_image: () => getIl2Cpp()?.module?.findExportByName("JxYkxqJAwOj"),
    il2cpp_class_get_assemblyname: () => getIl2Cpp()?.module?.findExportByName("KFjJZFvpmJC"),
    il2cpp_class_get_rank: () => getIl2Cpp()?.module?.findExportByName("vzEcUrXKxkt"),
    il2cpp_class_get_data_size: () => getIl2Cpp()?.module?.findExportByName("_nVcknqtcZi"),
    il2cpp_class_get_static_field_data: () => getIl2Cpp()?.module?.findExportByName("LMgDQJUStSl"),
    il2cpp_stats_dump_to_file: () => getIl2Cpp()?.module?.findExportByName("YJZNTixpxXa"),
    il2cpp_stats_get_value: () => getIl2Cpp()?.module?.findExportByName("xCHVLXZyFXI"),
    il2cpp_domain_get: () => getIl2Cpp()?.module?.findExportByName("zgqjZEiDlIQ"),
    il2cpp_domain_assembly_open: () => getIl2Cpp()?.module?.findExportByName("guGEVfBRnSO"),
    il2cpp_domain_get_assemblies: () => getIl2Cpp()?.module?.findExportByName("IJhlNjITioN"),
    il2cpp_raise_exception: () => getIl2Cpp()?.module?.findExportByName("UnaIsFLRjlX"),
    il2cpp_exception_from_name_msg: () => getIl2Cpp()?.module?.findExportByName("SCJVCJemWwc"),
    il2cpp_get_exception_argument_null: () => getIl2Cpp()?.module?.findExportByName("EFcnngivJaL"),
    il2cpp_format_exception: () => getIl2Cpp()?.module?.findExportByName("IMpiBGqawkh"),
    il2cpp_format_stack_trace: () => getIl2Cpp()?.module?.findExportByName("gUTgRmJRsyr"),
    il2cpp_unhandled_exception: () => getIl2Cpp()?.module?.findExportByName("DWbgYZRWZHt"),
    il2cpp_native_stack_trace: () => getIl2Cpp()?.module?.findExportByName("eXO_aiJNjpZ"),
    il2cpp_field_get_name: () => getIl2Cpp()?.module?.findExportByName("gQgofaYsQqq"),
    il2cpp_field_get_flags: () => getIl2Cpp()?.module?.findExportByName("bHtzhUm_yqq"),
    il2cpp_field_get_from_reflection: () => getIl2Cpp()?.module?.findExportByName("DlRHeZyHcXr"),
    il2cpp_field_get_parent: () => getIl2Cpp()?.module?.findExportByName("kkqDMLswfJe"),
    il2cpp_field_get_object: () => getIl2Cpp()?.module?.findExportByName("EDhwDtvYjNr"),
    il2cpp_field_get_offset: () => getIl2Cpp()?.module?.findExportByName("TrdGEEtQPiQ"),
    il2cpp_field_get_type: () => getIl2Cpp()?.module?.findExportByName("VlysKayecLq"),
    il2cpp_field_get_value: () => getIl2Cpp()?.module?.findExportByName("IYHNOteDfWd"),
    il2cpp_field_get_value_object: () => getIl2Cpp()?.module?.findExportByName("biznbmkhCBv"),
    il2cpp_field_has_attribute: () => getIl2Cpp()?.module?.findExportByName("njXqwUOBIUJ"),
    il2cpp_field_set_value: () => getIl2Cpp()?.module?.findExportByName("ciyZmxlToRx"),
    il2cpp_field_set_value_object: () => getIl2Cpp()?.module?.findExportByName("BNAcRHkeVSN"),
    il2cpp_field_static_get_value: () => getIl2Cpp()?.module?.findExportByName("LKYPGqigDlv"),
    il2cpp_field_static_set_value: () => getIl2Cpp()?.module?.findExportByName("ilAfNURlInf"),
    il2cpp_field_is_literal: () => getIl2Cpp()?.module?.findExportByName("ojKcvkkOkIR"),
    il2cpp_gc_collect: () => getIl2Cpp()?.module?.findExportByName("RTPFBMSYCdJ"),
    il2cpp_gc_collect_a_little: () => getIl2Cpp()?.module?.findExportByName("hvXqsWCbpbf"),
    il2cpp_gc_start_incremental_collection: () => getIl2Cpp()?.module?.findExportByName("BHBqkhp_nhw"),
    il2cpp_gc_enable: () => getIl2Cpp()?.module?.findExportByName("WpHQNjAeLWD"),
    il2cpp_gc_disable: () => getIl2Cpp()?.module?.findExportByName("eMwFXRiusj_"),
    il2cpp_gc_is_disabled: () => getIl2Cpp()?.module?.findExportByName("ERLvmSYiWMz"),
    il2cpp_gc_set_mode: () => getIl2Cpp()?.module?.findExportByName("hurwZJJaCoq"),
    il2cpp_gc_is_incremental: () => getIl2Cpp()?.module?.findExportByName("htulajhhfQR"),
    il2cpp_gc_get_max_time_slice_ns: () => getIl2Cpp()?.module?.findExportByName("yLeWZmtIeuv"),
    il2cpp_gc_set_max_time_slice_ns: () => getIl2Cpp()?.module?.findExportByName("fkhLjbPQLgS"),
    il2cpp_gc_get_used_size: () => getIl2Cpp()?.module?.findExportByName("OAsQ_NoukPa"),
    il2cpp_gc_get_heap_size: () => getIl2Cpp()?.module?.findExportByName("PSqzwlONuMj"),
    il2cpp_gc_foreach_heap: () => getIl2Cpp()?.module?.findExportByName("XMnhTDdvVXZ"),
    il2cpp_stop_gc_world: () => getIl2Cpp()?.module?.findExportByName("BsxVGTWjyFv"),
    il2cpp_start_gc_world: () => getIl2Cpp()?.module?.findExportByName("NLYNidDJGji"),
    il2cpp_gc_alloc_fixed: () => getIl2Cpp()?.module?.findExportByName("nWjDl_kgyxW"),
    il2cpp_gc_free_fixed: () => getIl2Cpp()?.module?.findExportByName("NQkhJpoSCvg"),
    il2cpp_gchandle_new: () => getIl2Cpp()?.module?.findExportByName("cGSHwRVBXLb"),
    il2cpp_gchandle_new_weakref: () => getIl2Cpp()?.module?.findExportByName("QeBeQzJOcBW"),
    il2cpp_gchandle_get_target: () => getIl2Cpp()?.module?.findExportByName("OaGleysgcTQ"),
    il2cpp_gchandle_foreach_get_target: () => getIl2Cpp()?.module?.findExportByName("Hrzn_PgrqfB"),
    il2cpp_gc_wbarrier_set_field: () => getIl2Cpp()?.module?.findExportByName("ZRJmVvYuupT"),
    il2cpp_gc_has_strict_wbarriers: () => getIl2Cpp()?.module?.findExportByName("iagwGBZotNf"),
    il2cpp_gc_set_external_allocation_tracker: () => getIl2Cpp()?.module?.findExportByName("XHJZCzpDcUF"),
    il2cpp_gc_set_external_wbarrier_tracker: () => getIl2Cpp()?.module?.findExportByName("QbcMXGjseQO"),
    il2cpp_gchandle_free: () => getIl2Cpp()?.module?.findExportByName("RDKRijdFUoV"),
    il2cpp_object_header_size: () => getIl2Cpp()?.module?.findExportByName("AWvDqmNIcOZ"),
    il2cpp_array_object_header_size: () => getIl2Cpp()?.module?.findExportByName("PATqbTpovpv"),
    il2cpp_offset_of_array_length_in_array_object_header: () => getIl2Cpp()?.module?.findExportByName("XzAewhdbghA"),
    il2cpp_offset_of_array_bounds_in_array_object_header: () => getIl2Cpp()?.module?.findExportByName("DOYtFhJtfIE"),
    il2cpp_allocation_granularity: () => getIl2Cpp()?.module?.findExportByName("DxqsVZmgFfA"),
    il2cpp_unity_liveness_allocate_struct: () => getIl2Cpp()?.module?.findExportByName("QWuweScJJlx"),
    il2cpp_unity_liveness_calculation_from_root: () => getIl2Cpp()?.module?.findExportByName("XXmAXtiBsoq"),
    il2cpp_unity_liveness_calculation_from_statics: () => getIl2Cpp()?.module?.findExportByName("ks_XilNgBCE"),
    il2cpp_unity_liveness_finalize: () => getIl2Cpp()?.module?.findExportByName("edNXZkMyvnc"),
    il2cpp_unity_liveness_free_struct: () => getIl2Cpp()?.module?.findExportByName("zoWgq_Czecz"),
    il2cpp_method_get_return_type: () => getIl2Cpp()?.module?.findExportByName("gPDlvWmtlYk"),
    il2cpp_method_get_from_reflection: () => getIl2Cpp()?.module?.findExportByName("qPQJdDTIMJV"),
    il2cpp_method_get_object: () => getIl2Cpp()?.module?.findExportByName("iYADDjQYEHm"),
    il2cpp_method_get_name: () => getIl2Cpp()?.module?.findExportByName("pyfZOnnmKyE"),
    il2cpp_method_is_generic: () => getIl2Cpp()?.module?.findExportByName("cgzvJCxNQBV"),
    il2cpp_method_is_inflated: () => getIl2Cpp()?.module?.findExportByName("fJwBZgbgsWM"),
    il2cpp_method_is_instance: () => getIl2Cpp()?.module?.findExportByName("lbZAjoLkKBQ"),
    il2cpp_method_get_param_count: () => getIl2Cpp()?.module?.findExportByName("yfrdsOEAtYd"),
    il2cpp_method_get_param: () => getIl2Cpp()?.module?.findExportByName("CcoGOcaraYc"),
    il2cpp_method_get_class: () => getIl2Cpp()?.module?.findExportByName("HTbthVDmZaa"),
    il2cpp_method_has_attribute: () => getIl2Cpp()?.module?.findExportByName("DCptdkt_fJA"),
    il2cpp_method_get_declaring_type: () => getIl2Cpp()?.module?.findExportByName("wDzakXByEDy"),
    il2cpp_method_get_flags: () => getIl2Cpp()?.module?.findExportByName("pIqquNcMutY"),
    il2cpp_method_get_token: () => getIl2Cpp()?.module?.findExportByName("RUCPvbTOyri"),
    il2cpp_method_get_param_name: () => getIl2Cpp()?.module?.findExportByName("McaIBXdwMwX"),
    il2cpp_profiler_install: () => getIl2Cpp()?.module?.findExportByName("yxcZNiLSqmN"),
    il2cpp_profiler_set_events: () => getIl2Cpp()?.module?.findExportByName("vdPYgXeZVwi"),
    il2cpp_profiler_install_enter_leave: () => getIl2Cpp()?.module?.findExportByName("kdiLdPtzthE"),
    il2cpp_profiler_install_allocation: () => getIl2Cpp()?.module?.findExportByName("LcvSjtGv_oL"),
    il2cpp_profiler_install_gc: () => getIl2Cpp()?.module?.findExportByName("dcnvjxCZFgY"),
    il2cpp_profiler_install_fileio: () => getIl2Cpp()?.module?.findExportByName("dLZBtmDCIQT"),
    il2cpp_profiler_install_thread: () => getIl2Cpp()?.module?.findExportByName("GlDCwllonOF"),
    il2cpp_property_get_name: () => getIl2Cpp()?.module?.findExportByName("YVRvnCBTvsM"),
    il2cpp_property_get_get_method: () => getIl2Cpp()?.module?.findExportByName("oWwVjAeaukm"),
    il2cpp_property_get_set_method: () => getIl2Cpp()?.module?.findExportByName("brYUGKLPUyY"),
    il2cpp_property_get_parent: () => getIl2Cpp()?.module?.findExportByName("GSmEjlQxWvG"),
    il2cpp_property_get_flags: () => getIl2Cpp()?.module?.findExportByName("HbPEKOxVjPm"),
    il2cpp_object_get_class: () => getIl2Cpp()?.module?.findExportByName("orFCiWejtKL"),
    il2cpp_object_get_size: () => getIl2Cpp()?.module?.findExportByName("nyZRIxVloGy"),
    il2cpp_object_get_virtual_method: () => getIl2Cpp()?.module?.findExportByName("Dm_LEcJiOQq"),
    il2cpp_object_new: () => getIl2Cpp()?.module?.findExportByName("vIbLVqyrZTt"),
    il2cpp_object_unbox: () => getIl2Cpp()?.module?.findExportByName("uElUHSHcugP"),
    il2cpp_value_box: () => getIl2Cpp()?.module?.findExportByName("jKXJKEUOgqM"),
    il2cpp_monitor_enter: () => getIl2Cpp()?.module?.findExportByName("pdA_vYrEIrb"),
    il2cpp_monitor_try_enter: () => getIl2Cpp()?.module?.findExportByName("pOoUPZWPqtG"),
    il2cpp_monitor_exit: () => getIl2Cpp()?.module?.findExportByName("BnPsPfYauoz"),
    il2cpp_monitor_pulse: () => getIl2Cpp()?.module?.findExportByName("_kSsMDeuNkD"),
    il2cpp_monitor_pulse_all: () => getIl2Cpp()?.module?.findExportByName("wVKMLSYVgTR"),
    il2cpp_monitor_wait: () => getIl2Cpp()?.module?.findExportByName("iLDwFQuyKhl"),
    il2cpp_monitor_try_wait: () => getIl2Cpp()?.module?.findExportByName("huYoIwGRILl"),
    il2cpp_runtime_invoke_convert_args: () => getIl2Cpp()?.module?.findExportByName("lL_IRurovCx"),
    il2cpp_runtime_invoke: () => getIl2Cpp()?.module?.findExportByName("xmXBQiFbQcg"),
    il2cpp_runtime_class_init: () => getIl2Cpp()?.module?.findExportByName("mROutgCxURx"),
    il2cpp_runtime_object_init: () => getIl2Cpp()?.module?.findExportByName("wXwdViByZyR"),
    il2cpp_runtime_object_init_exception: () => getIl2Cpp()?.module?.findExportByName("tTiSbEGYVpw"),
    il2cpp_runtime_unhandled_exception_policy_set: () => getIl2Cpp()?.module?.findExportByName("VeD_EyoewcO"),
    il2cpp_string_length: () => getIl2Cpp()?.module?.findExportByName("ThpFHzNTOem"),
    il2cpp_string_chars: () => getIl2Cpp()?.module?.findExportByName("cRNRGFVpqJZ"),
    il2cpp_string_new: () => getIl2Cpp()?.module?.findExportByName("vYssBhSIagU"),
    il2cpp_string_new_wrapper: () => getIl2Cpp()?.module?.findExportByName("_yEHIPGAOym"),
    il2cpp_string_new_utf16: () => getIl2Cpp()?.module?.findExportByName("gddZWMRYVpx"),
    il2cpp_string_new_len: () => getIl2Cpp()?.module?.findExportByName("ZxNSCvfoUcc"),
    il2cpp_string_intern: () => getIl2Cpp()?.module?.findExportByName("aaXixSoRuCI"),
    il2cpp_string_is_interned: () => getIl2Cpp()?.module?.findExportByName("cRqwONZqabJ"),
    il2cpp_thread_current: () => getIl2Cpp()?.module?.findExportByName("RvwLojBseNF"),
    il2cpp_thread_attach: () => getIl2Cpp()?.module?.findExportByName("ZXVcFUQEOXs"),
    il2cpp_thread_detach: () => getIl2Cpp()?.module?.findExportByName("xZzOsVbPjVf"),
    il2cpp_is_vm_thread: () => getIl2Cpp()?.module?.findExportByName("pkrPLLsLhZT"),
    il2cpp_current_thread_walk_frame_stack: () => getIl2Cpp()?.module?.findExportByName("sZaeDSThMQU"),
    il2cpp_thread_walk_frame_stack: () => getIl2Cpp()?.module?.findExportByName("AnlvPRCPjHY"),
    il2cpp_current_thread_get_top_frame: () => getIl2Cpp()?.module?.findExportByName("uCyRopHuENp"),
    il2cpp_thread_get_top_frame: () => getIl2Cpp()?.module?.findExportByName("DvjP_JDwE_O"),
    il2cpp_current_thread_get_frame_at: () => getIl2Cpp()?.module?.findExportByName("qHXIWUpmdsY"),
    il2cpp_thread_get_frame_at: () => getIl2Cpp()?.module?.findExportByName("jBesDe_RYQE"),
    il2cpp_current_thread_get_stack_depth: () => getIl2Cpp()?.module?.findExportByName("ARxELfhkozN"),
    il2cpp_thread_get_stack_depth: () => getIl2Cpp()?.module?.findExportByName("xuWcnWvGJyJ"),
    il2cpp_set_default_thread_affinity: () => getIl2Cpp()?.module?.findExportByName("XVclllTroqE"),
    il2cpp_override_stack_backtrace: () => getIl2Cpp()?.module?.findExportByName("ZnWH_YkGjKb"),
    il2cpp_type_get_object: () => getIl2Cpp()?.module?.findExportByName("COhULSlaKBW"),
    il2cpp_type_get_type: () => getIl2Cpp()?.module?.findExportByName("xJFntDgRFnR"),
    il2cpp_type_get_class_or_element_class: () => getIl2Cpp()?.module?.findExportByName("nhJjsfZarcF"),
    il2cpp_type_get_name: () => getIl2Cpp()?.module?.findExportByName("kxNe_rjjhEs"),
    il2cpp_type_get_assembly_qualified_name: () => getIl2Cpp()?.module?.findExportByName("aSMTjMILzGt"),
    il2cpp_type_get_reflection_name: () => getIl2Cpp()?.module?.findExportByName("WghGgpTKPPi"),
    il2cpp_type_is_byref: () => getIl2Cpp()?.module?.findExportByName("qpgsrzLZtIY"),
    il2cpp_type_get_attrs: () => getIl2Cpp()?.module?.findExportByName("MMlCAaZHAvu"),
    il2cpp_type_equals: () => getIl2Cpp()?.module?.findExportByName("hgvWJURXCDE"),
    il2cpp_type_is_static: () => getIl2Cpp()?.module?.findExportByName("wsCSTXLdEXb"),
    il2cpp_type_is_pointer_type: () => getIl2Cpp()?.module?.findExportByName("avPW_qXtOHk"),
    il2cpp_image_get_assembly: () => getIl2Cpp()?.module?.findExportByName("sJPUKxShxVg"),
    il2cpp_image_get_name: () => getIl2Cpp()?.module?.findExportByName("r_fLi_lbrrF"),
    il2cpp_image_get_filename: () => getIl2Cpp()?.module?.findExportByName("cDsYkfreuzk"),
    il2cpp_image_get_entry_point: () => getIl2Cpp()?.module?.findExportByName("ggMrPRFdkSW"),
    il2cpp_image_get_class_count: () => getIl2Cpp()?.module?.findExportByName("oYJAzdivHzH"),
    il2cpp_image_get_class: () => getIl2Cpp()?.module?.findExportByName("TFkDjcCuDgD"),
    il2cpp_capture_memory_snapshot: () => getIl2Cpp()?.module?.findExportByName("jdsdZ_xnUDB"),
    il2cpp_free_captured_memory_snapshot: () => getIl2Cpp()?.module?.findExportByName("eJmykNRuvwu"),
    il2cpp_set_find_plugin_callback: () => getIl2Cpp()?.module?.findExportByName("ZcBDoZptQDt"),
    il2cpp_register_log_callback: () => getIl2Cpp()?.module?.findExportByName("FmhMFEOMGkz"),
    il2cpp_debugger_set_agent_options: () => getIl2Cpp()?.module?.findExportByName("mWM_pwuJFlf"),
    il2cpp_is_debugger_attached: () => getIl2Cpp()?.module?.findExportByName("QkHmIsLPBxQ"),
    il2cpp_register_debugger_agent_transport: () => getIl2Cpp()?.module?.findExportByName("UdiKgeDqgPP"),
    il2cpp_debug_foreach_method: () => getIl2Cpp()?.module?.findExportByName("mbFXaZcuSju"),
    il2cpp_debug_get_method_info: () => getIl2Cpp()?.module?.findExportByName("kBgoEDRhHqG"),
    il2cpp_unity_install_unitytls_interface: () => getIl2Cpp()?.module?.findExportByName("vnnTPtyEGxZ"),
    il2cpp_custom_attrs_from_class: () => getIl2Cpp()?.module?.findExportByName("CQMVMPIweXx"),
    il2cpp_custom_attrs_from_method: () => getIl2Cpp()?.module?.findExportByName("CFlYUeuhppU"),
    il2cpp_custom_attrs_from_field: () => getIl2Cpp()?.module?.findExportByName("fBRSuqPORuN"),
    il2cpp_custom_attrs_has_attr: () => getIl2Cpp()?.module?.findExportByName("QDnvRVpI__b"),
    il2cpp_custom_attrs_get_attr: () => getIl2Cpp()?.module?.findExportByName("jVkWKBPzGjF"),
    il2cpp_custom_attrs_construct: () => getIl2Cpp()?.module?.findExportByName("FHCkRFKGbOf"),
    il2cpp_custom_attrs_free: () => getIl2Cpp()?.module?.findExportByName("DDLOrnbLXKn"),
    il2cpp_type_get_name_chunked: () => getIl2Cpp()?.module?.findExportByName("xPzDXdzDjyk"),
    il2cpp_class_set_userdata: () => getIl2Cpp()?.module?.findExportByName("qRXkmRqzbEU"),
    il2cpp_class_get_userdata_offset: () => getIl2Cpp()?.module?.findExportByName("TPRfOsD_NDy"),
    il2cpp_class_for_each: () => getIl2Cpp()?.module?.findExportByName("AWYQ__tAXfW"),
    il2cpp_unity_set_android_network_up_state_func: () => getIl2Cpp()?.module?.findExportByName("PwCWWkwGBrv"),
};

function normalizePlayerToken(value: any): string {
    try {
        if (value == null) return "";
        if (typeof value === "string") return value.trim();
        if (typeof value === "number" || typeof value === "boolean") return String(value).trim();
        if (value.content != null) return String(value.content).trim();
        return String(value).trim();
    } catch(_) {
        return "";
    }
}
function normalizeWhitelistToken(value: any): string {
    return normalizePlayerToken(value).toLowerCase();
}
const _errorLog: { time: number; tag: string; msg: string; fix: string }[] = [];
let   _errorLogEnabled = true;

function diagnoseError(tag: string, err: any): string {
    const msg: string = (err && err.message) ? err.message : String(err);

    // ── couldn't find class ─────────────────────────────────────────────
    const classMatch = msg.match(/couldn't find (?:non-static )?(?:class|type) ([^\s]+)/i)
                    ?? msg.match(/class ([^\s]+) not found/i);
    if (classMatch) {
        const cls = classMatch[1];
        return (
            `CLASS NOT FOUND: "${cls}"\n` +
            `  → The game removed or renamed this class in the current build.\n` +
            `  → Open the dump and search for "${cls.split(".").pop()}" to find the new name.\n` +
            `  → If it's gone entirely, wrap the call in: if (YourClass) { ... }`
        );
    }


}

function getPlayerIdentityInfo(p: any): { key: string, label: string, aliases: string[] } {
    const aliases: string[] = [];
    const JUNK = new Set([
        "netplayer","animalcompany.netplayer","player","(null)","null","none",
        "unknown","","local player","localplayer","true","false","0","1","-1"
    ]);
    const isJunk = (s: string) =>
        !s || /^\?+$/.test(s) || JUNK.has(s.toLowerCase()) || /^AnimalCompany\./i.test(s);

    const pushAlias = (value: any) => {
        const token = normalizePlayerToken(value);
        if (isJunk(token) || aliases.includes(token)) return;
        aliases.push(token);
    };

    // ── 1. scan EVERY field on the object ─────────────────────────────
    // Quest/Oculus stores the name in a Fusion networked field —
    // we don't know the exact name so we read them all and filter
    try {
        for (const field of (p.class?.fields ?? [])) {
            try {
                const raw = p.field(field.name).value;
                if (raw == null) continue;
                // skip booleans and numbers entirely
                if (typeof raw === "boolean" || typeof raw === "number") continue;
                if (typeof raw === "object" && raw.content == null) continue;
                const token = normalizePlayerToken(raw);
                if (!token || token.length < 2 || token.length > 64) continue;
                if (isJunk(token)) continue;
                if (/^\d+$/.test(token)) continue; // pure numbers → id, not name
                if (/^(true|false)$/i.test(token)) continue; // booleans as strings
                pushAlias(token);
            } catch(_) {}
        }
    } catch(_) {}

    // ── 2. known networked name field patterns as priority ─────────────
    for (const f of [
        "_n_playerName","n_playerName","playerName","_playerName",
        "_n_oculusName","n_oculusName","oculusName","_oculusName",
        "_n_userName","n_userName","userName","_userName",
        "_n_nickName","n_nickName","nickName","_nickName",
        "_n_displayName","n_displayName","_displayName","displayName"
    ]) {
        try {
            const raw = p.field(f).value;
            const token = normalizePlayerToken(raw);
            if (!isJunk(token) && !aliases.includes(token)) {
                aliases.unshift(token); // push to front — highest priority
            }
        } catch(_) {}
    }

    // ── 3. property getters ───────────────────────────────────────────
    for (const m of [
        "get_PlayerName","get_playerName","get_OculusName","get_oculusName",
        "get_UserName","get_userName","get_NickName","get_DisplayName","get_displayName"
    ]) {
        try { pushAlias(p.method(m).invoke()); } catch(_) {}
    }

    // ── 4. Oculus Platform: resolve userId → display name ─────────────
    try {
        const OculusPlatformImage = Il2Cpp.domain.assembly("Oculus.Platform").image;
        const UsersClass = OculusPlatformImage.class("Oculus.Platform.Users");
        // get the userId from the player
        let uid: any = null;
        for (const f of ["_userId","_userID","_accountId","_oculusId","_n_userId"]) {
            try { uid = p.field(f).value; if (uid) break; } catch(_) {}
        }
        if (!uid) try { uid = p.method("get_userId").invoke(); } catch(_) {}
        if (!uid) try { uid = p.method("GetUserIDAndRegister").invoke(); } catch(_) {}
        if (uid) {
            const uidStr = String(uid);
            // check our local name cache first
            const cached = _oculusNameCache.get(uidStr);
            if (cached) {
                pushAlias(cached);
            } else {
                // fire async request — result comes back later and populates cache
                try {
                    const req = UsersClass.method("Get", 1).invoke(uid);
                    if (req && !req.isNull?.()) {
                        // Oculus Message callback
                        const OculusCore = OculusPlatformImage.class("Oculus.Platform.Core");
                        OculusCore.method("OnUpdate").invoke();
                    }
                } catch(_) {}
                // also try GetLoggedInUser style cache class
                try {
                    const cacheClass = Il2Cpp.domain.assembly("AnimalCompany").image
                        .class("AnimalCompany.OculusUserCache");
                    const nameFromCache = cacheClass.method("GetName", 1).invoke(uid);
                    const n = normalizePlayerToken(nameFromCache);
                    if (n && !isJunk(n)) { _oculusNameCache.set(uidStr, n); pushAlias(n); }
                } catch(_) {}
            }
        }
    } catch(_) {}

    // ── 5. playerId as fallback id ─────────────────────────────────────
    try { pushAlias(p.method("get_playerId").invoke()); } catch(_) {}
    try { pushAlias(p.field("_playerId").value); } catch(_) {}

    // deduplicate keeping order
    const seen = new Set<string>();
    const deduped = aliases.filter(a => { if (seen.has(a)) return false; seen.add(a); return true; });

    // score each candidate — higher = more name-like
    const scoreAlias = (a: string): number => {
        let s = 0;
        if (a.length >= 3 && a.length <= 24)   s += 10;  // name-length range
        if (/[A-Z]/.test(a))                    s += 5;   // has uppercase → display name
        if (/\s/.test(a))                        s += 4;   // has space → probably a real name
        if (/[_\-]/.test(a))                     s += 2;   // underscore/dash → username style
        if (/^\d{8,}$/.test(a))                  s -= 20;  // pure long number → ID
        if (/^[0-9a-f]{10,}$/i.test(a))          s -= 15;  // hex string → ID
        if (a.length > 24)                       s -= 8;   // too long → probably ID
        if (/^[a-z0-9]{16,}$/.test(a))           s -= 12;  // long lowercase alphanum → oculus ID
        return s;
    };

    const bestLabel = [...deduped].sort((a, b) => scoreAlias(b) - scoreAlias(a))[0] ?? "?";
    return { key: deduped[0] ?? "?", label: bestLabel, aliases: deduped.length > 0 ? deduped : ["?"] };
}

function getPlayerName(p: any): string {
    return getPlayerIdentityInfo(p).label;
}

function whitelistHasPlayer(p: any): boolean {
    try {
        const info = getPlayerIdentityInfo(p);
        return info.aliases.some(alias => whitelist.includes(normalizeWhitelistToken(alias)));
    } catch(_) {
        return false;
    }
}

function normalizeSceneObjectHandle(obj: any): string {
    try {
        if (!obj || obj.isNull?.()) return "";
        const handle = obj.handle;
        if (!handle) return "";
        return handle.toString();
    } catch(_) {
        return "";
    }
}

function whitelistAddPlayer(p: any): string {
    const info = getPlayerIdentityInfo(p);
    for (const alias of info.aliases) {
        const token = normalizeWhitelistToken(alias);
        if (token && !whitelist.includes(token)) whitelist.push(token);
    }
    return info.label;
}

function whitelistRemovePlayer(p: any): string {
    const info = getPlayerIdentityInfo(p);
    const removeSet = info.aliases.map(alias => normalizeWhitelistToken(alias));
    whitelist = whitelist.filter(entry => !removeSet.includes(normalizeWhitelistToken(entry)));
    return info.label;
}

let uxSelectedObject: any = null;   
let uxSelectedName: string = "none";

let freecamActive: boolean = false;
let freecamObj: any = null;         
let freecamPos: any = null;         

function uxGetTransform(go: any): any {
    try { return go.method("get_transform").invoke(); } catch(_) { return null; }
}

function uxVec3Str(v: any): string {
    try {
        const x = (v.field("x").value as number).toFixed(3);
        const y = (v.field("y").value as number).toFixed(3);
        const z = (v.field("z").value as number).toFixed(3);
        return `(${x}, ${y}, ${z})`;
    } catch(_) { return "(?,?,?)"; }
}

  



function smartError(tag: string, err: any): void {
    if (!_errorLogEnabled) { console.error(`[${tag}]`, err); return; }

    const fix  = diagnoseError(tag, err);
    const msg  = (err && err.message) ? err.message : String(err);
    const time = Date.now();

    _errorLog.push({ time, tag, msg, fix });

    // Always print to Frida log
    console.error(
        `\n╔═ ERROR [${tag}] ════════════════════════════════════\n` +
        `║  ${msg}\n` +
        `╠═ HOW TO FIX ═══════════════════════════════════════\n` +
        `║  ${fix.replace(/\n/g, "\n║  ")}\n` +
        `╚════════════════════════════════════════════════════`
    );
}

function uxGetComponentNames(go: any): string[] {
    const names: string[] = [];
    try {
        const comps = go.method("GetComponentsInChildren", 1)
            .inflate(Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Component"))
            .invoke(false);
        if (!comps || comps.isNull()) return names;
        const len = comps.length;
        for (let i = 0; i < Math.min(len, 64); i++) {
            try {
                const c = comps.method("get_Item").invoke(i);
                const typeName = c.method("GetType").invoke().method("get_Name").invoke()?.content ?? "?";
                names.push(typeName);
            } catch(_) {}
        }
    } catch(_) {}
    return names;
}
const itemIDs = [
    "item_ac_cola",
    "item_pelican_case",
    "item_rpg",
    "item_alphablade",
    "item_anti_gravity_grenade",
    "item_arena_pistol",
    "item_arena_shotgun",
    "item_arrow",
    "item_arrow_bomb",
    "item_arrow_heart",
    "item_arrow_lightbulb",
    "item_arrow_teleport",
    "item_axe",
    "item_backpack",
    "item_backpack_black",
    "item_backpack_green",
    "item_backpack_large_base",
    "item_backpack_large_basketball",
    "item_backpack_large_clover",
    "item_backpack_pink",
    "item_backpack_realistic",
    "item_backpack_small_base",
    "item_backpack_white",
    "item_backpack_with_flashlight",
    "item_bait_beetle",
    "item_bait_fly",
    "item_bait_glowworm",
    "item_bait_magmar_ball",
    "item_bait_mouse_trap",
    "item_bait_sardine",
    "item_bait_shell",
    "item_bait_starfish",
    "item_bait_wallet",
    "item_balloon",
    "item_balloon_heart",
    "item_bamboo_fishing_rod",
    "item_banana",
    "item_banana_chips",
    "item_baseball_bat",
    "item_basic_fishing_rod",
    "item_beans",
    "item_big_cup",
    "item_bighead_larva",
    "item_bloodlust_vial",
    "item_boombox",
    "item_boombox_fishing",
    "item_boombox_neon",
    "item_boomerang",
    "item_box_fan",
    "item_brain_chunk",
    "item_broccoli_grenade",
    "item_broccoli_shrink_grenade",
    "item_broom",
    "item_broom_halloween",
    "item_bubble_gun",
    "item_burrito",
    "item_butcherpipe",
    "item_butcherspear",
    "item_butchersword",
    "item_calculator",
    "item_cardboard_box",
    "item_cardboard_dragon_body",
    "item_cardboard_dragon_head",
    "item_ceo_plaque",
    "item_chakra",
    "item_clapper",
    "item_cluster_grenade",
    "item_coconut_shell",
    "item_cola",
    "item_cola_large",
    "item_company_ration",
    "item_company_ration_heal",
    "item_cracker",
    "item_crate",
    "item_crossbow",
    "item_crossbow_heart",
    "item_crowbar",
    "item_cubetrident",
    "item_cutie_dead",
    "item_d20",
    "item_demon_sword",
    "item_disc",
    "item_disposable_camera",
    "item_dragons_claw",
    "item_drill",
    "item_drill_neon",
    "item_dynamite",
    "item_dynamite_cube",
    "item_egg",
    "item_electrical_tape",
    "item_eraser",
    "item_film_reel",
    "item_finger_board",
    "item_fish_boomfish",
    "item_fish_boot",
    "item_fish_bottled_message",
    "item_fish_carp",
    "item_fish_chewna",
    "item_fish_clam_hookshot",
    "item_fish_crappie",
    "item_fish_crispie",
    "item_fish_diamond_jade_koi",
    "item_fish_dollar_bill",
    "item_fish_dragonfish",
    "item_fish_fishsword",
    "item_fish_gold_fish",
    "item_fish_hydracarp",
    "item_fish_kissy",
    "item_fish_license_plate",
    "item_fish_magma_carp",
    "item_fish_nebula_fish",
    "item_fish_nutfish",
    "item_fish_rainbow_trout",
    "item_fish_rotten_fish",
    "item_fish_salmon",
    "item_fish_salmonster",
    "item_fish_scaldfish",
    "item_fish_seamine",
    "item_fish_shellfish_shield",
    "item_fish_spicy_salmon",
    "item_fish_tuna",
    "item_fish_yellowcake",
    "item_fishing_terminal_bait_button",
    "item_flamethrower",
    "item_flamethrower_skull",
    "item_flamethrower_skull_ruby",
    "item_flaregun",
    "item_flashbang",
    "item_flashlight",
    "item_flashlight_mega",
    "item_flashlight_red",
    "item_flipflop_realistic",
    "item_floppy3",
    "item_floppy5",
    "item_football",
    "item_friend_launcher",
    "item_frying_pan",
    "item_gameboy",
    "item_glowstick",
    "item_goldbar",
    "item_goldcoin",
    "item_goop",
    "item_goopfish",
    "item_great_sword",
    "item_grenade",
    "item_grenade_gold",
    "item_grenade_launcher",
    "item_guided_boomerang",
    "item_hammer_candy_cane",
    "item_harddrive",
    "item_hatchet",
    "item_hawaiian_drum",
    "item_heart_chunk",
    "item_heart_gun",
    "item_heartchocolatebox",
    "item_hh_key",
    "item_hookshot",
    "item_hookshot_sword",
    "item_hot_cocoa",
    "item_hoverpad",
    "item_impulse_grenade",
    "item_jetpack",
    "item_joystick",
    "item_joystick_inv_y",
    "item_keycard",
    "item_lance",
    "item_landmine",
    "item_landmine_bee",
    "item_lantern_cny",
    "item_large_banana",
    "item_lava_fishing_rod",
    "item_love_grenade",
    "item_megaphone",
    "item_metal_ball",
    "item_metal_ball_xmas",
    "item_metal_plate",
    "item_metal_plate_xmas",
    "item_metal_rod",
    "item_metal_rod_xmas",
    "item_metal_triangle",
    "item_momboss_box",
    "item_moneygun",
    "item_mountain_key",
    "item_mug",
    "item_needle",
    "item_nut",
    "item_nut_drop",
    "item_ogre_hands",
    "item_ore_copper_l",
    "item_ore_copper_m",
    "item_ore_copper_s",
    "item_ore_gold_l",
    "item_ore_gold_m",
    "item_ore_gold_s",
    "item_ore_hell",
    "item_ore_silver_l",
    "item_ore_silver_m",
    "item_ore_silver_s",
    "item_painting_canvas",
    "item_paperpack",
    "item_pickaxe",
    "item_pickaxe_cny",
    "item_pickaxe_cube",
    "item_pickaxe_realistic",
    "item_pinata_bat",
    "item_pineapple",
    "item_pipe",
    "item_pistol_dragon",
    "item_plank",
    "item_plunger",
    "item_pogostick",
    "item_police_baton",
    "item_popcorn",
    "item_portable_teleporter",
    "item_prop_scanner",
    "item_pumpkin_bomb",
    "item_pumpkin_pie",
    "item_pumpkinjack",
    "item_pumpkinjack_small",
    "item_quest_gy_skull",
    "item_quest_gy_skull_special",
    "item_quest_hlal_brain",
    "item_quest_hlal_eyeball",
    "item_quest_hlal_flesh",
    "item_quest_hlal_heart",
    "item_quest_key_graveyard",
    "item_quiver",
    "item_quiver_heart",
    "item_radiation_gun",
    "item_radioactive_broccoli",
    "item_radioactive_fishing_rod",
    "item_randombox_mobloot_big",
    "item_randombox_mobloot_medium",
    "item_randombox_mobloot_small",
    "item_randombox_mobloot_weapons",
    "item_randombox_mobloot_zombie",
    "item_rare_card",
    "item_remote_controller",
    "item_revolver",
    "item_revolver_ammo",
    "item_revolver_gold",
    "item_ring_buoy",
    "item_robo_monke",
    "item_robot_arm_left",
    "item_robot_arm_right",
    "item_robot_head",
    "item_rope",
    "item_rpg_ammo",
    "item_rpg_ammo_egg",
    "item_rpg_ammo_spear",
    "item_rpg_cny",
    "item_rpg_easter",
    "item_rpg_smshr",
    "item_rpg_spear",
    "item_rubberducky",
    "item_ruby",
    "item_saddle",
    "item_salmoncannon",
    "item_sawblade",
    "item_sawblade_launcher",
    "item_scanner",
    "item_scissors",
    "item_server_pad",
    "item_shield",
    "item_shield_bones",
    "item_shield_candy_cane",
    "item_shield_police",
    "item_shield_viking_1",
    "item_shield_viking_2",
    "item_shield_viking_3",
    "item_shield_viking_4",
    "item_shotgun",
    "item_shotgun_ammo",
    "item_shotgun_viper",
    "item_shovel",
    "item_shredder",
    "item_shrinking_broccoli",
    "item_skipole",
    "item_skishoe",
    "item_skishoe_2",
    "item_skishoe_3",
    "item_skishoe_4",
    "item_snail_friend",
    "item_snowball",
    "item_snowboard",
    "item_snowboard_2",
    "item_snowboard_3",
    "item_snowboard_4",
    "item_snowboard_auto",
    "item_spear_candy_cane",
    "item_special_fishing_rod",
    "item_special_fishing_rod_radar_part",
    "item_special_fishing_rod_with_radar",
    "item_stapler",
    "item_stash_grenade",
    "item_steel_beam",
    "item_steel_beam_xmas",
    "item_stellarsword_blue",
    "item_stellarsword_gold",
    "item_stick_armbones",
    "item_stick_bone",
    "item_sticker_dispenser",
    "item_sticky_dynamite",
    "item_stinky_cheese",
    "item_tablet",
    "item_tapedispenser",
    "item_tele_grenade",
    "item_tele_pearl",
    "item_teleport_gun",
    "item_theremin",
    "item_timebomb",
    "item_toilet_paper",
    "item_toilet_paper_mega",
    "item_toilet_paper_roll_empty",
    "item_token_circus",
    "item_trampoline",
    "item_treestick",
    "item_tripwire_explosive",
    "item_trophy",
    "item_truss",
    "item_truss_xmas",
    "item_turkey_leg",
    "item_turkey_whole",
    "item_ukulele",
    "item_ukulele_gold",
    "item_umbrella",
    "item_umbrella_clover",
    "item_umbrella_squirrel",
    "item_unidentified",
    "item_upsidedown_loot",
    "item_uranium_chunk_l",
    "item_uranium_chunk_m",
    "item_uranium_chunk_s",
    "item_viking_hammer",
    "item_viking_hammer_twilight",
    "item_war_fan",
    "item_wheelhandle",
    "item_wheelhandle_big",
    "item_whoopie",
    "item_wood_log",
    "item_wood_pallet",
    "item_wyrmpiercer",
    "item_zipline_gun",
    "item_zombie_meat"
];
const mobIDs: { name: string; id: number }[] = [
    { name: "Angler",              id: 1  },
    { name: "AnglerMad",           id: 2  },
    { name: "Armstrong",           id: 3  },
    { name: "ArmstrongMad",        id: 4  },
    { name: "Banshee",             id: 5  },
    { name: "Bomb",                id: 6  },
    { name: "Bomber",              id: 7  },
    { name: "BomberFlashbang",     id: 8  },
    { name: "BomberMad",           id: 9  },
    { name: "Chicken",             id: 10 },
    { name: "Cyst",                id: 11 },
    { name: "FakeGorilla",         id: 12 },
    { name: "BigHead",             id: 13 },
    { name: "RedGreen",            id: 14 },
    { name: "Phantom",             id: 15 },
    { name: "EvilEye",             id: 16 },
    { name: "GiantThrower",        id: 17 },
    { name: "RedGreenMad",         id: 18 },
    { name: "Spider",              id: 19 },
    { name: "FlyingSwarm",         id: 20 },
    { name: "NextBot",             id: 21 },
    { name: "Segway",              id: 22 },
    { name: "NextBotStatic",       id: 23 },
    { name: "EvilEyePinata",       id: 24 },
    { name: "EvilEyePinataLarge",  id: 25 },
    { name: "Lanky",               id: 26 },
    { name: "Blob",                id: 27 },
    { name: "Cutie",               id: 28 },
    { name: "SpiderCave",          id: 29 },
    { name: "ForestMob",           id: 30 },
    { name: "Mimic",               id: 31 },
    { name: "GraveyardBoss",       id: 32 },
    { name: "Ringmaster",          id: 33 },
    { name: "Puppet",              id: 34 },
    { name: "PolypMass",           id: 35 },
    { name: "RobotDog",            id: 36 },
    { name: "Shadow",              id: 37 },
    { name: "Heart",               id: 38 },
    { name: "Slimey",              id: 39 },
    { name: "ShadowBoss",          id: 40 },
    { name: "BigShark",            id: 41 },
    { name: "EdenZombie",          id: 42 },
    { name: "Skinwalker",          id: 43 },
    { name: "Smiley",              id: 47 },
];
const VFXTypes = {
    None: 255,
    MuzzleFlash_Shotgun: 0,
    MuzzleFlash_FlareGun: 1,
    CrateBreak: 2,
    MuzzleFlash_SmallGun: 3,
    MuzzleFlash_GoldRevolver: 4,
    MuzzleFlash_DragonPistol: 5,
    MuzzleFlash_ViperShotgun: 6,
    Explosion_FlareGun: 32,
    Explosion_Coins: 33,
    Explosion_Nuts: 34,
    Explosion_Keys: 35,
    Explosion_Balloon: 36,
    Explosion_TeleGrenadeSrc: 37,
    Player_Touch_Lava: 38,
    Portal_Teleport: 39,
    Explosion_Coins_Vertical: 40,
    Autumn_Leaves_Burst: 41,
    Explosion_Feathers: 42,
    Explosion_Popcorn: 43,
    Electricity_Small: 44,
    Impact_Flaregun: 64,
    Impact_Snowball: 65,
    Impact_GoldRevolver: 66,
    Impact_MeleeHit: 67,
    Impact_BigGroundHit: 68,
    Impact_MeleeHit_CriticalSmall: 69,
    Impact_MeleeHit_CriticalLarge: 70,
    Impact_MeleeHit_AoE: 71,
    Research_ZiplineAttachDetach: 96,
    Research_Purchase1RP: 97,
    Research_Purchase5RP: 98,
    Research_Purchase10RP: 99,
    Research_PurchaseRPBundle: 100,
    Rope_ZiplineAttachDetach: 110,
    MeatExplosion_1: 128,
    MeatExplosion_2: 129,
    MeatExplosion_Headshot: 130,
    ServerRoomSplash_Small: 160,
    ServerRoomSplash_Big: 161,
    RAMActivationSparks: 162,
    GreenBlink: 170,
    ConfettiBurst: 174,
    Ethereal_Void: 180,
    MomBoss_NailBreak: 181,
    MidAirJump_Fart: 182,
    FuelExplosion: 183
};
const version = "1.0.0";
const menuName = "G2 MENU";

let menu = null;
let matrixRainObjs: any[] = [];
let matrixRainNextUpdate = 0;
let matrixBtnObjs: any[] = [];
let matrixSetupQueue: Array<{textRoot: any, surface: any, char: string, color: [number,number,number,number], pos: any, size: any, isBg: boolean}> = [];
let reference = null;
let referenceCollider = null;
let buttonClickDelay = 0.0;
let LerpMenu = true;
let menuscale = 0.9;
let righthand = false;
let deltaTime = 0.0;
let time = 0.0;
let stashDupeEnabled = false;
let stashDupe = false;
let itemIndex = 0;
let itemGunDelay = 0;
let mobIndex = 0;
let mobGunDelay2 = 0;
let flySpeed = 20;
let customShredderNuts = 100;
let flingGunEnabled = false;
let kickGunEnabled = false;
let teleportGunEnabled = false;
let colorGunEnabled = false;
let spazColorGunEnabled = false;
let selectedTeleportLocation = 0;
let telekinesisGunEnabled = false;
let spawnGunEnabled = false;
let prefabGunEnabled = false;
let _kickTouchActive = false;
let _kickTouchDelay = 0;


let bgColor: [number, number, number, number]            = [0.0,  0.0,  0.0,  0.98];
let textColor: [number, number, number, number]          = [0.0,  1.0,  0.18, 1.0];
let buttonColor: [number, number, number, number]        = [0.02, 0.05, 0.02, 0.97];
let buttonPressedColor: [number, number, number, number] = [0.0,  0.85, 0.18, 1.0];
let menuAnimTime: number = 0;
let themeMode: number = 10; 
let rainbowStep: number = 0; 
const rainbowPresets: [number,number,number][] = [
    [1.0, 0.0, 0.0], 
    [1.0, 0.5, 0.0], 
    [1.0, 1.0, 0.0], 
    [0.0, 1.0, 0.0], 
    [0.0, 1.0, 1.0], 
    [0.0, 0.0, 1.0], 
    [0.5, 0.0, 1.0], 
    [1.0, 0.0, 1.0], 
];
let currentNotification: string = "";
let notifactionResetTime: number = 0;
let currentCategory = 0;
let currentPage = 0;
let hueVal = 0;
let satVal = 0;
let tagGunDelay = 0;
let frameCount = 0; 
let menuFontWarned = false;
let targetPlayerIndex: number = 0;
let _telekinesisActive: boolean = false;
let _telekinesisDelay: number = 0;
let _orbitAllActive: boolean = false;
let _orbitDelay: number = 0;
let _puppetActive: boolean = false;
let _puppetDelay: number = 0;
let _grabPlayerActive: boolean = false;
let _grabPlayerDelay: number = 0;
let _grabPlayerPrevB: boolean = false;
let _voidTouchActive: boolean = false;
let _voidTouchDelay: number = 0;
let _ragdollTouchActive: boolean = false;
let _ragdollTouchDelay: number = 0;
let _stickyFloorActive: boolean = false;
let _stickyFloorDelay: number = 0;
let _stickyFloorTouchActive: boolean = false;
let _stickyFloorTouchDelay: number = 0;
let _balloonTouchActive: boolean = false;
let _balloonTouchDelay: number = 0;
let _freezeActive: boolean = false;
let _freezeDelay: number = 0;
let _freezePos: any = null;
let _freezeTouchActive: boolean = false;
let _freezeTouchDelay: number = 0;
let _freezeTouchMap: { [key: string]: number[] } = {};

let leftPrimary = false;
let leftSecondary = false;
let rightPrimary = false;
let rightSecondary = false;
let leftGrab = false;
let rightGrab = false;
let leftTrigger = false;
let rightTrigger = false;
let leftStick = false;
let rightStick = false;
let leftStickX = 0.0;
let leftStickY = 0.0;
let rightStickX = 0.0;
let rightStickY = 0.0;
let prevLeftGrab = false;
let prevRightGrab = false;
let joystickFlyVelocity: [number, number, number] = [0, 0, 0];
let fistFlyVelocity: [number, number, number] = [0, 0, 0];
let InfAmmo = false;
let noRecoil = false;
let noShotgunCooldown = false;
let rapidFireEnabled = false;
let rapidFirePulseDelay = 0;
let infDamage = false;
let launchAxisCache: Map<string, string> = new Map();
let ejectDupeAmount = 2;
let ejectDupeIndex = 0;
const ejectDupeValues = [1, 2, 5, 10, 20, 30, 50, 100];
let scaleVal = 0;
let cachedItems: any = null;
let backpackDupe = false;
let lagGunDelay = 0;
let mobGunDelay = 0;
let idGunDelay = 0;
let rpgHandsDelay = 0;
let rpcMoneyAllLoopDelay = 0;
let giveFlyAllDelay = 0;
let menuStructurePatched = false;
let dualRevolverPunchDelay = 0;
let netPlayerSpawnDelay = 0;
let deleteAllLobbyItemsDelay = 0;
let itemRainDelay = 0;
let bringAllItemsGunDelay = 0;

// Animated Rainbow All Mobs
let rainbowMobsLoop = false;
let rainbowMobsNextTime = 0;
let rainbowMobsHue = 0; // 0..1 hue value
let rainbowMobsCursor = 0; // spread across frames to avoid freeze
let rainbowMobsCache: any[] = []; // cached mob instances
let rainbowMobsCacheNextRefresh = 0; // refresh cache every 3s

let floatingMachineEnabled = false;
let floatingMachine: any = null;
let floatingMachineState = "up";
let floatingMachinePauseTimer = 0;
let floatingMachineRotation = 0;
let floatingChristmasEnabled = false;
let telekinesisTarget: any = null;
let floatingChristmas: any = null;
let floatingChristmasState = "up";
let floatingChristmasPauseTimer = 0;
let floatingChristmasRotation = 0;


let bringAllItemsCursor = 0;
let goopSpamDelay = 0;
let itemLauncherSelfDelay = 0;
let heldItemDuplicateDelay = 0;
let kickGunDelay = 0;
let deletePlayerGunDelay = 0;
let blindGunDelay = 0;
let randomAllItemsDelay = 0;
let allPlayerGunBuffsDelay = 0;
let lagAllItemsDelay = 0;
let randomAllItemsCursor = 0;
let wlTargetActionDelay = 0;
let whitelist: any[] = [];
let netplrs: any[] = [];
let whitelistDisintegrateDelays: any = {};
let whitelistGunRe = false;
let sellingmachineSpawns: any[] = [];
let presentSpawns: any[] = [];
let spawnedNetworkPrefabs: any[] = [];
let spawnedPersistentMobs: any[] = [];
let movementPlatformLeft: any = null;
let movementPlatformRight: any = null;
let platformSpawnDelay = 0;
let menuSnapNextFrame = false;
let _kickTargetActive = false;
let _freezeGunActive = false;
let _freezeGunDelay = 0;
let _freezeGunPos = null;
let _freezeGunTargetPlayer = null;

let orbiters: any[] = [];
let orbitprefabs: any[] = [];
let buggyOrbiters: any[] = [];
let buggyOrbitPrefabs: any[] = [];
let sharkOrbiters: any[] = [];
let sharkOrbitPrefabs: any[] = [];
let sellingTowerOrbiters: any[] = [];
let sellingTowerOrbitPrefabs: any[] = [];
let itemTornadoEntries: any[] = [];
let spazMachineEntries: any[] = [];
let transformForwardAxisCache = new Map<string, number>();
let persistentMobEntries: any[] = [];
let wlSellingOrbitEntries: any[] = [];
let wlSellingOrbitPrefabs: any[] = [];
let wlOrbitAllTarget: any = null;
let wlOrbitAllPhase = 0;
let wlPissTarget: any = null;
let wlGunBuffTarget: any = null;
let wlRightHandDuperTarget: any = null;
let wlItemDuperHandTarget: any = null;
let wlStashEjectDuperTarget: any = null;
let wlItemDuperHandDelay = 0;
let mobOrbitEntries: any[] = [];
let prefabOrbitEntries: any[] = [];
let heldSellingMachine: any = null;
let forceDevModeEnabled = false;
let mobForceStayEnabled = false;
let mobSpawnAsyncBroken = false;
let infFartJumpEnabled = false;
let infFartJumpDelay = 0;
let infFartJumpOriginals: Map<string, any> = new Map();
let forceAllStashSlotsEnabled = false;
let containerFreedomAuraEnabled = false;
let containerFreedomSweepDelay = 0;
let playerCagePrefabs: any[] = [];
let playerCageEntries: any[] = [];
let spawnedGoopObjects: any[] = [];
let roundCornersEnabled = false;
let menuOutlineEnabled = true;
let GunPointer = null;
let GunLine = null;
const vfxTypeEntries = Object.entries(VFXTypes).filter(([_, value]) => typeof value === "number") as [string, number][];
let selectedVfxIndex = Math.max(0, vfxTypeEntries.findIndex(([name]) => name === "ConfettiBurst"));
let vfxDispatchUnavailableUntil = 0;
let vfxNoRunnerLogTime = 0;
let vfxMethodNamesCache: string[] | null = null;
let nameTagsEnabled = false;
let arenaEspEnabled = false;
let multiBuyEnabled = false;
let multiBuyAmount = 5;
let multiBuyHookGuard = false;
let playerNameTagEntries = new Map<string, any>();
let playerEspEntries = new Map<string, any>();

let prefabIndex: number = 0;
const prefabIDs: string[] = [
    
    "Shipwheel",
    "TeleportMachine",
    "FourLeafQuest_FourLeafSpawner",
    "EasterEgg_QuestSpawner",
    "RadarPartSpawner",
    "SimpleKeypadDoor",
    "GiantController_GraveyardBoss_backup",
    "MetaCameraControls",
    "GrenadeProjectile",
    "LaserMirror",
    "TeleportMachine",
    "mom_pillow",
    "RiggedPlank",
    "SharkScareTriggerObject",
    "Uvula",
    "BaitShopButton_Spawner",
    "NetworkedLever_SecretLeft",
    "CoreTeleporter",
    "LaserSource",
    "LaserSink",
    "grababble_fish_paper_message",
    "AutoDestroyItem_OilSplatter",
    "AutoDestroyItem_Splash0",
    "AutoDestroyItem_Splash1",
    "AutoDestroyItem_Splash2",
    "AutoDestroyItem_Splash3",
    "AutoDestroyItem_Splash4",
    "AutoDestroyItem_Splash5",
    "BarrelBeansDynamic",
    "BarrelBeansStatic",
    "BarrelExplodingDynamic",
    "BarrelExplodingStatic",
    "BarrelOilDynamic",
    "BarrelOilStatic",
    "Basketball",
    "BigBanana",
    "BigHatchdoorNetObject",
    "BigWheelhandleSpawner",
    "BonfireController",
    "BrainPowerPlug",
    "ChoppableTreeManager",
    "ChristmasBox",
    "ChristmasBoxManager",
    "ClawMachineNetObject",
    "DiggableGrave",
    "DummyPlayerTarget",
    "DummyTarget",
    "Duplicator",
    "EscherToyBlockObject",
    "ExplosiveEgg",
    "ExplosiveEggClustered",
    "FlareGunProjectile",
    "FortuneTellerNet",
    "FuelCanisterNetObject",
    "FuelCanisterSpawner",
    "GenericWorldItemSpawner",
    "GiantRockObject",
    "GiantRockObject_Fire",
    "GreenscreenNET",
    "HatchdoorGrabHandle",
    "HatchdoorNetObject",
    "HellAltar",
    "HH_LockedDoor",
    "HingedDoorNetworked",
    "HordeMobController",
    "HordeMobLobbyHandler",
    "InflatedBalloon",
    "InflatedHeartBalloon",
    "ItemSellingMachineController",
    "KeypadDoorNetObject",
    "LakePineapple_Spawner",
    "Landmine",
    "LeaderBoardMonsterKill",
    "LockedDoor_KeySpawner",
    "LockedShippingContainer_Quest",
    "LogQuestItemSpawner",
    "LootLantern",
    "Mausoleum_01",
    "MazeManager",
    "MimicSpawner_CemeteryTile1",
    "MimicSpawner_CemeteryTile3",
    "MomToyBlockObject",
    "MomToyBlockObject_DisappearOnDrop",
    "MountainKey_Spawner",
    "MovieTheater",
    "Net",
    "NetGameTimeManager",
    "NetLootSpawnGroup",
    "NetMobSpawnGroup",
    "NetPlayer",
    "NetSpectator",
    "Pillar_Arched_Broken_01",
    "RamEventNet",
    "remote_controller_receiver",
    "RobotDogRPG",
    "RPGRocket",
    "RPGRocketEgg",
    "RPGRocketSpear",
    "RuinTower_FloatingPlatform",
    "RuinTower_FloatingSmall",
    "ScaffoldTrap",
    "SkiRaceController",
    "Snail_Spawner",
    "SpaceshipTeleporter",
    "SpawnableZipline",
    "Spawner_Key",
    "StickyAnchor",
    "TeleportationManager",
    "ThunderController",
    "TubeMonster",
    "Vehicle_Buggy",
    "VHSQuests_VHSSpawner",
    "WinterFilm_ReelSpawner",
    
    "SpiderController",
];
let whitelistEnabled: boolean = true;
let soundFileIndex: number = 0;
let previousSoundKey: boolean = false;
let soundboardClips: { name: string; clip: any }[] = [];
let soundboardScanDone: boolean = false;
let soundboardVolume: number = 1.0;
let soundboardPitch: number = 1.0;
const _oculusNameCache: Map<string, string> = new Map();
const loadedBundles: any = {};
const loadedObjects: any = {};

Il2Cpp.perform(async () => {

    // Wait until IL2CPP domain is ready
    let domainReady = false;
    while (!domainReady) {
        await new Promise(r => setTimeout(r, 3000));
        try {
            const test = Il2Cpp.domain.assembly("AnimalCompany").image;
            if (test && !test.isNull()) domainReady = true;
        } catch(_) {}
    }

    
    const images = {
        "AnimalCompany":                    Il2Cpp.domain.assembly("AnimalCompany").image,
        "UnityEngine.CoreModule":           Il2Cpp.domain.assembly("UnityEngine.CoreModule").image,
        "UnityEngine.PhysicsModule":        Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image,
        "UnityEngine.UIModule":             Il2Cpp.domain.assembly("UnityEngine.UIModule").image,
        "UnityEngine.UI":                   Il2Cpp.domain.assembly("UnityEngine.UI").image,
        "UnityEngine.TextRenderingModule":  Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule").image,
        "PhotonFusionNetworking":           Il2Cpp.domain.assembly("Fusion.Runtime").image,
        "PhotonFusionNetworkingRealtime":   Il2Cpp.domain.assembly("Fusion.Realtime").image,
        "Unity.TextMeshPro":                Il2Cpp.domain.assembly("Unity.TextMeshPro").image,
        "UnityEngine.XRModule":             Il2Cpp.domain.assembly("UnityEngine.XRModule").image,
        "UnityEngine.AudioModule":          Il2Cpp.domain.assembly("UnityEngine.AudioModule").image,
        "Oculus.Platform":                  Il2Cpp.domain.assembly("Oculus.Platform").image,
    };

    const AssemblyCSharp           = images["AnimalCompany"];
    const UnityEngineCore          = images["UnityEngine.CoreModule"];
    const UnityEnginePhysics       = images["UnityEngine.PhysicsModule"];
    const UnityEngineUI            = images["UnityEngine.UI"];
    const UnityEngineUIModule      = images["UnityEngine.UIModule"];
    const UnityEngineTextRendering = images["UnityEngine.TextRenderingModule"];
    const PhotonFusionNetworking   = images["PhotonFusionNetworking"];
    const UnityTextMeshPro         = images["Unity.TextMeshPro"];
    const UnityEngineXR            = images["UnityEngine.XRModule"];
    const UnityEngineAudio         = images["UnityEngine.AudioModule"];
    const OculusPlatformSettings   = images["Oculus.Platform"].class("Oculus.Platform.PlatformSettings");

    
    const GTPlayerClass     = AssemblyCSharp.class("AnimalCompany.GorillaLocomotion");
    const NetPlayer         = AssemblyCSharp.class("AnimalCompany.NetPlayer");
    const ElevatorManager         = AssemblyCSharp.class("AnimalCompany.ElevatorManager");
    const ArenaGameManager = AssemblyCSharp.class("AnimalCompany.ArenaGameManager")
    const GrabbableObject = AssemblyCSharp.class("AnimalCompany.GrabbableObject");
    const PickupManager     = AssemblyCSharp.class("AnimalCompany.PickupManager");
    const ItemSellingMachineController = AssemblyCSharp.class("AnimalCompany.ItemSellingMachineController");
    const PrefabGen         = AssemblyCSharp.class("AnimalCompany.PrefabGenerator");
    const GBIClass          = AssemblyCSharp.class("AnimalCompany.GrabbableItem");
    
    const BackpackItemClass  = AssemblyCSharp.class("AnimalCompany.BackpackItem");
    const QuiverClass        = AssemblyCSharp.class("AnimalCompany.Quiver");
    let CrossbowClass: any = null;
    try { CrossbowClass = AssemblyCSharp.class("AnimalCompany.Crossbow"); } catch(_) {}
    let HeartGunClass: any = null;
    try { HeartGunClass = AssemblyCSharp.class("AnimalCompany.HeartGun"); } catch(_) {}
    let GrenadeLauncherClass: any = null;
    try { GrenadeLauncherClass = AssemblyCSharp.class("AnimalCompany.GrenadeLauncher"); } catch(_) {}
    let SalmonCannonClass: any = null;
    try { SalmonCannonClass = AssemblyCSharp.class("AnimalCompany.SalmonCannon"); } catch(_) {}
    let MobControllerBase: any = null;
    try { MobControllerBase = AssemblyCSharp.class("AnimalCompany.MobController"); } catch(_) {}
    let NetSessionPrivateRoomManagerClass: any = null;
    try { NetSessionPrivateRoomManagerClass = AssemblyCSharp.class("AnimalCompany.NetSessionPrivateRoomManager"); } catch(_) {}
    let PlayerWatchDevMenuMediatorClass: any = null;
    try { PlayerWatchDevMenuMediatorClass = AssemblyCSharp.class("AnimalCompany.PlayerWatchDevMenuMediator"); } catch(_) {}
    let ModerationMenuMediatorClass: any = null;
    try { ModerationMenuMediatorClass = AssemblyCSharp.class("AnimalCompany.ModerationMenuMediator"); } catch(_) {}
    let PrivateRoomStateClass: any = null;
    try { PrivateRoomStateClass = AssemblyCSharp.class("AnimalCompany.PrivateRoomState"); } catch(_) {}
    let UserCacheManagerClass: any = null;
    try { UserCacheManagerClass = AssemblyCSharp.class("AnimalCompany.UserCacheManager"); } catch(_) {}
    let AnimalCompanyApiClass: any = null;
    try { AnimalCompanyApiClass = AssemblyCSharp.class("AnimalCompany.API.AnimalCompanyAPI"); } catch(_) {}
    let ItemSellingMachineButtonViewClass: any = null;
    try { ItemSellingMachineButtonViewClass = AssemblyCSharp.class("AnimalCompany.ItemSellingMachineButtonView"); } catch(_) {}
    let GrabbablePurchaseClass: any = null;
    try { GrabbablePurchaseClass = AssemblyCSharp.class("AnimalCompany.GrabbablePurchase"); } catch(_) {}
    let ArenaGrabbablePurchaseClass: any = null;
    try { ArenaGrabbablePurchaseClass = AssemblyCSharp.class("AnimalCompany.ArenaGrabablePurchase"); } catch(_) {}
    const AudioClipClass     = UnityEngineAudio.class("UnityEngine.AudioClip");
    const PhotonVoiceImage   = Il2Cpp.domain.assembly("PhotonVoice").image;
    const VoiceConnectionClass  = PhotonVoiceImage.class("Photon.Voice.Unity.VoiceConnection");
    const NetworkSessionManagerClass = AssemblyCSharp.class("AnimalCompany.NetworkSessionManager");
    const DamageSourceInfoClass = AssemblyCSharp.class("AnimalCompany.DamageSourceInfo");
    const GameplayItemStateClass = AssemblyCSharp.class("AnimalCompany.GameplayItemState");
    const RigidbodyClass     = UnityEnginePhysics.class("UnityEngine.Rigidbody");
    const PCClass           = AssemblyCSharp.class("AnimalCompany.PlayerController");
    const GBOClass          = AssemblyCSharp.class("AnimalCompany.GrabbableObject");
    const SFXManager        = AssemblyCSharp.class("AnimalCompany.SFXManager");
    const NManager          = AssemblyCSharp.class("AnimalCompany.NetworkManager");
    const GorillaReportButton = AssemblyCSharp.class("AnimalCompany.ComputerTerminalKey");
    const InputDevices      = UnityEngineXR.class("UnityEngine.XR.InputDevices");
    const CommonUsages      = UnityEngineXR.class("UnityEngine.XR.CommonUsages");
    const Vector2           = UnityEngineCore.class("UnityEngine.Vector2");

    const GameObject        = UnityEngineCore.class("UnityEngine.GameObject");
    const Object            = UnityEngineCore.class("UnityEngine.Object");
    const Vector3           = UnityEngineCore.class("UnityEngine.Vector3");
    const Quaternion        = UnityEngineCore.class("UnityEngine.Quaternion");
    const Time              = UnityEngineCore.class("UnityEngine.Time");
    const Resources         = UnityEngineCore.class("UnityEngine.Resources");
    const Material          = UnityEngineCore.class("UnityEngine.Material");
    const Renderer          = UnityEngineCore.class("UnityEngine.Renderer");
    const Color             = UnityEngineCore.class("UnityEngine.Color");
    const Shader            = UnityEngineCore.class("UnityEngine.Shader");
    const Camera            = UnityEngineCore.class("UnityEngine.Camera");
    const RectTransform     = UnityEngineCore.class("UnityEngine.RectTransform");
    const LineRenderer      = UnityEngineCore.class("UnityEngine.LineRenderer");

    const BoxCollider       = UnityEnginePhysics.class("UnityEngine.BoxCollider");
    const Collider          = UnityEnginePhysics.class("UnityEngine.Collider");
    const Rigidbody         = UnityEnginePhysics.class("UnityEngine.Rigidbody");
    const Physics           = UnityEnginePhysics.class("UnityEngine.Physics");
    const Component         = UnityEngineCore.class("UnityEngine.Component");
    const ParticleManager      = AssemblyCSharp.class("AnimalCompany.ParticleManager");
    const ParticleManagerClass = ParticleManager;
    let VFXManagerClass: any = null;
    try { VFXManagerClass = AssemblyCSharp.class("AnimalCompany.VFXManager"); } catch(_) {}
    let MobDataUtilityClass: any = null;
    try { MobDataUtilityClass = AssemblyCSharp.class("AnimalCompany.MobDataUtility"); } catch(_) {}

    const Font              = UnityEngineTextRendering.class("UnityEngine.Font");
    let TextMesh: any = null;
    let TextMeshPro3D: any = null;
    let TMPSettingsClass: any = null;
    let tmpDefaultFontAsset: any = null;
    try { TextMesh = UnityEngineTextRendering.class("UnityEngine.TextMesh"); } catch(_) {}
    if (!TextMesh) {
        try { TextMesh = UnityEngineCore.class("UnityEngine.TextMesh"); } catch(_) {}
    }
    try { TextMeshPro3D = UnityTextMeshPro.class("TMPro.TextMeshPro"); } catch(_) {}
    try { TMPSettingsClass = UnityTextMeshPro.class("TMPro.TMP_Settings"); } catch(_) {}

    
    let GTPlayer: any = null;
    const UberShader        = Shader.method("Find").invoke(Il2Cpp.string("Universal Render Pipeline/Unlit"));
    const TextShader        = Shader.method("Find").invoke(Il2Cpp.string("UI/Default"));
    const zeroVector        = Vector3.field("zeroVector").value;
    const oneVector         = Vector3.field("oneVector").value;
    const identityQuaternion = Quaternion.field("identityQuaternion").value;
    let leftHandTransform: any = null;
    let rightHandTransform: any = null;
    let headCollider: any = null;
    let bodyCollider: any = null;
    let arial: any = null;
    let arialRetryAfter = 0;
    function getarialnocrash2() {
        if (arial && !arial.isNull()) return arial;
        const nowMs = Date.now();
        if (nowMs < arialRetryAfter) return null;
        try {
            arial = Resources.method("GetBuiltinResource", 1).inflate(Font).invoke(Il2Cpp.string("Arial.ttf"));
        } catch (e) {
            arial = null;
            arialRetryAfter = nowMs + 2000;
            if (!menuFontWarned) {
                menuFontWarned = true;
                console.error("[G2] Arial.ttf builtin font load failed during startup/runtime; text will retry later");
            }
        }
        return arial;
    }
    function gettmpfontnocrash() {
        if (tmpDefaultFontAsset && !tmpDefaultFontAsset.isNull()) return tmpDefaultFontAsset;
        if (!TMPSettingsClass) return null;
        try { tmpDefaultFontAsset = TMPSettingsClass.method("get_defaultFontAsset").invoke(); } catch(_) {}
        if (!tmpDefaultFontAsset || tmpDefaultFontAsset.isNull()) {
            try {
                const settingsInstance = TMPSettingsClass.method("get_instance").invoke();
                if (settingsInstance && !settingsInstance.isNull()) {
                    try { tmpDefaultFontAsset = settingsInstance.method("get_defaultFontAsset").invoke(); } catch(_) {}
                    if (!tmpDefaultFontAsset || tmpDefaultFontAsset.isNull()) {
                        try { tmpDefaultFontAsset = settingsInstance.field("m_defaultFontAsset").value; } catch(_) {}
                    }
                }
            } catch(_) {}
        }
        return tmpDefaultFontAsset && !tmpDefaultFontAsset.isNull() ? tmpDefaultFontAsset : null;
    }

    const NullMethod: any = {
        invoke: () => NullObject,
        inflate: () => NullMethod,
        overload: () => NullMethod
    };
    const NullObject: any = {
        handle: { isNull: () => true },
        isNull: () => true,
        method: () => NullMethod,
        field: () => ({ value: NullObject }),
        tryField: () => null,
        tryMethod: () => null,
        class: { type: { name: "NullObject" } }
    };

    function isLiveObject(obj: any) {
        try {
            return !!obj && !(obj.isNull?.() ?? true);
        } catch(_) {
            return false;
        }
    }

    function refreshRuntimeRefs() {
        try {
            const player = GTPlayerClass.field("<Instance>k__BackingField").value;
            if (isLiveObject(player)) GTPlayer = player;
        } catch(_) {}
        try {
            if (isLiveObject(GTPlayer)) {
                try {
                    const nextLeftHandTransform = GTPlayer.field("leftHandTransform").value;
                    if (isLiveObject(nextLeftHandTransform)) leftHandTransform = nextLeftHandTransform;
                } catch(_) {}
                try {
                    const nextRightHandTransform = GTPlayer.field("rightHandTransform").value;
                    if (isLiveObject(nextRightHandTransform)) rightHandTransform = nextRightHandTransform;
                } catch(_) {}
                try {
                    const nextHeadCollider = GTPlayer.field("headCollider").value;
                    if (isLiveObject(nextHeadCollider)) headCollider = nextHeadCollider;
                } catch(_) {}
                try {
                    const nextBodyCollider = GTPlayer.field("bodyCollider").value;
                    if (isLiveObject(nextBodyCollider)) bodyCollider = nextBodyCollider;
                } catch(_) {}
            }
        } catch(_) {
        }
        return isLiveObject(GTPlayer) && isLiveObject(leftHandTransform) && isLiveObject(rightHandTransform) && isLiveObject(bodyCollider);
    }

    // ── lobby-change crash fix ────────────────────────────────────────────────
    let _lastRunnerPtr: string = "";

    function getRunnerPtr(): string {
        try {
            const pgInst = PrefabGen.field("_instance").value;
            if (!pgInst || pgInst.isNull?.()) return "";
            const r = pgInst.method("get_runner").invoke();
            if (!r || r.isNull?.()) return "";
            return String(r.handle ?? r);
        } catch(_) { return ""; }
    }

    function flushSceneBoundState() {
        try {
            for (const arr of [spawnedNetworkPrefabs, spawnedPersistentMobs]) {
                for (const obj of arr) {
                    try {
                        if (obj && !obj.isNull?.()) {
                            const go = obj.method?.("get_gameObject")?.invoke?.();
                            if (go && !go.isNull?.()) Object.method("Destroy", 1).invoke(go);
                        }
                    } catch(_) {}
                }
            }
        } catch(_) {}

        spawnedNetworkPrefabs = [];
        spawnedPersistentMobs = [];
        persistentMobEntries  = [];
        spawnedGoopObjects    = [];
        spazMachineEntries    = [];
        itemTornadoEntries    = [];
        lockedItems           = [];

        matrixRainObjs   = [];
        matrixBtnObjs    = [];
        matrixSetupQueue = [];

        GTPlayer           = null;
        leftHandTransform  = null;
        rightHandTransform = null;
        headCollider       = null;
        bodyCollider       = null;

        try {
            if (menu != null && !menu.isNull?.()) { Object.method("Destroy", 1).invoke(menu); menu = null; }
        } catch(_) { menu = null; }
        try {
            if (reference != null && !reference.isNull?.()) { Object.method("Destroy", 1).invoke(reference); reference = null; }
        } catch(_) { reference = null; }

        runtimeRefMissCount = 0;
        console.log("[G2] Lobby change detected — scene-bound state flushed");
    }

    function checkLobbyChange() {
        const ptr = getRunnerPtr();
        if (ptr === "" && _lastRunnerPtr === "") return;
        if (ptr !== _lastRunnerPtr) {
            _lastRunnerPtr = ptr;
            flushSceneBoundState();
        }
    }
    // ── end lobby-change crash fix ────────────────────────────────────────────

    let runtimeRefMissCount = 0;

    function logButtonRuntimeError(button: any, error: any) {
        const now = time ?? 0;
        const nextLogTime = (button as any).__nextErrorLogTime ?? 0;
        const failCount = (((button as any).__failCount ?? 0) + 1);
        (button as any).__failCount = failCount;
        if (failCount === 1 || now >= nextLogTime) {
            console.error(`[LateUpdate] Error in '${button.buttonText}':`, error);
            (button as any).__nextErrorLogTime = now + 1.5;
        }
    }

    
    function Destroy(object) {
        try {
            if (!object || object === NullObject) return;
            if (object.isNull?.()) return;
            Object.method("Destroy", 1).invoke(object);
        } catch(_) {}
    }
    function getComponent(obj: any, type) {
        try {
            if (!obj || obj.isNull?.()) return null;
            return obj.method("GetComponent", 1).inflate(type).invoke();
        } catch(_) { return null; }
    }
    function getComponentInParent(obj: any, type) {
        try {
            if (!obj || obj.isNull?.()) return null;
            return obj.method("GetComponentInParent", 0).inflate(type).invoke();
        } catch(_) { return null; }
    }
    function addComponent(obj: any, type) { return obj.method("AddComponent", 1).inflate(type).invoke(); }
    function getTransform(obj: any) { return obj.method("get_transform").invoke(); }
    function playerIsLocal(player) { return player.method("get_IsMine").invoke(); }
    function setMenuTextScale(textTransform: any, scaleObject: any, baseScale: number) {
        try {
            const menuScale = getTransform(scaleObject).method("get_localScale").invoke();
            const sx = Math.abs(menuScale.field("x").value) || 1.0;
            const sy = Math.abs(menuScale.field("y").value) || 1.0;
            const sz = Math.abs(menuScale.field("z").value) || 1.0;
            const xScale = (baseScale * 0.42) / sx;
            textTransform.method("set_localScale").invoke([-xScale, baseScale / sy, baseScale / sz]);
        } catch(_) {
            try { textTransform.method("set_localScale").invoke([-(baseScale * 0.42), baseScale, baseScale]); } catch(_) {}
        }
    }
    function createEmptyObject(name: string = "", parent = null) {
        let obj = null;
        try {
            obj = GameObject.alloc();
            try { obj.method(".ctor", 1).invoke(Il2Cpp.string(name)); }
            catch(_) {
                obj.method(".ctor", 0).invoke();
                try { obj.method("set_name").invoke(Il2Cpp.string(name)); } catch(_) {}
            }
        } catch(_) {
            obj = createObject(zeroVector, identityQuaternion, oneVector, 3, [0, 0, 0, 0], parent);
            try {
                const col = getComponent(obj, Collider);
                if (col && !col.isNull()) col.method("set_enabled").invoke(false);
            } catch(_) {}
            return obj;
        }
        const transform = getTransform(obj);
        if (parent != null) transform.method("SetParent", 2).invoke(parent, false);
        return obj;
    }
    function invokeInstance(method: any, instance: any, ...args: any[]) { return method.invokeRaw(instance, ...args); }
    function tryMethodName(klass: any, names: string[], parameterCount: number = -1) {
        for (const name of names) {
            try { return parameterCount >= 0 ? klass.method(name, parameterCount) : klass.method(name); }
            catch(_) {}
        }
        return null;
    }
    function isClassNamed(obj: any, className: string) {
        try { return obj && !obj.isNull() && obj.class.type.name === className; } catch(_) { return false; }
    }

    const NetworkRunner = Il2Cpp.domain.assembly("Fusion.Runtime").image.class("Fusion.NetworkRunner");
    const NULL = Il2Cpp.reference(Il2Cpp.domain.assembly("mscorlib").image.class("System.Object").alloc());

    
    function spawnItemAtPos(bareID: string, pos: any, rot: any): any {
        try {
            const prefab = PrefabGen.method("GetItemPrefab", 1).invoke(Il2Cpp.string(bareID));
            if (prefab && !prefab.isNull()) {
                const result = PrefabGen.method("SpawnItem", 4).invoke(prefab, pos, rot, NULL);
                if (result && !result.isNull()) return result;
            }
            const result2 = PrefabGen.method("SpawnItem", 4).invoke(Il2Cpp.string(bareID), pos, rot, NULL);
            if (result2 && !result2.isNull()) return result2;
            return PrefabGen.method("SpawnItem", 4).invoke(Il2Cpp.string("item_prefab/" + bareID), pos, rot, NULL);
        } catch(e) {
            console.error("[spawnItemAtPos] " + bareID + ": " + e);
            return null;
        }
    }

       function kickPlayer(player) {
        const PrefabGenerator = AssemblyCSharp.class("AnimalCompany.NetSessionRPCs");
        const netinst = PrefabGenerator.field("_instance").value;
        if (!netinst) return null;
        const kickplr = PrefabGenerator.method("KickPlayer");
        if (!kickplr) return null;
        const rpckickplr = netinst.method("RPC_KickPlayer");
        if (!rpckickplr) return null;
        const plruserID = player.field("_userID").value;
        if (!plruserID) return null;
        const parsedid = Il2Cpp.corlib.class("System.Guid").method("Parse").invoke(plruserID);
        rpckickplr.invoke(parsedid);
        kickplr.invoke(plruserID);
    }

    function kickAllPlayers() {
        try {
            let kickCount = 0;
            const rigs = Object.method("FindObjectsOfType").inflate(NetPlayer).invoke();
            for (let i = 0; i < rigs.length; i++) {
                const rig = rigs.get(i);
                if (playerIsLocal(rig)) continue;
                kickPlayer(rig);
                kickCount++;
            }
            console.log(`[+] Kicked ${kickCount} players`);
            sendNotification(`Kicked ${kickCount} players`, false);
        } catch (e) {
            console.log(`[-] Error in kickAllPlayers: ${e}`);
        }
    }

    function trackPersistentMob(mobEntry: { name: string; id: number }, pos: any, rot: any, spawned: any) {
        try {
            persistentMobEntries.push({
                mobEntry,
                pos,
                rot,
                object: spawned ?? null,
                lastRespawnTime: time
            });
        } catch(_) {}
    }
    function stabilizeMobInstance(mob: any, fallbackPos: any = null) {
        try {
            if (!mob || mob.isNull?.()) return;
            let go = mob;
            try {
                const maybeGo = mob.method("get_gameObject").invoke();
                if (maybeGo && !maybeGo.isNull?.()) go = maybeGo;
            } catch(_) {}
            try { go.method("SetActive").invoke(true); } catch(_) {}
            try { mob.method("set_enabled").invoke(true); } catch(_) {}
            try {
                const killer = go.method("GetComponentInChildren", 0).inflate(AssemblyCSharp.class("AnimalCompany.ArenaItemKiller")).invoke();
                if (killer && !killer.isNull?.()) {
                    try { killer.method("set_enabled").invoke(false); } catch(_) {}
                    try { killer.field("_isEnabled").value = false; } catch(_) {}
                }
            } catch(_) {}
            if (fallbackPos) {
                try {
                    const tf = getTransform(go);
                    const cur = tf.method("get_position").invoke();
                    if ((cur.field("y").value as number) < -5000) tf.method("set_position").invoke(fallbackPos);
                } catch(_) {}
            }
        } catch(_) {}
    }


// ── Mob Spawn Delegate helpers ────────────────────────────────────────────────
let _beforeSpawnDelegate: any = null;
let _beforeSpawnDelegateClass: any = null;
let _validatorBypassEnabled = false;

function enableMobValidatorBypass() {
    if (_validatorBypassEnabled) return;
    try {
        Il2Cpp.domain
            .assembly("AnimalCompany")
            .image.class("AnimalCompany.MobSpawnValidator")
            .method("IsMobAllowed", 1)
            .implementation = () => true;
        _validatorBypassEnabled = true;
    } catch(e) { console.log("[G2] bypass fail: " + e); }
}

function getBeforeMobSpawnDelegate() {
    if (_beforeSpawnDelegate) return _beforeSpawnDelegate;
    try {
        _beforeSpawnDelegateClass = Il2Cpp.domain
            .assembly("Fusion.Runtime")
            .image.class("Fusion.NetworkRunner")
            .tryNested("OnBeforeSpawned");
        const validator = Il2Cpp.domain
            .assembly("AnimalCompany")
            .image.class("AnimalCompany.MobSpawnValidator");
        _beforeSpawnDelegate = Il2Cpp.delegate(
            _beforeSpawnDelegateClass,
            (_runner: any, networkObject: any) => {
                if (!networkObject || networkObject.handle?.isNull()) return;
                try {
                    const networkId = networkObject.method("get_Id").invoke();
                    validator.method("AddAllowMob", 1).invoke(networkId);
                } catch(_) {}
            }
        );
    } catch(e) { console.log("[G2] fail: " + e); }
    return _beforeSpawnDelegate;
}

function spawnMobAtPos(mobEntry: { name: string; id: number }, pos: any, rot: any): any {
    const trackSpawnedMob = (spawned: any) => {
        try {
            if (spawned && !spawned.isNull?.()) {
                stabilizeMobInstance(spawned, pos);
                spawnedPersistentMobs.push(spawned);
                trackPersistentMob(mobEntry, pos, rot, spawned);
            }
        } catch(_) {}
        return spawned;
    };

    // Try delegate-based SpawnMobAsync first (new method)
    try {
        enableMobValidatorBypass();
        const animalCompany = Il2Cpp.domain.assembly("AnimalCompany").image;
        const prefabGenerator = animalCompany.class("AnimalCompany.PrefabGenerator");
        const mobIdClass = animalCompany.class("AnimalCompany.MobID");
        const cleanName = String(mobEntry.name).replace(/^mobprefab/i, "");
        const candidates = [cleanName, cleanName.replace(/Controller$/, ""), cleanName + "Controller"];
        let mobId: any = null;
        for (const candidate of candidates) {
            try { mobId = mobIdClass.field(candidate).value; break; } catch(_) {}
        }
        if (mobId !== null) {
            try {
                const objectRef = Il2Cpp.reference(
                    Il2Cpp.domain.assembly("mscorlib").image.class("System.Object").alloc()
                );
                const result = prefabGenerator.method("SpawnMobAsync", 6).overload(
                    "AnimalCompany.MobID",
                    "UnityEngine.Vector3",
                    "UnityEngine.Quaternion",
                    "Fusion.NetworkRunner.OnBeforeSpawned",
                    "Fusion.NetworkObjectSpawnDelegate",
                    "System.String"
                ).invoke(mobId, pos, rot, getBeforeMobSpawnDelegate(), objectRef, Il2Cpp.string("mod"));
                if (result && !result.isNull?.()) return trackSpawnedMob(result);
            } catch(e) { console.log("[G2] delegate path fail: " + e); }
        }
    } catch(e) { console.log("[G2] setup fail: " + e); }

    // Fallback: old ID-based SpawnMobAsync
    if (!mobSpawnAsyncBroken) {
        try {
            const result = PrefabGen.method("SpawnMobAsync", 6).invoke(
                mobEntry.id, pos, rot, NULL, NULL, Il2Cpp.string("menu")
            );
            if (result && !result.isNull?.()) return trackSpawnedMob(result);
        } catch(e) {
            if (String(e).toLowerCase().indexOf("access violation") >= 0) mobSpawnAsyncBroken = true;
        }
    }

    // Fallback: prefab name variants
    try {
        const fallbackNames = [
            mobEntry.name, "mob_" + mobEntry.name,
            mobEntry.name + "Controller", "Mob" + mobEntry.name
        ];
        for (const prefabName of fallbackNames) {
            if (!prefabName) continue;
            const spawned = spawnNetworkPrefab(prefabName, pos, rot);
            if (spawned && !spawned.isNull?.()) return trackSpawnedMob(spawned);
        }
    } catch(_) {}

    return null;
}

    
    function spawnNetworkPrefab(prefabName: string, pos: any, rot: any) {
        try {
            const runner = PrefabGen.field("_instance").value.method("get_runner").invoke();
            if (!runner || runner.isNull()) return null;
            const sources = runner.field("_config").value.field("PrefabTable").value.field("_sources").value;
            const count = sources.method("get_Count").invoke();
            for (let i = 0; i < count; i++) {
                try {
                    const source = sources.method("get_Item").invoke(i);
                    const desc = source.method("get_Description").invoke().toString();
                    if (desc.toLowerCase().includes(String(prefabName).toLowerCase())) {
                        const no = source.method("WaitForResult").invoke();
                        if (!no || no.isNull()) return null;
                        const makeZeroForType = (type) => {
                            if (type.class.isEnum || type.isPrimitive) return 0;
                            if (!type.class.isValueType) return NULL;
                            const fields = type.class.fields.filter(f => !f.isStatic);
                            if (fields.length === 0) return 0;
                            return fields.map(f => makeZeroForType(f.type));
                        };
                        const buildNullableArg = (nullableType, hasValue, value) => {
                            const fields = nullableType.class.fields.filter(f => !f.isStatic);
                            return fields.map(f => {
                                const lname = f.name.toLowerCase();
                                if (lname.includes("hasvalue")) return hasValue ? 1 : 0;
                                if (lname === "value") return hasValue ? value : makeZeroForType(f.type);
                                return makeZeroForType(f.type);
                            });
                        };
                        const normalizeValue = (type, value) => {
                            if (typeof value === "boolean") return value ? 1 : 0;
                            if (value instanceof Il2Cpp.ValueType) {
                                const fields = type.class.fields.filter(f => !f.isStatic);
                                if (fields.length === 0) return 0;
                                return fields.map(f => normalizeValue(f.type, f.bind(value).value));
                            }
                            if (Array.isArray(value)) return value.map(v => normalizeValue(type, v));
                            return value;
                        };
                        const buildNullableFromValueType = (nullableType, valueType) => {
                            return buildNullableArg(nullableType, true, normalizeValue(valueType.type, valueType));
                        };
                        let spawnMethod = null;
                        for (const m of runner.method("Spawn").overloads()) {
                            if (m.parameterCount !== 6 || m.isGeneric) continue;
                            const p = m.parameters;
                            if (p[0].type.name.includes("Fusion.NetworkObject") &&
                                p[1].type.name.startsWith("System.Nullable") && p[1].type.name.includes("Vector3") &&
                                p[2].type.name.startsWith("System.Nullable") && p[2].type.name.includes("Quaternion") &&
                                p[3].type.name.startsWith("System.Nullable") && p[3].type.name.includes("PlayerRef") &&
                                p[4].type.name.includes("OnBeforeSpawned") &&
                                p[5].type.name.includes("NetworkSpawnFlags")) {
                                spawnMethod = m; break;
                            }
                        }
                        if (!spawnMethod) return null;
                        const posArg = buildNullableFromValueType(spawnMethod.parameters[1].type, pos);
                        const rotArg = buildNullableFromValueType(spawnMethod.parameters[2].type, rot);
                        const authArg = buildNullableArg(spawnMethod.parameters[3].type, false, makeZeroForType(spawnMethod.parameters[3].type));
                        const onBeforeArg = spawnMethod.parameters[4].type.class.isValueType ? makeZeroForType(spawnMethod.parameters[4].type) : NULL;
                        const spawned = spawnMethod.bind(runner).invoke(no, posArg, rotArg, authArg, onBeforeArg, 0);
                        if (spawned && !spawned.isNull()) spawnedNetworkPrefabs.push(spawned);
                        return spawned;
                    }
                } catch(_) {}
            }
        } catch(e) { console.error("spawnNetworkPrefab error: " + e); }
        return null;
    }
    function cleanupDeadTrackedObjects(list: any[]) {
        for (let i = list.length - 1; i >= 0; i--) {
            const obj = list[i];
            if (!obj || obj.isNull?.()) list.splice(i, 1);
        }
    }
    function trySetObjectVelocity(obj: any, velocity: any) {
        try {
            if (!obj || obj.isNull?.()) return false;
            let rb = null;
            try { rb = getComponent(obj, Rigidbody); } catch(_) {}
            if ((!rb || rb.isNull?.()) && obj.method) {
                try {
                    const go = obj.method("get_gameObject").invoke();
                    if (go && !go.isNull()) rb = getComponent(go, Rigidbody);
                } catch(_) {}
            }
            if ((!rb || rb.isNull?.()) && obj.method) {
                try {
                    const tf = getTransform(obj);
                    if (tf && !tf.isNull()) rb = getComponentInParent(tf.method("get_gameObject").invoke(), Rigidbody);
                } catch(_) {}
            }
            if ((!rb || rb.isNull?.()) && obj.method) {
                try {
                    const go = obj.method("get_gameObject").invoke();
                    if (go && !go.isNull()) {
                        rb = go.method("GetComponentInChildren", 0).inflate(Rigidbody).invoke();
                    }
                } catch(_) {}
            }
            if (rb && !rb.isNull()) {
                try { rb.method("set_isKinematic").invoke(false); } catch(_) {}
                try { rb.method("set_useGravity").invoke(true); } catch(_) {}
                try { rb.method("set_velocity").invoke(velocity); return true; } catch(_) {}
                try { rb.method("AddForce").invoke(velocity, 2); return true; } catch(_) {}
                try { rb.method("AddForce").invoke(velocity); return true; } catch(_) {}
                try { rb.field("_velocity").value = velocity; return true; } catch(_) {}
            }
        } catch(_) {}
        return false;
    }
    function getLaunchForward(sourceTransform: any, referenceTransform: any = null) {
        try {
            const refTf = (referenceTransform && !referenceTransform.isNull?.())
                ? referenceTransform
                : (headCollider && !headCollider.isNull?.() ? getTransform(headCollider) : null);
            const referenceForward = refTf && !refTf.isNull?.()
                ? readVec3Components(refTf.method("get_forward").invoke())
                : [0, 0, 1];
            const cacheKey = normalizeSceneObjectHandle(sourceTransform) || String(sourceTransform);
            const cachedAxis = launchAxisCache.get(cacheKey);
            const readAxis = (axisName: string): any => {
                switch (axisName) {
                    case "forward": return sourceTransform.method("get_forward").invoke();
                    case "-forward": return Vector3.method("op_Multiply", 2).invoke(sourceTransform.method("get_forward").invoke(), -1);
                    case "up": return sourceTransform.method("get_up").invoke();
                    case "-up": return Vector3.method("op_Multiply", 2).invoke(sourceTransform.method("get_up").invoke(), -1);
                    case "right": return sourceTransform.method("get_right").invoke();
                    case "-right": return Vector3.method("op_Multiply", 2).invoke(sourceTransform.method("get_right").invoke(), -1);
                    default: return sourceTransform.method("get_forward").invoke();
                }
            };
            if (cachedAxis) {
                return Vector3.method("Normalize").invoke(readAxis(cachedAxis));
            }
            const candidates = ["forward", "-forward"];
            let bestAxis = "forward";
            let bestScore = -999999;
            for (const axisName of candidates) {
                try {
                    const vec = readAxis(axisName);
                    const v = readVec3Components(vec);
                    const score = (v[0] * referenceForward[0]) + (v[1] * referenceForward[1]) + (v[2] * referenceForward[2]);
                    if (score > bestScore) {
                        bestScore = score;
                        bestAxis = axisName;
                    }
                } catch(_) {}
            }
            launchAxisCache.set(cacheKey, bestAxis);
            return Vector3.method("Normalize").invoke(readAxis(bestAxis));
        } catch(_) {
            try { return sourceTransform.method("get_forward").invoke(); } catch(_) { return [0, 0, 1]; }
        }
    }
    function getLaunchUp(sourceTransform: any, forward: any) {
        try {
            const worldUp = [0, 1, 0];
            const dot = Vector3.method("Dot").invoke(worldUp, forward) as number;
            let projected = Vector3.method("op_Subtraction", 2).invoke(
                worldUp,
                Vector3.method("op_Multiply", 2).invoke(forward, dot)
            );
            const mag = Vector3.method("Magnitude").invoke(projected) as number;
            if (mag < 0.05) {
                projected = sourceTransform.method("get_up").invoke();
            }
            return Vector3.method("Normalize").invoke(projected);
        } catch(_) {
            try { return sourceTransform.method("get_up").invoke(); } catch(_) { return [0, 1, 0]; }
        }
    }
    function getLaunchRotation(sourceTransform: any, forward: any, up: any) {
        try { return Quaternion.method("LookRotation", 2).invoke(forward, up); } catch(_) {}
        try { return Quaternion.method("LookRotation", 1).invoke(forward); } catch(_) {}
        try { return sourceTransform.method("get_rotation").invoke(); } catch(_) { return identityQuaternion; }
    }
    function spawnForwardLaunchedNetworkPrefab(prefabName: string, sourceTransform: any, speed: number = 30.0, forwardOffset: number = 1.0) {
        try {
            const forward = getLaunchForward(sourceTransform);
            const up = getLaunchUp(sourceTransform, forward);
            const spawnPos = Vector3.method("op_Addition").invoke(
                sourceTransform.method("get_position").invoke(),
                Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, forwardOffset),
                    Vector3.method("op_Multiply", 2).invoke(up, -0.06)
                )
            );
            const rot = getLaunchRotation(sourceTransform, forward, up);
            const spawned = spawnNetworkPrefab(prefabName, spawnPos, rot);
            if (spawned && !spawned.isNull()) {
                const vel = Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, speed),
                    Vector3.method("op_Multiply", 2).invoke(up, 3.0)
                );
                if (!trySetObjectVelocity(spawned, vel)) {
                    try {
                        const tf = getTransform(spawned);
                        tf.method("set_position").invoke(
                            Vector3.method("op_Addition").invoke(
                                spawnPos,
                                Vector3.method("op_Multiply", 2).invoke(forward, 2.2)
                            )
                        );
                    } catch(_) {}
                }
            }
            return spawned;
        } catch(_) {
            return null;
        }
    }
    function spawnForwardLaunchedItem(bareID: string, sourceTransform: any, speed: number = 24.0, forwardOffset: number = 0.82) {
        try {
            const forward = getLaunchForward(sourceTransform);
            const up = getLaunchUp(sourceTransform, forward);
            const spawnPos = Vector3.method("op_Addition").invoke(
                sourceTransform.method("get_position").invoke(),
                Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, forwardOffset),
                    Vector3.method("op_Multiply", 2).invoke(up, -0.05)
                )
            );
            const rot = getLaunchRotation(sourceTransform, forward, up);
            const spawned = spawnItemAtPos(bareID, spawnPos, rot);
            if (spawned && !spawned.isNull()) {
                const velocity = Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, speed),
                    Vector3.method("op_Multiply", 2).invoke(up, 1.2)
                );
                trySetObjectVelocity(spawned, velocity);
            }
            return spawned;
        } catch(_) {
            return null;
        }
    }
    function getGunAimDirection() {
        try {
            const referenceTf = headCollider && !headCollider.isNull?.() ? getTransform(headCollider) : null;
            return getLaunchForward(rightHandTransform, referenceTf);
        } catch(_) {
            return rightHandTransform.method("get_forward").invoke();
        }
    }
    function setUniformLocalScale(targetObj: any, parentObj: any, worldScale: number) {
        try {
            const parentScale = getTransform(parentObj).method("get_localScale").invoke();
            const sx = Math.abs(parentScale.field("x").value) || 1.0;
            const sy = Math.abs(parentScale.field("y").value) || 1.0;
            const sz = Math.abs(parentScale.field("z").value) || 1.0;
            getTransform(targetObj).method("set_localScale").invoke([worldScale / sx, worldScale / sy, worldScale / sz]);
        } catch(_) {
            try { getTransform(targetObj).method("set_localScale").invoke([worldScale, worldScale, worldScale]); } catch(_) {}
        }
    }
    function addSurfaceOutline(surfaceObject: any, color: [number, number, number, number], thickness: number = 0.045) {
        try {
            const parent = getTransform(surfaceObject);
            const pad = 1.0 + thickness * 0.5;
            // x=-0.01 puts it behind, x scale 1.05 makes it slightly thicker than button, y/z pad makes it wider/taller
            const border = createObject([-0.01, 0, 0], identityQuaternion, [1.05, pad, pad], 3, color, parent);
            try { const col = getComponent(border, Collider); if (col && !col.isNull()) col.method("set_enabled").invoke(false); } catch(_) {}
        } catch(_) {}
    }
    function addRoundedCorners(surfaceObject: any, color: [number, number, number, number], radius: number = 0.022) {
        if (!roundCornersEnabled) return;
        return;
        const parent = getTransform(surfaceObject);
        const corners = [
            [0.508, 0.47, 0.47],
            [0.508, 0.47, -0.47],
            [0.508, -0.47, 0.47],
            [0.508, -0.47, -0.47]
        ];
        for (const corner of corners) {
            try {
                const sphere = createObject(corner as any, identityQuaternion, oneVector, 0, color, parent);
                const col = getComponent(sphere, Collider);
                if (col && !col.isNull()) col.method("set_enabled").invoke(false);
                setUniformLocalScale(sphere, surfaceObject, radius);
            } catch(_) {}
        }
    }

    let cachedSpawnPrefab: any = null;
    let cachedSpawnPrefabName: string = "";
    let prefabTestIndex: number = 0;
    let lockedItems: any[] = [];
    let lastSpawnSearchTime: number = 0;
    function world2Player(position) {
        position = Vector3.method("op_Subtraction", 2).invoke(position, getTransform(bodyCollider).method("get_position").invoke());
        position = Vector3.method("op_Addition", 2).invoke(position, getTransform(GTPlayer).method("get_position").invoke());
        return position;
    }

    function teleportPlayer(position) {
        const player = NetPlayer.method("get_localPlayer").invoke();
        if (!player) return;
        player.method("RPC_Teleport").invoke(world2Player(position));
    }

    function sendNotification(text: string = "", requiresReload: boolean = true, clearTime: number = 5) {
        notifactionResetTime = time + clearTime;
        currentNotification = text;
    }

    

function createObject(pos = zeroVector, rot = identityQuaternion, scale = oneVector, primitiveType: number = 3, colorArr: [number, number, number, number] = [1, 1, 1, 1], parent = null, enableCollider: boolean = false) {
    const obj = GameObject.method("CreatePrimitive").invoke(primitiveType);
    const renderer = getComponent(obj, Renderer);
    if (colorArr[3] == 0) {
        renderer.method("set_enabled").invoke(false);
    } else {
        const material = renderer.method("get_material").invoke();
        material.method("set_shader").invoke(UberShader);
        material.method("set_color").invoke(colorArr);
    }
    const col = getComponent(obj, Collider);
    if (col && !col.isNull()) {
        if (enableCollider) {
            col.method("set_enabled").invoke(true);
            col.method("set_isTrigger").invoke(true);
        } else {
            col.method("set_isTrigger").invoke(true);
        }
    }
    const transform = getTransform(obj);
    if (parent != null) transform.method("SetParent", 2).invoke(parent, false);
    transform.method("set_position").invoke(pos);
    transform.method("set_rotation").invoke(rot);
    transform.method("set_localScale").invoke(scale);
    return obj;
}

    function setRendererColorSafe(obj: any, color: [number, number, number, number]) {
        try {
            if (!obj || obj.isNull?.()) return;
            const renderer = getComponent(obj, Renderer);
            if (!renderer || renderer.isNull?.()) return;
            const material = renderer.method("get_material").invoke();
            if (material && !material.isNull?.()) material.method("set_color").invoke(color);
        } catch(_) {}
    }
    function setTextColorSafe(obj: any, color: [number, number, number, number]) {
        try {
            if (!obj || obj.isNull?.()) return;
            try {
                const tmp = getComponent(obj, TextMeshPro3D);
                if (tmp && !tmp.isNull?.()) {
                    try { tmp.method("set_color").invoke(color); } catch(_) {}
                    return;
                }
            } catch(_) {}
            try {
                const tm = getComponent(obj, TextMesh);
                if (tm && !tm.isNull?.()) {
                    try { tm.method("set_color").invoke(color); } catch(_) {}
                }
            } catch(_) {}
        } catch(_) {}
    }
    let menuThemeLastFrame = 0;
    function updateLiveMenuThemeVisuals() {
        try {
            if (!menu || menu.isNull?.()) return;
            if (frameCount - menuThemeLastFrame < 10) return;
            menuThemeLastFrame = frameCount;
            const gos = menu.method("GetComponentsInChildren", 0).inflate(GameObject).invoke(true);
            if (!gos || gos.isNull?.()) return;
            for (let i = 0; i < gos.length; i++) {
                try {
                    const go = gos.get(i);
                    if (!go || go.isNull?.()) continue;
                    const name = (go.method("get_name").invoke()?.content ?? "").toString();
                    if (name === "MenuBackground") {
                        setRendererColorSafe(go, bgColor);
                    } else if (name.startsWith("@")) {
                        const buttonData = getIndex(name.slice(1));
                        setRendererColorSafe(go, buttonData?.enabled
                            ? [0.02, 0.22, 0.02, 1.0]
                            : [0.0,  0.0,  0.0,  1.0]);
                    } else if (name === "MenuText") {
                        setTextColorSafe(go, textColor);
                    }
                } catch(_) {}
            }
        } catch(_) {}
    }

    function axisDeadzone(value: number, deadzone: number = 0.08) {
        return Math.abs(value) < deadzone ? 0 : value;
    }
    function smoothNumber(current: number, target: number, amount: number = 0.18) {
        return current + ((target - current) * amount);
    }
    function smoothVec3(state: [number, number, number], target: [number, number, number], amount: number = 0.18) {
        state[0] = smoothNumber(state[0], target[0], amount);
        state[1] = smoothNumber(state[1], target[1], amount);
        state[2] = smoothNumber(state[2], target[2], amount);
        return state;
    }
    function readVec3Components(vec: any): [number, number, number] {
        return [
            (vec.field("x").value as number) || 0,
            (vec.field("y").value as number) || 0,
            (vec.field("z").value as number) || 0
        ];
    }
    function normalizeXZ(x: number, z: number): [number, number] {
        const mag = Math.sqrt((x * x) + (z * z));
        if (mag < 0.0001) return [0, 1];
        return [x / mag, z / mag];
    }
    function getPlayerLaunchTransform(player: any, handIndex: number = 1, heldGrabbable: any = null): any {
        try {
            const handAnchor = getPlayerHandAnchorTransform(player, handIndex);
            if (handAnchor && !handAnchor.isNull?.()) return handAnchor;
        } catch(_) {}
        try {
            if (heldGrabbable && !heldGrabbable.isNull?.()) {
                try {
                    const heldTf = getTransform(heldGrabbable);
                    if (heldTf && !heldTf.isNull?.()) return heldTf;
                } catch(_) {}
                try {
                    const heldGo = heldGrabbable.method("get_gameObject").invoke();
                    if (heldGo && !heldGo.isNull?.()) {
                        const heldTf = getTransform(heldGo);
                        if (heldTf && !heldTf.isNull?.()) return heldTf;
                    }
                } catch(_) {}
            }
        } catch(_) {}
        return getPlayerProjectileOriginTransform(player);
    }
    function getPlayerHeadTransform(player: any): any {
        try {
            const head = player.field("headCollider").value;
            if (head && !head.isNull?.()) return getTransform(head);
        } catch(_) {}
        try {
            const playerView = player.method("get_playerView").invoke();
            if (playerView && !playerView.isNull?.()) {
                try {
                    const cameraTransform = playerView.field("_cameraTransform").value;
                    if (cameraTransform && !cameraTransform.isNull?.()) return cameraTransform;
                } catch(_) {}
            }
        } catch(_) {}
        try { return getTransform(player); } catch(_) { return null; }
    }
    function collectAllLobbyItemsWithHeld(): any[] {
        const results = getAllLobbyItemGameObjects();
        const seen = new Set<string>();
        const finalItems: any[] = [];
        for (const item of results) {
            try {
                const key = normalizeSceneObjectHandle(item) || String(item);
                if (!seen.has(key)) {
                    seen.add(key);
                    finalItems.push(item);
                }
            } catch(_) {}
        }
        for (const player of getAllNetPlayersList(true)) {
            for (const handIndex of [0, 1]) {
                try {
                    const held = getPlayerHeldGrabbable(player, handIndex);
                    if (!held || held.isNull?.()) continue;
                    const key = normalizeSceneObjectHandle(held) || String(held);
                    if (!seen.has(key)) {
                        seen.add(key);
                        finalItems.push(held);
                    }
                } catch(_) {}
            }
            try {
                const playerView = player.method("get_playerView").invoke();
                if (playerView && !playerView.isNull?.()) {
                    const pvGo = playerView.method("get_gameObject").invoke();
                    if (pvGo && !pvGo.isNull?.()) {
                        try {
                            const gbis = pvGo.method("GetComponentsInChildren", 0).inflate(GBIClass).invoke(true);
                            if (gbis && !gbis.isNull?.()) {
                                for (let i = 0; i < gbis.length; i++) {
                                    try {
                                        const item = gbis.get(i);
                                        if (!item || item.isNull?.()) continue;
                                        const key = normalizeSceneObjectHandle(item) || String(item);
                                        if (!seen.has(key)) {
                                            seen.add(key);
                                            finalItems.push(item);
                                        }
                                    } catch(_) {}
                                }
                            }
                        } catch(_) {}
                        try {
                            const gbos = pvGo.method("GetComponentsInChildren", 0).inflate(GBOClass).invoke(true);
                            if (gbos && !gbos.isNull?.()) {
                                for (let i = 0; i < gbos.length; i++) {
                                    try {
                                        const item = gbos.get(i);
                                        if (!item || item.isNull?.()) continue;
                                        const key = normalizeSceneObjectHandle(item) || String(item);
                                        if (!seen.has(key)) {
                                            seen.add(key);
                                            finalItems.push(item);
                                        }
                                    } catch(_) {}
                                }
                            }
                        } catch(_) {}
                    }
                }
            } catch(_) {}
        }
        return finalItems;
    }
    function getRootLikeObject(obj: any): any {
        try {
            if (!obj || obj.isNull?.()) return null;
            let go = obj;
            try {
                const maybeGo = obj.method("get_gameObject").invoke();
                if (maybeGo && !maybeGo.isNull?.()) go = maybeGo;
            } catch(_) {}
            try {
                const rootTf = getTransform(go).method("get_root").invoke();
                if (rootTf && !rootTf.isNull?.()) {
                    const rootGo = rootTf.method("get_gameObject").invoke();
                    if (rootGo && !rootGo.isNull?.()) return rootGo;
                }
            } catch(_) {}
            return go;
        } catch(_) {
            return obj;
        }
    }
    function isItemOccupiedByPlayer(item: any): boolean {
        try {
            if (!item || item.isNull?.()) return false;
            const rootKey = normalizeSceneObjectHandle(getRootLikeObject(item)) || normalizeSceneObjectHandle(item);
            for (const player of getAllNetPlayersList(true)) {
                try {
                    for (const handIndex of [0, 1]) {
                        const held = getPlayerHeldGrabbable(player, handIndex);
                        if (!held || held.isNull?.()) continue;
                        const heldKey = normalizeSceneObjectHandle(getRootLikeObject(held)) || normalizeSceneObjectHandle(held);
                        if (rootKey && heldKey && rootKey === heldKey) return true;
                    }
                } catch(_) {}
            }
            try {
                const rootGo = getRootLikeObject(item);
                const inPlayer = rootGo.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                if (inPlayer && !inPlayer.isNull?.()) return true;
            } catch(_) {}
        } catch(_) {}
        return false;
    }
    function tryForceDeveloperMode(): void {
        try {
            const AppClass = AssemblyCSharp.class("AnimalCompany.App");
            const appState = AppClass.method("get_state").invoke();
            if (!appState || appState.isNull?.()) return;
            try {
                const userState = appState.method("get_user").invoke();
                if (userState && !userState.isNull?.()) {
                    try { userState.field("_isDeveloper").value = true; } catch(_) {}
                    try { userState.field("isDeveloper").value = true; } catch(_) {}
                    tryCallNames(userState, ["set_isDeveloper"], 1, true);
                }
            } catch(_) {}
            try {
                const mapMachine = appState.method("get_mapMachine").invoke();
                if (mapMachine && !mapMachine.isNull?.()) {
                    try {
                        const useDevMode = mapMachine.method("get_useDevMode").invoke();
                        if (useDevMode && !useDevMode.isNull?.()) {
                            try { useDevMode.method("set_value").invoke(true); } catch(_) {}
                            try { useDevMode.field("_value").value = true; } catch(_) {}
                            try { useDevMode.field("value").value = true; } catch(_) {}
                        }
                    } catch(_) {}
                    try { mapMachine.field("_useDevMode").value = true; } catch(_) {}
                    tryCallNames(mapMachine, ["set_useDevMode"], 1, true);
                    tryCallNames(mapMachine, ["RefreshDevMode", "Reload", "RefreshButtons", "UpdateButtons", "OpenDevMenu", "OpenDevPanel"], 0);
                }
            } catch(_) {}
        } catch(_) {}
    }
    function spawnHeldItemDuplicateForPlayer(player: any, forwardSpeed: number = 14.0): boolean {
        try {
            if (!player || player.isNull?.()) return false;
            const held = getPlayerHeldGrabbable(player, 1) ?? getPlayerHeldGrabbable(player, 0);
            if (!held || held.isNull?.()) return false;
            const itemId = getGrabbableItemId(held);
            if (!itemId) return false;
            const handTf = getPlayerLaunchTransform(player, getPlayerHeldGrabbable(player, 1) === held ? 1 : 0, held);
            if (!handTf || handTf.isNull?.()) return false;
            const forward = getLaunchForward(handTf, getTransform(player));
            const up = getLaunchUp(handTf, forward);
            const rot = getLaunchRotation(handTf, forward, up);
            const pos = handTf.method("get_position").invoke();
            const spawnPos = Vector3.method("op_Addition").invoke(
                pos,
                Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, 0.42),
                    Vector3.method("op_Multiply", 2).invoke(up, -0.02)
                )
            );
            const spawned = spawnItemAtPos(itemId, spawnPos, rot);
            if (!spawned || spawned.isNull?.()) return false;
            try {
                const srcGbo = held.method("GetComponent", 1).inflate(GBOClass).invoke();
                const dstGbo = spawned.method("GetComponent", 1).inflate(GBOClass).invoke();
                if (srcGbo && !srcGbo.isNull?.() && dstGbo && !dstGbo.isNull?.()) {
                    try { dstGbo.method("set_scaleModifier").invoke(srcGbo.method("get_scaleModifier").invoke()); } catch(_) {}
                    try { dstGbo.method("set_colorHue").invoke(srcGbo.method("get_colorHue").invoke()); } catch(_) {}
                    try { dstGbo.method("set_colorSaturation").invoke(srcGbo.method("get_colorSaturation").invoke()); } catch(_) {}
                    try { dstGbo.field("_scaleModifier").value = srcGbo.field("_scaleModifier").value; } catch(_) {}
                    try { dstGbo.field("_colorHue").value = srcGbo.field("_colorHue").value; } catch(_) {}
                    try { dstGbo.field("_colorSaturation").value = srcGbo.field("_colorSaturation").value; } catch(_) {}
                }
            } catch(_) {}
            trySetObjectVelocity(spawned, Vector3.method("op_Addition").invoke(
                Vector3.method("op_Multiply", 2).invoke(forward, forwardSpeed),
                Vector3.method("op_Multiply", 2).invoke(up, 0.7)
            ));
            return true;
        } catch(_) {
            return false;
        }
    }
    function spawnHeldItemEjectBurstForPlayer(player: any, burstCount: number = 3): boolean {
        try {
            if (!player || player.isNull?.()) return false;
            const held = getPlayerHeldGrabbable(player, 1) ?? getPlayerHeldGrabbable(player, 0);
            if (!held || held.isNull?.()) return false;
            const itemId = getGrabbableItemId(held);
            if (!itemId) return false;
            const handIndex = getPlayerHeldGrabbable(player, 1) === held ? 1 : 0;
            const handTf = getPlayerLaunchTransform(player, handIndex, held);
            if (!handTf || handTf.isNull?.()) return false;
            const straightForward = getPlayerStraightForward(player);
            const up: [number, number, number] = [0, 1, 0];
            const basePos = handTf.method("get_position").invoke();
            const rot = getLookRotationFromForward(straightForward);
            let spawnedAny = false;
            for (let i = 0; i < burstCount; i++) {
                try {
                    const side = ((i % 2 === 0) ? -1 : 1) * (0.03 + (i * 0.015));
                    const spawnPos = [
                        (basePos.field("x").value as number) + (straightForward[0] * 0.24),
                        (basePos.field("y").value as number) - 0.02 + (i * 0.01),
                        (basePos.field("z").value as number) + (straightForward[2] * 0.24) + side
                    ];
                    const spawned = spawnItemAtPos(itemId, spawnPos, rot);
                    if (!spawned || spawned.isNull?.()) continue;
                    spawnedAny = true;
                    try {
                        const srcGbo = held.method("GetComponent", 1).inflate(GBOClass).invoke();
                        const dstGbo = spawned.method("GetComponent", 1).inflate(GBOClass).invoke();
                        if (srcGbo && !srcGbo.isNull?.() && dstGbo && !dstGbo.isNull?.()) {
                            try { dstGbo.method("set_scaleModifier").invoke(srcGbo.method("get_scaleModifier").invoke()); } catch(_) {}
                            try { dstGbo.method("set_colorHue").invoke(srcGbo.method("get_colorHue").invoke()); } catch(_) {}
                            try { dstGbo.method("set_colorSaturation").invoke(srcGbo.method("get_colorSaturation").invoke()); } catch(_) {}
                        }
                    } catch(_) {}
                    trySetObjectVelocity(spawned, [
                        straightForward[0] * (7.0 + (i * 0.45)),
                        0.6 + (i * 0.08),
                        straightForward[2] * (7.0 + (i * 0.45))
                    ]);
                } catch(_) {}
            }
            return spawnedAny;
        } catch(_) {
            return false;
        }
    }
    function pulseWeaponSecondary(grabbable: any) {
        for (let i = 0; i < 6; i++) {
            tryCallNames(grabbable, ["HandleSecondaryUse", "HandleGripUse", "CockHammer", "PullBackHammer", "HandleSecondaryPress", "PressBButton"], 0);
            tryCallNames(grabbable, ["HandleSecondaryButton", "HandleSecondaryUse", "HandleGripUse", "CockHammer", "PullBackHammer", "HandleSecondaryPress", "PressBButton"], 1, true);
            tryCallNames(grabbable, ["OnSecondaryButtonDown", "OnSecondaryUseDown", "OnBButtonDown", "HandleBButtonDown"], 0);
            tryCallNames(grabbable, ["HandleSecondaryButton", "HandleSecondaryUse", "HandleGripUse", "HandleSecondaryPress", "HandleBButton"], 1, false);
            tryCallNames(grabbable, ["OnSecondaryButtonUp", "OnSecondaryUseUp", "OnBButtonUp", "HandleBButtonUp"], 0);
        }
    }
    function applyGunBuffsToGrabbable(grabbable: any, pulseFire: boolean = false) {
        try {
            if (!grabbable || grabbable.isNull?.()) return false;
            if (!grabbableLooksLikeGun(grabbable)) return false;
            const heldClassName = String(grabbable.class?.type?.name ?? "").toLowerCase();
            const isRevolverLike = heldClassName.indexOf("revolver") >= 0;
            const isRpgLike = heldClassName.indexOf("rpg") >= 0 || heldClassName.indexOf("rocket") >= 0 || heldClassName.indexOf("flare") >= 0 || heldClassName.indexOf("zipline") >= 0;
            try { grabbable.field("_ammoLoaded").value = 255; } catch(_) {}
            try { grabbable.field("ammoLoaded").value = 255; } catch(_) {}
            try { grabbable.field("_ammo").value = 255; } catch(_) {}
            try { grabbable.field("ammo").value = 255; } catch(_) {}
            try { grabbable.field("_isHammerCocked").value = true; } catch(_) {}
            try { grabbable.field("_isCocked").value = true; } catch(_) {}
            try { grabbable.field("isHammerCocked").value = true; } catch(_) {}
            try { grabbable.field("_hasAmmo").value = true; } catch(_) {}
            try { grabbable.field("hasAmmo").value = true; } catch(_) {}
            try { grabbable.field("_isLoaded").value = true; } catch(_) {}
            try { grabbable.field("isLoaded").value = true; } catch(_) {}
            try { grabbable.field("_nextUseTime").value = 0.0; } catch(_) {}
            try { grabbable.field("_reloadTimer").value = 0.0; } catch(_) {}
            try { grabbable.field("_reloadCooldown").value = 0.0; } catch(_) {}
            try { grabbable.field("_shotCooldown").value = 0.0; } catch(_) {}
            try { grabbable.field("_timeBetweenShots").value = 0.0; } catch(_) {}
            try { grabbable.field("_useCooldown").value = 0.0; } catch(_) {}
            try { grabbable.field("_secondaryUseCooldown").value = 0.0; } catch(_) {}
            try { grabbable.field("_triggerUseCooldown").value = 0.0; } catch(_) {}
            try { grabbable.field("_hammerPullbackAmount").value = 1.0; } catch(_) {}
            try { grabbable.field("_recoilCooldown").value = 0.0; } catch(_) {}
            try { grabbable.field("recoilForceMag").value = 0.0; } catch(_) {}
            try { grabbable.field("_recoilForceMag").value = 0.0; } catch(_) {}
            try { grabbable.method("set_isHammerCocked").invoke(true); } catch(_) {}
            try { grabbable.method("set_ammoLoaded").invoke(255); } catch(_) {}
            try { grabbable.method("set_hasAmmo").invoke(true); } catch(_) {}
            try { grabbable.method("set_isLoaded").invoke(true); } catch(_) {}
            if (isRpgLike) {
                try {
                    const loadedState = grabbable.method("get_loadedState").invoke();
                    if (loadedState && !loadedState.isNull?.()) {
                        try { loadedState.field("isLoaded").value = true; } catch(_) {}
                        try { loadedState.field("_isLoaded").value = true; } catch(_) {}
                        try { grabbable.method("set_loadedState").invoke(loadedState); } catch(_) {}
                    }
                } catch(_) {}
            }
            pulseWeaponSecondary(grabbable);
            if (pulseFire) {
                for (let i = 0; i < (isRevolverLike ? 3 : 2); i++) {
                    try { grabbable.method("HandleTriggerUse").invoke(); } catch(_) {}
                }
                tryCallNames(grabbable, ["HandlePrimaryUse", "HandlePrimaryButton", "OnPrimaryButtonDown"], 0);
                tryCallNames(grabbable, ["HandlePrimaryButton"], 1, true);
                tryCallNames(grabbable, ["HandlePrimaryButton"], 1, false);
                pulseWeaponSecondary(grabbable);
            }
            try {
                const cfg = grabbable.method("get_config").invoke();
                if (cfg && !cfg.isNull?.()) {
                    try { cfg.field("recoilForceMag").value = 0.0; } catch(_) {}
                    try { cfg.field("handRecoilForceMag").value = 0.0; } catch(_) {}
                    try { cfg.field("shotSpread").value = 0.0; } catch(_) {}
                    try { cfg.field("shotSpreadMin").value = 0.0; } catch(_) {}
                    try { cfg.field("shotSpreadMax").value = 0.0; } catch(_) {}
                    try { cfg.field("ammoLoaded").value = 255; } catch(_) {}
                    try { cfg.field("ammo").value = 255; } catch(_) {}
                    try { cfg.field("hasAmmo").value = true; } catch(_) {}
                    try { cfg.field("isLoaded").value = true; } catch(_) {}
                    try { cfg.field("reloadTime").value = 0.0; } catch(_) {}
                    try { cfg.field("timeBetweenShots").value = 0.0; } catch(_) {}
                    try { cfg.field("useCooldown").value = 0.0; } catch(_) {}
                    try { cfg.field("secondaryUseCooldown").value = 0.0; } catch(_) {}
                }
            } catch(_) {}
            return true;
        } catch(_) {
            return false;
        }
    }
    function spawnGoopBurstAtTransform(sourceTransform: any, hue: number = 18, saturation: number = 96, count: number = 2, expireAfter: number = 2.2, velocityScale: number = 8.8) {
        try {
            if (!sourceTransform || sourceTransform.isNull?.()) return;
            const pos = sourceTransform.method("get_position").invoke();
            const forwardVec = readVec3Components(sourceTransform.method("get_forward").invoke());
            const [fx, fz] = normalizeXZ(forwardVec[0], forwardVec[2]);
            for (let i = 0; i < count; i++) {
                const spawnPos = [
                    (pos.field("x").value as number) + (fx * 0.14) + ((Math.random() * 0.05) - 0.025),
                    (pos.field("y").value as number) - 0.28 + ((Math.random() * 0.02) - 0.01),
                    (pos.field("z").value as number) + (fz * 0.14) + ((Math.random() * 0.05) - 0.025)
                ];
                const goop = spawnItemAtPos("item_goop", spawnPos, identityQuaternion);
                if (!goop || goop.isNull?.()) continue;
                spawnedGoopObjects.push({ object: goop, expireAt: time + expireAfter });
                try { goop.method("set_colorHue").invoke(hue); } catch(_) {}
                try { goop.method("set_colorSaturation").invoke(saturation); } catch(_) {}
                try {
                    const goopGo = goop.method("get_gameObject").invoke();
                    if (goopGo && !goopGo.isNull?.()) {
                        try {
                            const gbo = goopGo.method("GetComponent", 1).inflate(GBOClass).invoke();
                            if (gbo && !gbo.isNull?.()) {
                                try { gbo.method("set_colorHue").invoke(hue); } catch(_) {}
                                try { gbo.method("set_colorSaturation").invoke(saturation); } catch(_) {}
                            }
                        } catch(_) {}
                        try {
                            const renderer = getComponent(goopGo, Renderer);
                            if (renderer && !renderer.isNull?.()) {
                                const material = renderer.method("get_material").invoke();
                                if (material && !material.isNull?.()) {
                                    material.method("set_color").invoke([1.0, 0.95, 0.12, 1.0]);
                                }
                            }
                        } catch(_) {}
                    }
                } catch(_) {}
                trySetObjectVelocity(goop, [
                    (fx * velocityScale) + ((Math.random() * 0.95) - 0.475),
                    -1.0 + (Math.random() * 0.35),
                    (fz * velocityScale) + ((Math.random() * 0.95) - 0.475)
                ]);
            }
        } catch(_) {}
    }
    function createSolidPlatform(pos: any, scale: [number, number, number] = [0.35, 0.03, 0.35], color: [number, number, number, number] = [1.0, 0.55, 0.08, 0.9]) {
        const obj = createObject(pos, identityQuaternion, scale, 3, color, null, true);
        try {
            const col = getComponent(obj, Collider);
            if (col && !col.isNull()) {
                col.method("set_enabled").invoke(true);
                col.method("set_isTrigger").invoke(false);
            }
        } catch(_) {}
        return obj;
    }

    function renderMenuText(textRootObject, surfaceObject, text: string = "", color: [number, number, number, number] = [1, 1, 1, 1], pos = zeroVector, size = oneVector) {
        if (!TextMesh && !TextMeshPro3D) {
            if (!menuFontWarned) {
                menuFontWarned = true;
                console.error("[G2] No TextMesh/TextMeshPro class on this build; skipping menu text");
            }
            return;
        }
        const textObj = createEmptyObject("MenuText", getTransform(textRootObject));
        const widthFactor = Math.max(size?.[0] ?? 1.0, 0.2);
        const heightFactor = Math.max((size?.[1] ?? 0.1) / 0.1, 0.6);
        const textLen = Math.max((text ?? "").trim().length, 1);
        const isButtonLabel = widthFactor <= 0.9;
        const lengthFactor = isButtonLabel
            ? Math.max(0.55, Math.min(1.0, 10.5 / textLen))
            : Math.max(0.55, Math.min(1.0, 20.0 / textLen));
        const finalScale = (isButtonLabel ? 0.028 : 0.018) * heightFactor * lengthFactor;
        if (TextMeshPro3D) {
            const title = addComponent(textObj, TextMeshPro3D);
            const tmpFont = gettmpfontnocrash();
            if (tmpFont && !tmpFont.isNull()) {
                try { title.method("set_font").invoke(tmpFont); } catch(_) {}
                try {
                    const textRenderer = getComponent(textObj, Renderer);
                    if (textRenderer && !textRenderer.isNull()) {
                        textRenderer.method("set_enabled").invoke(true);
                        try { textRenderer.method("set_sharedMaterial").invoke(tmpFont.method("get_material").invoke()); }
                        catch(_) { try { textRenderer.method("set_material").invoke(tmpFont.method("get_material").invoke()); } catch(_) {} }
                    }
                } catch(_) {}
            }
            try { title.method("SetText", 1).invoke(Il2Cpp.string(text)); }
            catch(_) { try { title.method("set_text").invoke(Il2Cpp.string(text)); } catch(_) {} }
            try { title.method("set_fontSize").invoke((isButtonLabel ? 4.5 : 3.0) * heightFactor); } catch(_) {}
            try { title.method("set_color").invoke(color); } catch(_) {}
            try { title.method("set_alignment").invoke(514); } catch(_) {}
            try { title.method("set_enableWordWrapping").invoke(false); } catch(_) {}
            try { title.method("ForceMeshUpdate", 0).invoke(); } catch(_) {}
        } else {
            const font = getarialnocrash2();
            if (!font || font.isNull()) {
                if (!menuFontWarned) {
                    menuFontWarned = true;
                    console.error("[G2] Builtin font load failed; skipping menu text to avoid freeze");
                }
                return;
            }
            const title = addComponent(textObj, TextMesh);
            title.method("set_font").invoke(font);
            title.method("set_text").invoke(Il2Cpp.string(text));
            try { title.method("set_fontSize").invoke(isButtonLabel ? 120 : 100); } catch(_) {}
            try { title.method("set_characterSize").invoke((isButtonLabel ? 0.03 : 0.022) * heightFactor); } catch(_) {}
            try { title.method("set_anchor").invoke(4); } catch(_) {}
            try { title.method("set_alignment").invoke(1); } catch(_) {}
            try { title.method("set_color").invoke(color); } catch(_) {}
            try {
                const textRenderer = getComponent(textObj, Renderer);
                if (textRenderer && !textRenderer.isNull()) {
                    textRenderer.method("set_enabled").invoke(true);
                    try { textRenderer.method("set_sharedMaterial").invoke(font.method("get_material").invoke()); }
                    catch(_) { try { textRenderer.method("set_material").invoke(font.method("get_material").invoke()); } catch(_) {} }
                }
            } catch(_) {}
        }
        const textTransform = getTransform(textObj);
        try {
            const anchorPos = [(pos?.[0] ?? 0) + 0.0125, pos?.[1] ?? 0, pos?.[2] ?? 0];
            const worldAnchor = getTransform(surfaceObject).method("TransformPoint", 1).invoke(anchorPos);
            textTransform.method("set_position").invoke(worldAnchor);
        } catch(_) {
            textTransform.method("set_localPosition").invoke(pos);
        }
        try {
            const surfaceRotation = getTransform(surfaceObject).method("get_rotation").invoke();
            const faceRotation = Quaternion.method("op_Multiply").invoke(
                surfaceRotation,
                Quaternion.method("Euler").invoke(0.0, 90.0, 90.0)
            );
            textTransform.method("set_rotation").invoke(faceRotation);
        } catch(_) {
            textTransform.method("set_localRotation").invoke(Quaternion.method("Euler").invoke(0.0, 90.0, 90.0));
        }
        setMenuTextScale(textTransform, menu, finalScale);
    }

    function updateButtonColor(button, buttonData) {
        const RendererClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
        const renderer = getComponent(button, RendererClass);
        if (!renderer) return;
        const material = renderer.method("get_material").invoke();
        const col: [number, number, number, number] = buttonData.enabled
            ? [0.02, 0.22, 0.02, 1.0]   // active — dark green
            : [0.0,  0.0,  0.0,  1.0];  // inactive — pure black
        material.method("set_color").invoke(col);
    }

    function reloadMenu() {
        try {
            if (menu != null && !menu.isNull?.()) {
                Object.method("Destroy", 1).invoke(menu);
                menu = null;
            }
        } catch(_) {}
        menuSnapNextFrame = true;
        try {
            if ((righthand && rightSecondary) || (!righthand && leftSecondary)) {
                renderMenu();
            }
        } catch(_) {}
    }
    let gunLocked = false;
    let lockTarget = null;
    let GunPointer = null;
    let GunLine = null;
    function renderMenuTextRet(textRootObject, surfaceObject, text: string = "", color: [number, number, number, number] = [1, 1, 1, 1], pos = zeroVector, size = oneVector): any {
        renderMenuText(textRootObject, surfaceObject, text, color, pos, size);
        // return last created MenuText child
        try {
            const root = getTransform(textRootObject);
            const count = root.method("get_childCount").invoke() as number;
            if (count > 0) return root.method("GetChild").invoke(count - 1).method("get_gameObject").invoke();
        } catch(_) {}
        return null;
    }

    function renderMenu() {
        applyMenuStructurePatches();
        menuSnapNextFrame = true;
        menu = createObject(zeroVector, identityQuaternion, [0.1, 0.3, 0.3825], 3, [0, 0, 0, 0]);
        try { menu.method("set_name").invoke(Il2Cpp.string("MenuRoot")); } catch(_) {}
        Destroy(getComponent(menu, BoxCollider));

        const menuBackground = createObject([0.1, 0, 0], identityQuaternion, [0.1, 1, 1], 3, bgColor, getTransform(menu));
        try { menuBackground.method("set_name").invoke(Il2Cpp.string("MenuBackground")); } catch(_) {}
        Destroy(getComponent(menuBackground, BoxCollider));
        // no outline on background — that was the big green plane

        const textRootObject = createEmptyObject("MenuTextRoot", getTransform(menu));

        // queue matrix chars for gradual creation in update loop — no spike
        matrixSetupQueue = [];
        matrixRainObjs = [];
        matrixBtnObjs = [];
        const rainChars = ["0","1","0","1","1","0","0","1","0","1"];
        // background chars
        const cols = 8; const rows = 12;
        for (let col = 0; col < cols; col++) {
            for (let row = 0; row < rows; row++) {
                matrixSetupQueue.push({
                    textRoot: textRootObject, surface: menuBackground,
                    char: rainChars[Math.floor(Math.random() * rainChars.length)],
                    color: [0.0, 0.55 + Math.random() * 0.45, 0.0, 0.85] as [number,number,number,number],
                    pos: [0.501, -0.42 + (col/(cols-1))*0.84, -0.44 + (row/(rows-1))*0.88],
                    size: [0.08, 0.055], isBg: true
                });
            }
        }
        renderMenuText(textRootObject, menuBackground, "[G2]", [0.0, 1.0, 0.18, 1.0], [0.501, 0, 0.365], [0.85, 0.06]);

        // — G2 Menu header (transparent bg, white bold text)
        const menuHeaderSurface = createObject([0.105, 0, 0.175], identityQuaternion, [0.09, 0.9, 0.055], 3, [0.0, 0.0, 0.0, 0.0], getTransform(menu));
        try { menuHeaderSurface.method("set_name").invoke(Il2Cpp.string("MenuHeader")); } catch(_) {}
        Destroy(getComponent(menuHeaderSurface, BoxCollider));
        renderMenuText(textRootObject, menuHeaderSurface, menuName, [1.0, 1.0, 1.0, 1.0], [0.501, 0, 0], [0.88, 0.1]);

        // — disconnect / notification button
        const disconnectButton = createObject([0.1, 0.0, 0.225], identityQuaternion, [0.09, 0.9, 0.08], 3, [0.0, 0.0, 0.0, 0.97], getTransform(menu), true);
        disconnectButton.method("set_name").invoke(Il2Cpp.string("@Disconnect"));
        addComponent(disconnectButton, GorillaReportButton);
        getComponent(disconnectButton, BoxCollider).method("set_isTrigger").invoke(true);
        renderMenuText(textRootObject, disconnectButton, "// DISCONNECT", [0.0, 1.0, 0.18, 1.0], [0.501, 0, 0], [0.82, 0.095]);
        if (time > notifactionResetTime) currentNotification = "";
        renderMenuText(textRootObject, disconnectButton, currentNotification, [0.0, 1.0, 0.18, 1.0], [0.501, 0, 0.88], [0.74, 0.13]);
        for (let bc = 0; bc < 5; bc++) {
            const capturedBtn = disconnectButton;
            matrixSetupQueue.push({ textRoot: textRootObject, surface: capturedBtn, char: bc % 2 === 0 ? "0" : "1", color: [0.0, 0.6, 0.1, 0.9] as [number,number,number,number], pos: [0.501, -0.35 + bc * 0.18, 0], size: [0.09, 0.05], isBg: false });
        }

        // — return button
        const returnButton = createObject([0.1, -0.175, -0.225], identityQuaternion, [0.09, 0.09, 0.09], 3, [0.0, 0.0, 0.0, 0.97], getTransform(menu));
        returnButton.method("set_name").invoke(Il2Cpp.string("@GlobalReturn"));
        addComponent(returnButton, GorillaReportButton);
        getComponent(returnButton, BoxCollider).method("set_isTrigger").invoke(true);
        renderMenuText(textRootObject, returnButton, "<", [0.0, 1.0, 0.18, 1.0], [0.501, 0, 0], [0.35, 0.11]);

        // — prev page
        {
            const pageButton = createObject([0.1, 0.2, 0], identityQuaternion, [0.09, 0.2, 0.9], 3, [0.0, 0.0, 0.0, 0.97], getTransform(menu));
            pageButton.method("set_name").invoke(Il2Cpp.string("@PreviousPage"));
            addComponent(pageButton, GorillaReportButton);
            getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(textRootObject, pageButton, "<", [0.0, 1.0, 0.18, 1.0], [0.501, 0, 0], [0.35, 0.11]);
            for (let bc = 0; bc < 4; bc++) {
                const capturedBtn = pageButton;
                matrixSetupQueue.push({ textRoot: textRootObject, surface: capturedBtn, char: bc % 2 === 0 ? "1" : "0", color: [0.0, 0.6, 0.1, 0.9] as [number,number,number,number], pos: [0.501, -0.3 + bc * 0.2, 0], size: [0.09, 0.05], isBg: false });
            }
        }
        // — next page
        {
            const pageButton = createObject([0.1, -0.2, 0], identityQuaternion, [0.09, 0.2, 0.9], 3, [0.0, 0.0, 0.0, 0.97], getTransform(menu));
            pageButton.method("set_name").invoke(Il2Cpp.string("@NextPage"));
            addComponent(pageButton, GorillaReportButton);
            getComponent(pageButton, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(textRootObject, pageButton, ">", [0.0, 1.0, 0.18, 1.0], [0.501, 0, 0], [0.35, 0.11]);
            for (let bc = 0; bc < 4; bc++) {
                const capturedBtn = pageButton;
                matrixSetupQueue.push({ textRoot: textRootObject, surface: capturedBtn, char: bc % 2 === 0 ? "0" : "1", color: [0.0, 0.6, 0.1, 0.9] as [number,number,number,number], pos: [0.501, -0.3 + bc * 0.2, 0], size: [0.09, 0.05], isBg: false });
            }
        }

        // — menu buttons
        let i = 0;
        const targetMods = buttons[currentCategory].slice(currentPage * 8).slice(0, 8);
        targetMods.forEach((buttonData) => {
            const isEnabled = buttonData.enabled;
            const btnBg: [number, number, number, number] = isEnabled ? [0.0, 0.18, 0.04, 1.0] : [0.0, 0.0, 0.0, 0.97];
            const button = createObject([0.105, 0, 0.13 - (i * 0.04)], identityQuaternion, [0.09, 0.9, 0.08], 3, btnBg, getTransform(menu));
            button.method("set_name").invoke(Il2Cpp.string("@" + buttonData.buttonText));
            addComponent(button, GorillaReportButton);
            getComponent(button, BoxCollider).method("set_isTrigger").invoke(true);
            renderMenuText(textRootObject, button, buttonData.buttonText,
                isEnabled ? [0.0, 1.0, 0.22, 1.0] : [0.0, 0.9, 0.18, 1.0],
                [0.501, 0, 0], [0.82, 0.095]);
            updateButtonColor(button, buttonData);
            // queue 3 matrix chars per button
            for (let bc = 0; bc < 3; bc++) {
                const capturedButton = button;
                matrixSetupQueue.push({
                    textRoot: textRootObject, surface: capturedButton,
                    char: bc % 2 === 0 ? "0" : "1",
                    color: [0.0, 0.7, 0.1, 0.9] as [number,number,number,number],
                    pos: [0.501, -0.25 + bc * 0.25, 0],
                    size: [0.09, 0.055], isBg: false
                });
            }
            i++;
        });

        getTransform(menu).method("set_localScale").invoke(
            Vector3.method("op_Multiply").invoke(
                Vector3.method("op_Multiply").invoke(getTransform(menu).method("get_localScale").invoke(), GTPlayer.field("<playerScale>k__BackingField").value),
                menuscale
            )
        );
        recenterMenu();
    }

    function renderReference() {
        if (righthand) {
            reference = createObject(zeroVector, identityQuaternion, [0.01, 0.01, 0.01], 0, bgColor, leftHandTransform);
        } else {
            reference = createObject(zeroVector, identityQuaternion, [0.01, 0.01, 0.01], 0, bgColor, rightHandTransform);
        }
        referenceCollider = getComponent(reference, Collider);
        getTransform(reference).method("set_localPosition").invoke([0.01, -0.117, 0.05]);
        reference.method("set_layer").invoke(2);
        addComponent(reference, Rigidbody).method("set_isKinematic").invoke(true);
    }
    let physicsRaycastAllVec4: any = null;
    let physicsRaycastOutVec4: any = null;
    let physicsRaycastOutVec5: any = null;
    function renderGun(overrideLayerMask = null) {
        const StartPosition = rightHandTransform.method("get_position").invoke();
        const Direction = getGunAimDirection();

        const rayStartPosition = Vector3.method("op_Addition").invoke(
            StartPosition,
            Vector3.method("op_Multiply").invoke(Direction, 0.08)
        );

        const layerMask = overrideLayerMask ?? -1;
        let finalRay = null;
        try {
            if (!physicsRaycastAllVec4) {
                physicsRaycastAllVec4 = Physics.method("RaycastAll").overload(
                    "UnityEngine.Vector3",
                    "UnityEngine.Vector3",
                    "System.Single",
                    "System.Int32"
                );
            }
            const hits = physicsRaycastAllVec4.invoke(rayStartPosition, Direction, 512.0, layerMask);
            if (hits && !hits.isNull() && hits.length > 0) {
                let bestDistance = Number.POSITIVE_INFINITY;
                for (let i = 0; i < hits.length; i++) {
                    try {
                        const hit = hits.get(i);
                        if (!hit || hit.isNull?.()) continue;
                        const hitCollider = hit.method("get_collider").invoke();
                        if (!hitCollider || hitCollider.isNull()) continue;
                        const hitPoint = hit.method("get_point").invoke();
                        const distance = Vector3.method("Distance").invoke(hitPoint, StartPosition) as number;
                        if (distance < 0.08 || distance >= bestDistance) continue;
                        bestDistance = distance;
                        finalRay = hit;
                    } catch(_) {}
                }
            }
        } catch(_) {}

        if (!finalRay) {
            try {
                const hitBuf = Il2Cpp.alloc(128);
                if (!physicsRaycastOutVec4) {
                    physicsRaycastOutVec4 = Physics.method("Raycast").overload(
                        "UnityEngine.Vector3",
                        "UnityEngine.Vector3",
                        "UnityEngine.RaycastHit&",
                        "System.Single"
                    );
                }
                if (!physicsRaycastOutVec5) {
                    physicsRaycastOutVec5 = Physics.method("Raycast").overload(
                        "UnityEngine.Vector3",
                        "UnityEngine.Vector3",
                        "UnityEngine.RaycastHit&",
                        "System.Single",
                        "System.Int32"
                    );
                }
                const didHit = overrideLayerMask == null
                    ? physicsRaycastOutVec4.invoke(rayStartPosition, Direction, hitBuf, 512.0)
                    : physicsRaycastOutVec5.invoke(rayStartPosition, Direction, hitBuf, 512.0, layerMask);
                if (didHit) {
                    const hitRef = Il2Cpp.reference(hitBuf);
                    const hitPoint = hitRef.method("get_point").invoke();
                    const distance = Vector3.method("Distance").invoke(hitPoint, StartPosition) as number;
                    if (distance >= 0.08) finalRay = hitRef;
                }
            } catch(_) {}
        }

        if (finalRay) {
            try {
                finalRay.method("get_point").invoke();
            } catch(_) {}
        }

        let EndPosition;
        if (gunLocked) {
            EndPosition = getTransform(lockTarget).method("get_position").invoke();
        } else {
            if (finalRay && !(finalRay.isNull?.() ?? false)) {
                EndPosition = finalRay.method("get_point").invoke();
            } else {
                const farDirection = Vector3.method("op_Multiply").invoke(Direction, 512);
                EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
            }
        }

        if (Vector3.method("op_Equality").invoke(EndPosition, zeroVector)) {
            const farDirection = Vector3.method("op_Multiply").invoke(Direction, 512);
            EndPosition = Vector3.method("op_Addition").invoke(StartPosition, farDirection);
        }

        if (GunPointer == null || GunPointer.isNull?.()) {
            GunPointer = createObject(EndPosition, identityQuaternion, [0.1, 0.1, 0.1], 0, [1, 1, 1, 1]);
        }

        GunPointer.method("SetActive").invoke(true);
        const pointerTransform = getTransform(GunPointer);
        pointerTransform.method("set_position").invoke(EndPosition);

        const PointerRenderer = getComponent(GunPointer, Renderer);
        const material = PointerRenderer.method("get_material").invoke();

        material.method("set_shader").invoke(TextShader);

        const pointerColor = (gunLocked || rightTrigger) ? buttonPressedColor : buttonColor;
        material.method("set_color").invoke(pointerColor);

        const collider = getComponent(GunPointer, Collider);
        if (collider != null) {
            Destroy(collider);
        }

        if (GunLine == null || GunLine.isNull?.()) {
            const lineObj = createObject(zeroVector, identityQuaternion, oneVector, 0, [0, 0, 0, 0]);
            GunLine = addComponent(lineObj, LineRenderer);
        } else {
            GunLine.method("get_gameObject").invoke().method("SetActive").invoke(true);
        }

        const lineMaterial = GunLine.method("get_material").invoke();
        lineMaterial.method("set_shader").invoke(TextShader);

        GunLine.method("set_startColor").invoke(bgColor);
        GunLine.method("set_endColor").invoke(bgColor);

        const lineWidth = 0.025;
        GunLine.method("set_startWidth").invoke(lineWidth);
        GunLine.method("set_endWidth").invoke(lineWidth);

        GunLine.method("set_positionCount").invoke(2);
        GunLine.method("set_useWorldSpace").invoke(true);

        

        GunLine.method("SetPosition").invoke(0, StartPosition);
        GunLine.method("SetPosition").invoke(1, EndPosition);

        if (rightTrigger || gunLocked) {
            const Step = 34;
            GunLine.method("set_positionCount").invoke(Step);
            GunLine.method("SetPosition").invoke(0, StartPosition);
            const dirVec = readVec3Components(Direction);
            const dirMag = Math.sqrt((dirVec[0] * dirVec[0]) + (dirVec[1] * dirVec[1]) + (dirVec[2] * dirVec[2])) || 1;
            const dirNorm: [number, number, number] = [dirVec[0] / dirMag, dirVec[1] / dirMag, dirVec[2] / dirMag];
            let upBasis: [number, number, number] = [0, 1, 0];
            if (Math.abs(dirNorm[1]) > 0.92) upBasis = [1, 0, 0];
            let side: [number, number, number] = [
                (upBasis[1] * dirNorm[2]) - (upBasis[2] * dirNorm[1]),
                (upBasis[2] * dirNorm[0]) - (upBasis[0] * dirNorm[2]),
                (upBasis[0] * dirNorm[1]) - (upBasis[1] * dirNorm[0])
            ];
            let sideMag = Math.sqrt((side[0] * side[0]) + (side[1] * side[1]) + (side[2] * side[2])) || 1;
            side = [side[0] / sideMag, side[1] / sideMag, side[2] / sideMag];
            let swirlUp: [number, number, number] = [
                (dirNorm[1] * side[2]) - (dirNorm[2] * side[1]),
                (dirNorm[2] * side[0]) - (dirNorm[0] * side[2]),
                (dirNorm[0] * side[1]) - (dirNorm[1] * side[0])
            ];
            let swirlUpMag = Math.sqrt((swirlUp[0] * swirlUp[0]) + (swirlUp[1] * swirlUp[1]) + (swirlUp[2] * swirlUp[2])) || 1;
            swirlUp = [swirlUp[0] / swirlUpMag, swirlUp[1] / swirlUpMag, swirlUp[2] / swirlUpMag];

            for (let i = 1; i < (Step - 1); i++) {
                const t = i / (Step - 1);
                const Position = Vector3.method("Lerp").invoke(StartPosition, EndPosition, t);
                const swirlAngle = (time * 9.0) + (t * Math.PI * 10.0);
                const swirlFade = Math.sin(t * Math.PI);
                const swirlRadius = (0.018 + (Math.sin((t * Math.PI * 2.0) + (time * 2.4)) * 0.004)) * swirlFade;
                const offset = [
                    (side[0] * Math.cos(swirlAngle) + swirlUp[0] * Math.sin(swirlAngle)) * swirlRadius,
                    (side[1] * Math.cos(swirlAngle) + swirlUp[1] * Math.sin(swirlAngle)) * swirlRadius,
                    (side[2] * Math.cos(swirlAngle) + swirlUp[2] * Math.sin(swirlAngle)) * swirlRadius
                ];
                const finalPosition = Vector3.method("op_Addition").invoke(Position, offset);
                GunLine.method("SetPosition").invoke(i, finalPosition);
            }

            GunLine.method("SetPosition").invoke(Step - 1, EndPosition);
        }

        return { ray: finalRay ?? NullObject, gunPointer: GunPointer, endPosition: EndPosition };
    }

    function getAllNetPlayersList(includeLocal: boolean = true): any[] {
        const players: any[] = [];
        try {
            const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
            if (!playerDict || playerDict.isNull()) return players;
            const vals = playerDict.method("get_Values").invoke();
            const en = vals.method("GetEnumerator").invoke();
            while (en.method("MoveNext").invoke()) {
                const p = en.method("get_Current").invoke();
                if (!p || p.isNull?.()) continue;
                if (!includeLocal && playerIsLocal(p)) continue;
                players.push(p);
            }
        } catch(_) {}
        return players;
    }

    function resolveGunTargetPlayer(gunData: any, maxDistance: number = 8.0): any {
        if (!gunData) return null;
        try {
            const ray = gunData.ray;
            if (ray && !(ray.handle?.isNull?.() ?? true)) {
                try {
                    const hitCollider = ray.method("get_collider").invoke();
                    if (hitCollider && !hitCollider.isNull()) {
                        try {
                            const directPlayer = hitCollider.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                            if (directPlayer && !directPlayer.isNull()) return directPlayer;
                        } catch(_) {}
                        try {
                            const hitGO = hitCollider.method("get_gameObject").invoke();
                            if (hitGO && !hitGO.isNull()) {
                                const hitPlayer = hitGO.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                                if (hitPlayer && !hitPlayer.isNull()) return hitPlayer;
                            }
                        } catch(_) {}
                    }
                } catch(_) {}
            }
        } catch(_) {}

        try {
            const pointerPos = getTransform(gunData.gunPointer).method("get_position").invoke();
            let nearest = null;
            let nearestDist = maxDistance;
            for (const p of getAllNetPlayersList(false)) {
                try {
                    const pPos = getTransform(p).method("get_position").invoke();
                    const dist = Vector3.method("Distance").invoke(pointerPos, pPos) as number;
                    if (dist < nearestDist) {
                        nearestDist = dist;
                        nearest = p;
                    }
                } catch(_) {}
            }
            return nearest;
        } catch(_) {
            return null;
        }
    }

    function getWhitelistGunTarget(gunData: any, requireWhitelisted: boolean = true, maxDistance: number = 8.0): any {
        const hitPlayer = resolveGunTargetPlayer(gunData, maxDistance);
        if (!hitPlayer || hitPlayer.isNull?.() || playerIsLocal(hitPlayer)) return null;
        const id = getPlayerName(hitPlayer);
        return { player: hitPlayer, id, blocked: false };
    }

    function spawnRpgProjectile(spawnPos: any, spawnRot: any, forward: any, projectileSpeed: number = 30.0) {
        try {
            const spawnResult = PrefabGen.method("SpawnItem", 4).invoke(
                Il2Cpp.string("RpgProjectile"),
                spawnPos,
                spawnRot,
                NULL
            );
            if (spawnResult && !spawnResult.isNull()) {
                try {
                    const rb = spawnResult.method("GetComponent", 1).inflate(Rigidbody).invoke();
                    if (rb && !rb.isNull()) {
                        const vel = Vector3.method("op_Multiply", 2).invoke(forward, projectileSpeed);
                        rb.method("set_velocity").invoke(vel);
                    }
                } catch(_) {}
            }
            return spawnResult;
        } catch(_) {
            return null;
        }
    }
    function spawnRpgProjectileAt(sourceTransform: any, projectileSpeed: number = 30.0, referenceTransform: any = null) {
        try {
            const forward = getLaunchForward(sourceTransform, referenceTransform);
            const up = getLaunchUp(sourceTransform, forward);
            const spawnPos = Vector3.method("op_Addition").invoke(
                sourceTransform.method("get_position").invoke(),
                Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, 0.62),
                    Vector3.method("op_Multiply", 2).invoke(up, -0.03)
                )
            );
            return spawnRpgProjectile(
                spawnPos,
                getLaunchRotation(sourceTransform, forward, up),
                forward,
                projectileSpeed
            );
        } catch(_) {
            return null;
        }
    }
    function getPlayerProjectileOriginTransform(player: any) {
        try {
            const rightHandAnchor = getPlayerHandAnchorTransform(player, 1);
            if (rightHandAnchor && !rightHandAnchor.isNull?.()) return rightHandAnchor;
        } catch(_) {}
        try {
            const rightHand = player.field("rightHandTransform").value;
            if (isLiveObject(rightHand)) return rightHand;
        } catch(_) {}
        try {
            const playerView = player.method("get_playerView").invoke();
            if (isLiveObject(playerView)) {
                try {
                    const rightHand = playerView.field("_rightHandTransform").value;
                    if (isLiveObject(rightHand)) return rightHand;
                } catch(_) {}
            }
        } catch(_) {}
        try {
            const playerView = player.method("get_playerView").invoke();
            if (isLiveObject(playerView)) {
                try {
                    const cameraTransform = playerView.field("_cameraTransform").value;
                    if (isLiveObject(cameraTransform)) return cameraTransform;
                } catch(_) {}
            }
        } catch(_) {}
        try {
            const head = player.field("headCollider").value;
            if (isLiveObject(head)) return getTransform(head);
        } catch(_) {}
        try {
            return getTransform(player);
        } catch(_) {
            return null;
        }
    }
    function getPlayerStraightForward(player: any): [number, number, number] {
        try {
            const tf = getPlayerHeadTransform(player) ?? getTransform(player);
            const raw = readVec3Components(tf.method("get_forward").invoke());
            const x = raw[0];
            const z = raw[2];
            const mag = Math.sqrt((x * x) + (z * z));
            if (mag > 0.0001) return [x / mag, 0, z / mag];
        } catch(_) {}
        return [0, 0, 1];
    }
    function getLookRotationFromForward(forward: [number, number, number]): any {
        try { return Quaternion.method("LookRotation", 2).invoke(forward, [0, 1, 0]); } catch(_) {}
        try { return Quaternion.method("LookRotation", 1).invoke(forward); } catch(_) {}
        return identityQuaternion;
    }

    function recenterMenu() {
        const menuTransform = getTransform(menu);
        let targetPos, targetRot;
        if (righthand) {
            targetPos = rightHandTransform.method("get_position").invoke();
            targetRot = rightHandTransform.method("get_rotation").invoke();
            targetRot = Quaternion.method("op_Multiply").invoke(targetRot, Quaternion.method("Euler").invoke(0, 0, 180));
        } else {
            targetPos = leftHandTransform.method("get_position").invoke();
            targetRot = leftHandTransform.method("get_rotation").invoke();
        }
        if (menuSnapNextFrame) {
            menuTransform.method("set_position").invoke(targetPos);
            menuTransform.method("set_rotation").invoke(targetRot);
            menuSnapNextFrame = false;
        } else if (LerpMenu || true) {
            const menuPos = menuTransform.method("get_position").invoke();
            menuTransform.method("set_position").invoke(Vector3.method("Lerp").invoke(menuPos, targetPos, Math.min(1.0, deltaTime * 22)));
            menuTransform.method("set_rotation").invoke(Quaternion.method("Slerp").invoke(menuTransform.method("get_rotation").invoke(), targetRot, Math.min(1.0, deltaTime * 20)));
        } else {
            menuTransform.method("set_position").invoke(targetPos);
            menuTransform.method("set_rotation").invoke(targetRot);
        }
    }

    function getAllLobbyItemGameObjects(): any[] {
        const results: any[] = [];
        const seen = new Set<string>();
        const pushItem = (obj: any) => {
            try {
                if (!obj || obj.isNull?.()) return;
                let key = normalizeSceneObjectHandle(getRootLikeObject(obj)) || normalizeSceneObjectHandle(obj);
                if (!key) {
                    try {
                        const go = obj.method("get_gameObject").invoke();
                        key = normalizeSceneObjectHandle(go);
                    } catch(_) {}
                }
                if (!key || seen.has(key)) return;
                seen.add(key);
                results.push(obj);
            } catch(_) {}
        };
        try {
            const items = Object.method("FindObjectsByType", 1).inflate(GBOClass).invoke(0);
            if (items && !items.isNull()) {
                for (let i = 0; i < items.length; i++) {
                    try {
                        const item = items.get(i).cast(GBOClass);
                        if (!item || item.isNull?.()) continue;
                        pushItem(item);
                    } catch(_) {}
                }
            }
        } catch(_) {}
        try {
            const items = Object.method("FindObjectsByType", 1).inflate(GBIClass).invoke(0);
            if (items && !items.isNull()) {
                for (let i = 0; i < items.length; i++) {
                    try {
                        const item = items.get(i).cast(GBIClass);
                        if (!item || item.isNull?.()) continue;
                        pushItem(item);
                    } catch(_) {}
                }
            }
        } catch(_) {}
        try {
            const allItems = GBIClass.method("get_allLootItems").invoke();
            if (allItems && !allItems.isNull()) {
                const en = allItems.method("GetEnumerator").invoke();
                while (en.method("MoveNext").invoke()) {
                    try {
                        const item = en.method("get_Current").invoke();
                        if (!item || item.isNull?.()) continue;
                        pushItem(item);
                    } catch(_) {}
                }
            }
        } catch(_) {}
        try {
            for (const player of getAllNetPlayersList(true)) {
                try {
                    for (const handIndex of [0, 1]) {
                        const held = getPlayerHeldGrabbable(player, handIndex);
                        if (held && !held.isNull?.()) pushItem(held);
                    }
                } catch(_) {}
            }
        } catch(_) {}
        return results;
    }
    function getPlayerHeldGrabbable(player: any, handIndex: number): any {
        try {
            const interactor = player.method("GetHandInteractor", 1).invoke(handIndex);
            if (!interactor || interactor.isNull?.()) return null;
            const itemAnchor = interactor.field("_itemAnchor").value;
            if (!itemAnchor || itemAnchor.isNull?.()) return null;
            const grabbable = itemAnchor.method("get_grabbableObject").invoke();
            if (!grabbable || grabbable.isNull?.()) return null;
            return grabbable;
        } catch(_) {
            return null;
        }
    }
    function getLocalHeldGrabbable(preferRight: boolean = true): any {
        try {
            const player = NetPlayer.method("get_localPlayer").invoke();
            if (!player || player.isNull?.()) return null;
            const first = preferRight ? 1 : 0;
            const second = preferRight ? 0 : 1;
            return getPlayerHeldGrabbable(player, first) ?? getPlayerHeldGrabbable(player, second);
        } catch(_) {
            return null;
        }
    }
    function getPlayerOverlayKey(player: any): string {
        try { return normalizeSceneObjectHandle(player) || getPlayerName(player) || String(player); } catch(_) { return String(player); }
    }
    function configureOverlayMaterial(material: any, color: [number, number, number, number]) {
        try {
            if (!material || material.isNull?.()) return;
            try { material.method("set_shader").invoke(TextShader); } catch(_) { try { material.method("set_shader").invoke(UberShader); } catch(_) {} }
            try { material.method("set_color").invoke(color); } catch(_) {}
            try { material.method("SetInt").invoke(Il2Cpp.string("_ZTest"), 8); } catch(_) {}
            try { material.method("SetInt").invoke(Il2Cpp.string("_ZWrite"), 0); } catch(_) {}
            try { material.method("SetInt").invoke(Il2Cpp.string("_Cull"), 0); } catch(_) {}
            try { material.method("set_renderQueue").invoke(5000); } catch(_) {}
        } catch(_) {}
    }
    function configureOverlayRenderer(renderer: any, color: [number, number, number, number]) {
        try {
            if (!renderer || renderer.isNull?.()) return;
            try { renderer.method("set_sortingOrder").invoke(32767); } catch(_) {}
            try { renderer.method("set_allowOcclusionWhenDynamic").invoke(false); } catch(_) {}
            const material = renderer.method("get_material").invoke();
            configureOverlayMaterial(material, color);
        } catch(_) {}
    }
    function destroyOverlayEntries(map: Map<string, any>) {
        try {
            for (const [, entry] of map.entries()) {
                try {
                    if (entry?.root && !entry.root.isNull?.()) Destroy(entry.root);
                    if (entry?.boxRoot && !entry.boxRoot.isNull?.()) Destroy(entry.boxRoot);
                    if (entry?.rayRoot && !entry.rayRoot.isNull?.()) Destroy(entry.rayRoot);
                } catch(_) {}
            }
            map.clear();
        } catch(_) {}
    }
    function getOverlayViewPosition(): any {
        try { return getTransform(headCollider).method("get_position").invoke(); } catch(_) { return [0, 0, 0]; }
    }
    function updatePlayerNameTags() {
        if (!nameTagsEnabled) {
            destroyOverlayEntries(playerNameTagEntries);
            return;
        }
        const alive = new Set<string>();
        const viewerPos = getOverlayViewPosition();
        for (const player of getAllNetPlayersList(true)) {
            try {
                if (!player || player.isNull?.()) continue;
                const key = getPlayerOverlayKey(player);
                alive.add(key);
                let entry = playerNameTagEntries.get(key);
                if (!entry) {
                    const root = createEmptyObject("PlayerNameTag", null);
                    const textObj = createEmptyObject("PlayerNameTagText", getTransform(root));
                    let comp: any = null;
                    if (TextMesh) {
                        comp = addComponent(textObj, TextMesh);
                        try {
                            const font = getarialnocrash2();
                            if (font && !font.isNull?.()) comp.method("set_font").invoke(font);
                        } catch(_) {}
                    } else if (TextMeshPro3D) {
                        comp = addComponent(textObj, TextMeshPro3D);
                        try {
                            const tmpFont = gettmpfontnocrash();
                            if (tmpFont && !tmpFont.isNull?.()) comp.method("set_font").invoke(tmpFont);
                        } catch(_) {}
                    }
                    entry = { root, textObj, comp };
                    playerNameTagEntries.set(key, entry);
                }
                const headTf = getPlayerHeadTransform(player);
                if (!headTf || headTf.isNull?.()) continue;
                const headPos = headTf.method("get_position").invoke();
                const tagPos = [
                    (headPos.field("x").value as number),
                    (headPos.field("y").value as number) + 0.34,
                    (headPos.field("z").value as number)
                ];
                const rootTf = getTransform(entry.root);
                rootTf.method("set_position").invoke(tagPos);
                const lookDir = Vector3.method("op_Subtraction", 2).invoke(viewerPos, tagPos);
                try {
                    const rot = Quaternion.method("LookRotation", 1).invoke(lookDir);
                    rootTf.method("set_rotation").invoke(rot);
                } catch(_) {}
                try { rootTf.method("Rotate").invoke(0.0, 180.0, 0.0); } catch(_) {}
                if (TextMeshPro3D && entry.comp && !TextMesh) {

    try {
        entry.comp.method("SetText", 1).invoke(
            Il2Cpp.string(getPlayerName(player))
        );
    } catch(_) {
        try {
            entry.comp.method("set_text").invoke(
                Il2Cpp.string(getPlayerName(player))
            );
        } catch(_) {}
    }

    try { entry.comp.method("set_fontSize").invoke(2.8); } catch(_) {}
    try { entry.comp.method("set_color").invoke([0.24, 0.66, 1.0, 1.0]); } catch(_) {}
    try { entry.comp.method("set_alignment").invoke(514); } catch(_) {}
    try { entry.comp.method("set_enableWordWrapping").invoke(false); } catch(_) {}

    // FORCE RENDERER ENABLED
    try {

        const renderer = entry.textObj
            .method("GetComponent")
            .inflate(Renderer)
            .invoke();

        if (renderer && !renderer.isNull?.()) {

            renderer.method("set_enabled").invoke(true);

            const mat = renderer.method("get_material").invoke();

            if (mat && !mat.isNull?.()) {

                try {
                    mat.method("set_renderQueue").invoke(5000);
                } catch(_) {}

            }
        }

    } catch(e) {
        console.error("NameTag Renderer:", e);
    }

    // FIX MICROSCOPIC SCALE
    try {
        getTransform(entry.textObj)
            .method("set_localScale")
            .invoke([0.02, 0.02, 0.02]);
    } catch(_) {}

} else if (entry.comp) {

    try {
        entry.comp.method("set_text").invoke(
            Il2Cpp.string(getPlayerName(player))
        );
    } catch(_) {}

    try { entry.comp.method("set_fontSize").invoke(44); } catch(_) {}
    try { entry.comp.method("set_characterSize").invoke(0.032); } catch(_) {}

    // FIX SCALE FOR NORMAL TEXTMESH
    try {
        getTransform(entry.textObj)
            .method("set_localScale")
            .invoke([0.02, 0.02, 0.02]);
    } catch(_) {}

    try { entry.comp.method("set_anchor").invoke(4); } catch(_) {}
    try { entry.comp.method("set_alignment").invoke(1); } catch(_) {}
    try { entry.comp.method("set_color").invoke([0.24, 0.66, 1.0, 1.0]); } catch(_) {}

    // FORCE NORMAL TEXTMESH RENDERER
    try {

        const renderer = entry.textObj
            .method("GetComponent")
            .inflate(Renderer)
            .invoke();

        if (renderer && !renderer.isNull?.()) {

            renderer.method("set_enabled").invoke(true);

            const mat = renderer.method("get_material").invoke();

            if (mat && !mat.isNull?.()) {

                try {
                    mat.method("set_renderQueue").invoke(5000);
                } catch(_) {}

            }
        }

    } catch(e) {
        console.error("NameTag Renderer:", e);
    }
                } else if (entry.comp) {
                    try { entry.comp.method("set_text").invoke(Il2Cpp.string(getPlayerName(player))); } catch(_) {}
                    try { entry.comp.method("set_fontSize").invoke(44); } catch(_) {}
                    try { entry.comp.method("set_characterSize").invoke(0.032); } catch(_) {}
                    try { entry.comp.method("set_anchor").invoke(4); } catch(_) {}
                    try { entry.comp.method("set_alignment").invoke(1); } catch(_) {}
                    try { entry.comp.method("set_color").invoke([0.24, 0.66, 1.0, 1.0]); } catch(_) {}
                }
                try {
                    const rend = getComponent(entry.textObj ?? entry.root, Renderer);
                    if (rend && !rend.isNull?.()) {
                        try { rend.method("set_enabled").invoke(true); } catch(_) {}
                        try {
                            if (TextMesh && entry.comp) {
                                const font = getarialnocrash2();
                                if (font && !font.isNull?.()) {
                                    try { rend.method("set_sharedMaterial").invoke(font.method("get_material").invoke()); } catch(_) {
                                        try { rend.method("set_material").invoke(font.method("get_material").invoke()); } catch(_) {}
                                    }
                                }
                            }
                        } catch(_) {}
                        configureOverlayRenderer(rend, [0.24, 0.66, 1.0, 1.0]);
                    }
                } catch(_) {}
                try { getTransform(entry.textObj ?? entry.root).method("set_localScale").invoke([0.055, 0.055, 0.055]); } catch(_) {}
            } catch(_) {}
        }
        for (const [key, entry] of Array.from(playerNameTagEntries.entries())) {
            if (alive.has(key)) continue;
            try { if (entry?.textObj && !entry.textObj.isNull?.()) Destroy(entry.textObj); } catch(_) {}
            try { if (entry?.root && !entry.root.isNull?.()) Destroy(entry.root); } catch(_) {}
            playerNameTagEntries.delete(key);
        }
    }
    function ensureEspEntry(player: any): any {
        const key = getPlayerOverlayKey(player);
        let entry = playerEspEntries.get(key);
        if (entry) return entry;
        const rayRoot = createEmptyObject("PlayerEspRay", null);
        const boxRoot = createEmptyObject("PlayerEspBox", null);
        const ray = addComponent(rayRoot, LineRenderer);
        const box = addComponent(boxRoot, LineRenderer);
        entry = { rayRoot, boxRoot, ray, box };
        playerEspEntries.set(key, entry);
        return entry;
    }
    function updatePlayerEspOverlays() {
        if (!arenaEspEnabled) {
            destroyOverlayEntries(playerEspEntries);
            return;
        }
        const alive = new Set<string>();
        const viewerTf = getTransform(headCollider);
        const viewerPos = viewerTf.method("get_position").invoke();
        const camRight = readVec3Components(viewerTf.method("get_right").invoke());
        const camUp = readVec3Components(viewerTf.method("get_up").invoke());
        const handPos = rightHandTransform.method("get_position").invoke();
        for (const player of getAllNetPlayersList(false)) {
            try {
                if (!player || player.isNull?.()) continue;
                const key = getPlayerOverlayKey(player);
                alive.add(key);
                const entry = ensureEspEntry(player);
                const headTf = getPlayerHeadTransform(player);
                const bodyTf = getTransform(player);
                if (!headTf || headTf.isNull?.() || !bodyTf || bodyTf.isNull?.()) continue;
                const headPos = headTf.method("get_position").invoke();
                const bodyPos = bodyTf.method("get_position").invoke();
                const center = [
                    (bodyPos.field("x").value as number),
                    ((bodyPos.field("y").value as number) + (headPos.field("y").value as number)) * 0.5,
                    (bodyPos.field("z").value as number)
                ];
                const height = Math.max(0.9, ((headPos.field("y").value as number) - (bodyPos.field("y").value as number)) + 0.55);
                const width = Math.max(0.24, height * 0.32);
                const rightVec: [number, number, number] = [camRight[0] * width, camRight[1] * width, camRight[2] * width];
                const upVec: [number, number, number] = [camUp[0] * height * 0.5, camUp[1] * height * 0.5, camUp[2] * height * 0.5];
                const p0 = [center[0] - rightVec[0] - upVec[0], center[1] - rightVec[1] - upVec[1], center[2] - rightVec[2] - upVec[2]];
                const p1 = [center[0] + rightVec[0] - upVec[0], center[1] + rightVec[1] - upVec[1], center[2] + rightVec[2] - upVec[2]];
                const p2 = [center[0] + rightVec[0] + upVec[0], center[1] + rightVec[1] + upVec[1], center[2] + rightVec[2] + upVec[2]];
                const p3 = [center[0] - rightVec[0] + upVec[0], center[1] - rightVec[1] + upVec[1], center[2] - rightVec[2] + upVec[2]];
                const box = entry.box;
                const ray = entry.ray;
                const espColor: [number, number, number, number] = [0.18, 0.62, 1.0, 0.95];
                const rayColor: [number, number, number, number] = [1.0, 0.58, 0.1, 0.92];
                try {
                    box.method("set_useWorldSpace").invoke(true);
                    box.method("set_positionCount").invoke(5);
                    box.method("set_startWidth").invoke(0.01);
                    box.method("set_endWidth").invoke(0.01);
                    box.method("set_startColor").invoke(espColor);
                    box.method("set_endColor").invoke(espColor);
                    try { box.method("set_numCornerVertices").invoke(8); } catch(_) {}
                    try { box.method("set_numCapVertices").invoke(8); } catch(_) {}
                    box.method("SetPosition").invoke(0, p0);
                    box.method("SetPosition").invoke(1, p1);
                    box.method("SetPosition").invoke(2, p2);
                    box.method("SetPosition").invoke(3, p3);
                    box.method("SetPosition").invoke(4, p0);
                    configureOverlayMaterial(box.method("get_material").invoke(), espColor);
                } catch(_) {}
                try {
                    ray.method("set_useWorldSpace").invoke(true);
                    ray.method("set_positionCount").invoke(2);
                    ray.method("set_startWidth").invoke(0.006);
                    ray.method("set_endWidth").invoke(0.006);
                    ray.method("set_startColor").invoke(rayColor);
                    ray.method("set_endColor").invoke(rayColor);
                    try { ray.method("set_numCornerVertices").invoke(8); } catch(_) {}
                    try { ray.method("set_numCapVertices").invoke(8); } catch(_) {}
                    ray.method("SetPosition").invoke(0, handPos);
                    ray.method("SetPosition").invoke(1, headPos);
                    configureOverlayMaterial(ray.method("get_material").invoke(), rayColor);
                } catch(_) {}
            } catch(_) {}
        }
        for (const [key, entry] of Array.from(playerEspEntries.entries())) {
            if (alive.has(key)) continue;
            try { if (entry?.rayRoot && !entry.rayRoot.isNull?.()) Destroy(entry.rayRoot); } catch(_) {}
            try { if (entry?.boxRoot && !entry.boxRoot.isNull?.()) Destroy(entry.boxRoot); } catch(_) {}
            playerEspEntries.delete(key);
        }
    }
    function getPlayerHandAnchorTransform(player: any, handIndex: number = 1): any {
        try {
            const interactor = player.method("GetHandInteractor", 1).invoke(handIndex);
            if (interactor && !interactor.isNull?.()) {
                try {
                    const itemAnchor = interactor.field("_itemAnchor").value;
                    if (itemAnchor && !itemAnchor.isNull?.()) {
                        try {
                            const anchorTf = itemAnchor.method("get_transform").invoke();
                            if (anchorTf && !anchorTf.isNull?.()) return anchorTf;
                        } catch(_) {}
                    }
                } catch(_) {}
                try {
                    const handTf = interactor.field("_handTransform").value;
                    if (handTf && !handTf.isNull?.()) return handTf;
                } catch(_) {}
            }
        } catch(_) {}
        try {
            const fieldName = handIndex === 1 ? "rightHandTransform" : "leftHandTransform";
            const handTf = player.field(fieldName).value;
            if (handTf && !handTf.isNull?.()) return handTf;
        } catch(_) {}
        return null;
    }
    function grabbableLooksLikeRevolver(grabbable: any): boolean {
        try {
            if (!grabbable || grabbable.isNull?.()) return false;
            const className = (grabbable.class?.type?.name ?? "").toLowerCase();
            if (className.indexOf("revolver") >= 0) return true;
            try {
                const go = grabbable.method("get_gameObject").invoke();
                const goName = (go?.method("get_name").invoke()?.content ?? "").toLowerCase();
                if (goName.indexOf("revolver") >= 0) return true;
            } catch(_) {}
        } catch(_) {}
        return false;
    }
    function grabbableLooksLikeGun(grabbable: any): boolean {
        try {
            if (!grabbable || grabbable.isNull?.()) return false;
            const checks: string[] = [];
            try { checks.push((grabbable.class?.type?.name ?? "").toLowerCase()); } catch(_) {}
            try {
                const go = grabbable.method("get_gameObject").invoke();
                checks.push((go?.method("get_name").invoke()?.content ?? "").toLowerCase());
            } catch(_) {}
            const needles = ["gun", "revolver", "shotgun", "pistol", "rpg", "rocket", "flare", "crossbow", "launcher", "cannon", "bow"];
            return checks.some(v => needles.some(n => v.indexOf(n) >= 0));
        } catch(_) {
            return false;
        }
    }
    function getSelectedItemNeedles(bareID: string): string[] {
        const values = new Set<string>();
        const add = (v: string) => {
            const t = (v ?? "").toLowerCase().trim();
            if (t) values.add(t);
        };
        add(bareID);
        if ((bareID ?? "").toLowerCase().startsWith("item_")) add((bareID ?? "").slice(5));
        return Array.from(values);
    }
    function grabbableMatchesSelectedItem(grabbable: any, bareID: string): boolean {
        for (const needle of getSelectedItemNeedles(bareID)) {
            if (grabbableMatchesItemId(grabbable, needle)) return true;
        }
        return false;
    }
    function getGrabbableItemId(grabbable: any): string {
        try {
            if (!grabbable || grabbable.isNull?.()) return "";
            try {
                const gbi = grabbable.method("GetComponent", 1).inflate(GBIClass).invoke();
                if (gbi && !gbi.isNull()) {
                    const idObj = gbi.method("get_itemID").invoke();
                    const idStr = (idObj?.content ?? "").trim();
                    if (idStr) return idStr;
                }
            } catch(_) {}
            try {
                const go = grabbable.method("get_gameObject").invoke();
                const goName = (go?.method("get_name").invoke()?.content ?? "").trim();
                if (goName) return goName;
            } catch(_) {}
            return (grabbable.class?.type?.name ?? "").trim();
        } catch(_) {
            return "";
        }
    }
    function grabbableMatchesItemId(grabbable: any, bareID: string): boolean {
        try {
            if (!grabbable || grabbable.isNull?.()) return false;
            const needle = (bareID ?? "").toLowerCase();
            const className = (grabbable.class?.type?.name ?? "").toLowerCase();
            if (className.indexOf(needle) >= 0) return true;
            try {
                const go = grabbable.method("get_gameObject").invoke();
                const goName = (go?.method("get_name").invoke()?.content ?? "").toLowerCase();
                if (goName.indexOf(needle) >= 0) return true;
            } catch(_) {}
            try {
                const gbi = grabbable.method("GetComponent", 1).inflate(GBIClass).invoke();
                if (gbi && !gbi.isNull()) {
                    const idObj = gbi.method("get_itemID").invoke();
                    const idStr = (idObj?.content ?? "").toLowerCase();
                    if (idStr === needle || idStr.endsWith(needle)) return true;
                }
            } catch(_) {}
        } catch(_) {}
        return false;
    }
    function getPlayerKickTokens(player: any): string[] {
        const tokens: string[] = [];
        const pushToken = (value: any) => {
            const token = normalizePlayerToken(value);
            if (!token || token === "?" || tokens.includes(token)) return;
            tokens.push(token);
        };
        try {
            const info = getPlayerIdentityInfo(player);
            for (const alias of info.aliases) pushToken(alias);
        } catch(_) {}
        try { pushToken(player.method("GetUserIDAndRegister").invoke()); } catch(_) {}
        try { pushToken(player.method("get_userId").invoke()); } catch(_) {}
        try { pushToken(player.method("get_userID").invoke()); } catch(_) {}
        try { pushToken(player.method("get_accountId").invoke()); } catch(_) {}
        try { pushToken(player.method("get_accountID").invoke()); } catch(_) {}
        try { pushToken(player.field("_userId").value); } catch(_) {}
        try { pushToken(player.field("_userID").value); } catch(_) {}
        try { pushToken(player.field("_accountId").value); } catch(_) {}
        try { pushToken(player.field("_accountID").value); } catch(_) {}
        try {
            const playerView = player.method("get_playerView").invoke();
            if (playerView && !playerView.isNull?.()) {
                try { pushToken(playerView.field("_userId").value); } catch(_) {}
                try { pushToken(playerView.field("_accountId").value); } catch(_) {}
                try { pushToken(playerView.method("get_userId").invoke()); } catch(_) {}
            }
        } catch(_) {}
        return tokens;
    }
    function dumpPlayerInfoToTerminal(player: any): void {
        try {
            if (!player || player.isNull?.()) return;
            const lines: string[] = [];
            const info = getPlayerIdentityInfo(player);
            lines.push("========================================");
            lines.push("[PlayerInfo] " + info.label);
            lines.push("aliases: " + info.aliases.join(" | "));
            lines.push("kickTokens: " + getPlayerKickTokens(player).join(" | "));
            try { lines.push("playerRef: " + normalizePlayerToken(player.method("get_PlayerRef").invoke())); } catch(_) {}
            const dumpCandidate = (owner: any, prefix: string) => {
                try {
                    if (!owner || owner.isNull?.()) return;
                    const needles = ["name", "display", "playerid", "userid", "account", "auth", "token", "nonce", "session", "photon"];
                    for (const field of (owner.class?.fields ?? [])) {
                        try {
                            const fieldName = String(field.name ?? "");
                            if (!needles.some(n => fieldName.toLowerCase().indexOf(n) >= 0)) continue;
                            lines.push(prefix + "field " + fieldName + " = " + normalizePlayerToken(owner.field(fieldName).value));
                        } catch(_) {}
                    }
                    for (const methodName of ["get_displayName", "get_name", "get_playerId", "get_userId", "get_userID", "get_accountId", "get_accountID", "get_authToken", "get_token", "get_nonce"]) {
                        try {
                            lines.push(prefix + methodName + " = " + normalizePlayerToken(owner.method(methodName).invoke()));
                        } catch(_) {}
                    }
                } catch(_) {}
            };
            dumpCandidate(player, "player.");
            try {
                const playerView = player.method("get_playerView").invoke();
                if (playerView && !playerView.isNull?.()) dumpCandidate(playerView, "view.");
            } catch(_) {}
            console.log(lines.join("\n"));
        } catch(e) {
            console.error("[PlayerInfo]", e);
        }
    }
    function rankKickToken(token: string): number {
        if (!token) return -9999;
        let score = 0;
        if (token.indexOf(" ") < 0) score += 3;
        if (token.length >= 10) score += 3;
        if (/^[a-z0-9_\-:.]+$/i.test(token)) score += 2;
        if (/[0-9]/.test(token)) score += 1;
        if (token.toLowerCase().indexOf("player") >= 0) score -= 2;
        return score;
    }
    function getSingletonInstanceCandidates(klass: any): any[] {
        const results: any[] = [];
        const seen = new Set<string>();
        const pushObj = (obj: any) => {
            try {
                if (!obj || obj.isNull?.()) return;
                const key = normalizeSceneObjectHandle(obj) || String(obj);
                if (seen.has(key)) return;
                seen.add(key);
                results.push(obj);
            } catch(_) {}
        };
        if (!klass) return results;
        for (const fieldName of ["<Instance>k__BackingField", "_instance", "Instance", "instance", "s_instance", "m_instance"]) {
            try { pushObj(klass.field(fieldName).value); } catch(_) {}
        }
        for (const getterName of ["get_Instance", "get_instance"]) {
            try { pushObj(klass.method(getterName).invoke()); } catch(_) {}
        }
        return results;
    }
    function buildModerationArg(type: any, token: string, player: any): any {
        try {
            const typeName = String(type?.name ?? "");
            if (typeName.indexOf("System.String") >= 0) return Il2Cpp.string(token);
            if (typeName.indexOf("AnimalCompany.NetPlayer") >= 0) return player;
            if (typeName.indexOf("Fusion.PlayerRef") >= 0) {
                try { return player.method("get_PlayerRef").invoke(); } catch(_) {}
                try { return player.field("_playerRef").value; } catch(_) {}
                return 0;
            }
            if (typeName.indexOf("Boolean") >= 0) return 0;
            if (/(Byte|SByte|Int16|UInt16|Int32|UInt32|Int64|UInt64|Single|Double)/.test(typeName)) return 0;
            try { if (type?.class?.isEnum) return 0; } catch(_) {}
            try { if (type?.class?.isValueType) return 0; } catch(_) {}
        } catch(_) {}
        return NULL;
    }
    function tryInvokeModerationMethod(receiver: any, isStaticReceiver: boolean, methodName: string, token: string, player: any): boolean {
        try {
            const methodGroup = receiver.method(methodName);
            const overloads = methodGroup.overloads ? methodGroup.overloads() : [methodGroup];
            for (const overload of overloads) {
                try {
                    if (overload.parameters.length < 1 || overload.parameters.length > 4) continue;
                    const hasSupportedArg = overload.parameters.some((p: any) => {
                        const typeName = String(p.type?.name ?? "");
                        return typeName.indexOf("System.String") >= 0 ||
                            typeName.indexOf("AnimalCompany.NetPlayer") >= 0 ||
                            typeName.indexOf("Fusion.PlayerRef") >= 0;
                    });
                    if (!hasSupportedArg) continue;
                    const args = [];
                    let hasBoolean = false;
                    for (const param of overload.parameters) {
                        try {
                            if (String(param.type?.name ?? "").indexOf("Boolean") >= 0) hasBoolean = true;
                        } catch(_) {}
                        args.push(buildModerationArg(param.type, token, player));
                    }
                    const argVariants = [args];
                    if (hasBoolean) {
                        const toggled = args.slice();
                        for (let i = 0; i < overload.parameters.length; i++) {
                            try {
                                if (String(overload.parameters[i].type?.name ?? "").indexOf("Boolean") >= 0) toggled[i] = true;
                            } catch(_) {}
                        }
                        argVariants.push(toggled);
                    }
                    for (const argSet of argVariants) {
                        if (isStaticReceiver) {
                            overload.invoke(...argSet);
                        } else {
                            overload.bind(receiver).invoke(...argSet);
                        }
                        return true;
                    }
                } catch(_) {}
            }
        } catch(_) {}
        return false;
    }
    function tryKickPlayer(player: any): boolean {
        if (!player || player.isNull?.() || playerIsLocal(player)) return false;
        try {
            const playerRef = (() => {
                try { return player.method("get_PlayerRef").invoke(); } catch(_) {}
                try { return player.field("_playerRef").value; } catch(_) {}
                return null;
            })();
            for (const runner of getRunnerCandidates()) {
                try {
                    if (!runner || runner.isNull?.()) continue;
                    if (playerRef != null) {
                        if (tryCallNames(runner, ["Disconnect", "DisconnectPlayer", "RemovePlayer", "KickPlayer", "CloseConnection", "KickPeer"], 1, playerRef)) return true;
                        if (tryCallNames(runner, ["Disconnect", "DisconnectPlayer", "RemovePlayer", "KickPlayer", "CloseConnection", "KickPeer"], 2, playerRef, true)) return true;
                    }
                    if (tryCallNames(runner, ["Disconnect", "DisconnectPlayer", "RemovePlayer", "KickPlayer", "CloseConnection", "KickPeer"], 1, player)) return true;
                    if (tryCallNames(runner, ["Disconnect", "DisconnectPlayer", "RemovePlayer", "KickPlayer", "CloseConnection", "KickPeer"], 2, player, true)) return true;
                } catch(_) {}
            }
        } catch(_) {}
        const tokens = getPlayerKickTokens(player).sort((a, b) => rankKickToken(b) - rankKickToken(a));
        const methodNames = [
            "KickPlayer",
            "RPC_KickPlayer",
            "KickPlayerByUserId",
            "KickPlayerByAccountId",
            "DisconnectPlayer",
            "DisconnectUser",
            "KickUserFromPrivateRoom",
            "RemovePrivateRoomMember",
            "KickUser",
            "BanUserFromPrivateRoom",
            "RoomBanUserAsync",
            "KickSelectedPlayer",
            "ModerateKickUser",
            "OnKickUserPressed"
        ];
        const candidateClasses = [
            NetSessionPrivateRoomManagerClass,
            PlayerWatchDevMenuMediatorClass,
            ModerationMenuMediatorClass,
            NetworkSessionManagerClass,
            NManager,
            PrivateRoomStateClass,
            UserCacheManagerClass,
            AnimalCompanyApiClass
        ];
        for (const token of tokens) {
            for (const klass of candidateClasses) {
                if (!klass) continue;
                for (const methodName of methodNames) {
                    for (const instance of getSingletonInstanceCandidates(klass)) {
                        if (tryInvokeModerationMethod(instance, false, methodName, token, player)) return true;
                    }
                    if (tryInvokeModerationMethod(klass, true, methodName, token, player)) return true;
                }
            }
        }
        return false;
    }
    function isPlayerNearMe(player: any, maxDistance: number = 10.0): boolean {
        try {
            const myPos = getTransform(headCollider).method("get_position").invoke();
            const playerPos = getTransform(player).method("get_position").invoke();
            return (Vector3.method("Distance").invoke(myPos, playerPos) as number) <= maxDistance;
        } catch(_) {
            return false;
        }
    }
    function tryCallNames(obj: any, names: string[], parameterCount: number = -1, ...args: any[]): boolean {
        try {
            if (!obj || obj.isNull?.()) return false;
            for (const name of names) {
                try {
                    const method = parameterCount >= 0 ? obj.class.method(name, parameterCount) : obj.class.method(name);
                    if (method) {
                        invokeInstance(method, obj, ...args);
                        return true;
                    }
                } catch(_) {}
                try {
                    const method = parameterCount >= 0 ? obj.method(name, parameterCount) : obj.method(name);
                    if (method) {
                        method.invoke(...args);
                        return true;
                    }
                } catch(_) {}
            }
        } catch(_) {}
        return false;
    }
    function tryReleaseHeldItem(obj: any): void {
        try {
            if (!obj || obj.isNull?.()) return;
            const names = ["ForceDrop", "Drop", "Release", "ReleaseGrabHandle", "ReleaseGrabHandles", "ReleaseHeldObject", "DropHeldObject", "DropItem", "Detach", "DetachFromPlayer", "RPC_Drop", "TryDrop", "TryRelease", "ForceRelease", "Unequip", "UngrabAllHandles", "BreakGrabWithDistance"];
            tryCallNames(obj, names, -1);
            tryCallNames(obj, names, 0);
            try {
                const go = obj.method("get_gameObject").invoke();
                if (go && !go.isNull?.()) {
                    tryCallNames(go, names, -1);
                    tryCallNames(go, names, 0);
                }
            } catch(_) {}
        } catch(_) {}
    }
    function requestAuthorityDeep(obj: any): void {
        try {
            if (!obj || obj.isNull?.()) return;
            tryCallNames(obj, ["RequestStateAuthority", "RequestInputAuthority", "TakeOwnership", "ClaimOwnership"], 0);
            try {
                const networkObj = tryMethodName(obj.class, ["get_Object", "get_NetworkObject"], 0);
                if (networkObj) {
                    const no = invokeInstance(networkObj, obj);
                    if (no && !no.isNull?.()) tryCallNames(no, ["RequestStateAuthority", "RequestInputAuthority", "TakeOwnership", "ClaimOwnership"], 0);
                }
            } catch(_) {}
            try {
                const runner = obj.method?.("get_Runner")?.invoke?.();
                if (runner && !runner.isNull?.()) {
                    tryCallNames(runner, ["RequestStateAuthority", "RequestInputAuthority"], 1, obj);
                }
            } catch(_) {}
        } catch(_) {}
    }
    function forceReleaseItemFromAllPlayers(obj: any): void {
        try {
            const targetKey = normalizeSceneObjectHandle(obj);
            for (const player of getAllNetPlayersList(true)) {
                try { tryReleaseHeldItem(player); } catch(_) {}
                tryCallNames(player, ["ReleaseHeldObject", "DropHeldObject", "DropItem", "DetachFromBack", "SetAttachedToBack", "SetAttachedToHip"], 0);
                tryCallNames(player, ["SetAttachedToBack", "SetAttachedToHip"], 1, false);
                for (const handIndex of [0, 1]) {
                    try {
                        const interactor = player.method("GetHandInteractor", 1).invoke(handIndex);
                        if (interactor && !interactor.isNull?.()) {
                            tryReleaseHeldItem(interactor);
                            tryCallNames(interactor, ["ReleaseHeldObject", "DropHeldObject", "DropItem", "ForceDrop"], 0);
                        }
                        const held = getPlayerHeldGrabbable(player, handIndex);
                        if (!held || held.isNull?.()) continue;
                        const heldKey = normalizeSceneObjectHandle(held);
                        if (targetKey && heldKey && targetKey !== heldKey) continue;
                        tryReleaseHeldItem(held);
                        tryReleaseHeldItem(player);
                        tryCallNames(held, ["DetachFromBack", "DetachFromHip", "SetAttachedToBack", "SetAttachedToHip"], 0);
                        tryCallNames(held, ["SetAttachedToBack", "SetAttachedToHip"], 1, false);
                    } catch(_) {}
                }
            }
        } catch(_) {}
    }
    function forceMoveLobbyItem(go: any, worldPos: any): boolean {
        try {
            if (!go || go.isNull?.()) return false;
            let target = go;
            let targetGo = go;
            try {
                const maybeGo = go.method("get_gameObject").invoke();
                if (maybeGo && !maybeGo.isNull?.()) targetGo = maybeGo;
            } catch(_) {}
            let rootGo = targetGo;
            try {
                const rootTf = getTransform(targetGo).method("get_root").invoke();
                if (rootTf && !rootTf.isNull?.()) {
                    const rootCandidate = rootTf.method("get_gameObject").invoke();
                    if (rootCandidate && !rootCandidate.isNull?.()) rootGo = rootCandidate;
                }
            } catch(_) {}
            forceReleaseItemFromAllPlayers(target);
            forceReleaseItemFromAllPlayers(targetGo);
            forceReleaseItemFromAllPlayers(rootGo);
            tryReleaseHeldItem(target);
            tryReleaseHeldItem(targetGo);
            tryReleaseHeldItem(rootGo);
            requestAuthorityDeep(target);
            requestAuthorityDeep(targetGo);
            requestAuthorityDeep(rootGo);
            try {
                let gbo = null;
                try { gbo = go.cast?.(GBOClass); } catch(_) {}
                if (!gbo || gbo.isNull?.()) {
                    try { gbo = targetGo.method("GetComponent", 1).inflate(GBOClass).invoke(); } catch(_) {}
                }
                if (gbo && !gbo.isNull()) {
                    requestAuthorityDeep(gbo);
                    try {
                        const networkObj = gbo.method("get_Object").invoke();
                        if (networkObj && !networkObj.isNull?.()) {
                            try { networkObj.method("RequestStateAuthority").invoke(); } catch(_) {}
                            requestAuthorityDeep(networkObj);
                        }
                    } catch(_) {}
                    tryCallNames(gbo, ["SetIsHidden"], 1, false);
                }
            } catch(_) {}
            tryCallNames(target, ["Grab", "Release"], 2, NULL, false);
            tryCallNames(target, ["RPC_Teleport", "TeleportTo"], 1, worldPos);
            tryCallNames(targetGo, ["RPC_Teleport", "TeleportTo"], 1, worldPos);
            tryCallNames(rootGo, ["RPC_Teleport", "TeleportTo"], 1, worldPos);
            try {
                const rb = rootGo.method("GetComponentInChildren", 0).inflate(Rigidbody).invoke();
                if (rb && !rb.isNull()) {
                    try { rb.method("set_isKinematic").invoke(true); } catch(_) {}
                    try { rb.method("set_detectCollisions").invoke(false); } catch(_) {}
                    try { rb.method("set_velocity").invoke(zeroVector); } catch(_) {}
                    try { rb.method("set_angularVelocity").invoke(zeroVector); } catch(_) {}
                }
            } catch(_) {}
            try {
                getTransform(target).method("set_position").invoke(worldPos);
            } catch(_) {
                getTransform(targetGo).method("set_position").invoke(worldPos);
            }
            try { getTransform(targetGo).method("set_position").invoke(worldPos); } catch(_) {}
            try { getTransform(rootGo).method("set_position").invoke(worldPos); } catch(_) {}
            tryCallNames(target, ["SetWorldPosition", "SetPosition"], 1, worldPos);
            tryCallNames(targetGo, ["SetWorldPosition", "SetPosition"], 1, worldPos);
            tryCallNames(rootGo, ["SetWorldPosition", "SetPosition"], 1, worldPos);
            tryCallNames(target, ["RPC_SetPosition", "RPC_SetWorldPosition"], 1, worldPos);
            tryCallNames(targetGo, ["RPC_SetPosition", "RPC_SetWorldPosition"], 1, worldPos);
            tryCallNames(rootGo, ["RPC_SetPosition", "RPC_SetWorldPosition"], 1, worldPos);
            try {
                const rb = rootGo.method("GetComponentInChildren", 0).inflate(Rigidbody).invoke();
                if (rb && !rb.isNull()) {
                    try { rb.method("set_velocity").invoke(zeroVector); } catch(_) {}
                    try { rb.method("set_angularVelocity").invoke(zeroVector); } catch(_) {}
                }
            } catch(_) {}
            return true;
        } catch(_) {
            return false;
        }
    }
    function destroyNetworkedObjectDeep(obj: any): boolean {
        try {
            if (!obj || obj.isNull?.()) return false;
            const rootGo = getRootLikeObject(obj);
            const candidates = [obj, rootGo];
            for (const candidate of candidates) {
                try { requestAuthorityDeep(candidate); } catch(_) {}
                try { tryReleaseHeldItem(candidate); } catch(_) {}
                try {
                    let gbo = null;
                    try { gbo = candidate.cast?.(GBOClass); } catch(_) {}
                    if (!gbo || gbo.isNull?.()) {
                        try { gbo = candidate.method("GetComponent", 1).inflate(GBOClass).invoke(); } catch(_) {}
                    }
                    if (gbo && !gbo.isNull?.()) {
                        try { gbo.method("set_isHidden").invoke(false); } catch(_) {}
                        try { gbo.method("Despawn").invoke(); return true; } catch(_) {}
                        try { gbo.method("RPC_Destroy").invoke(); return true; } catch(_) {}
                    }
                } catch(_) {}
                try {
                    const networkObj = tryMethodName(candidate.class, ["get_Object", "get_NetworkObject"], 0);
                    if (networkObj) {
                        const no = invokeInstance(networkObj, candidate);
                        if (no && !no.isNull?.()) {
                            for (const runner of getRunnerCandidates()) {
                                try { runner.method("Despawn").invoke(no); return true; } catch(_) {}
                            }
                            try { no.method("Despawn").invoke(); return true; } catch(_) {}
                        }
                    }
                } catch(_) {}
                try { if (candidate.method) { candidate.method("Despawn").invoke(); return true; } } catch(_) {}
                try { if (candidate.method) { candidate.method("RPC_Destroy").invoke(); return true; } } catch(_) {}
                try { if (candidate.method) { candidate.method("DestroySelf").invoke(); return true; } } catch(_) {}
            }
            try { Destroy(rootGo); } catch(_) {}
            try { Destroy(obj); } catch(_) {}
            return true;
        } catch(_) {
            return false;
        }
    }
    function getSelectedVfxEntry(): [string, number] {
        if (selectedVfxIndex < 0 || selectedVfxIndex >= vfxTypeEntries.length) selectedVfxIndex = 0;
        return vfxTypeEntries[selectedVfxIndex];
    }
    function getRunnerCandidates(): any[] {
        const results: any[] = [];
        const seen = new Set<string>();
        const pushRunner = (runner: any) => {
            try {
                if (!runner || runner.isNull?.()) return;
                const key = normalizeSceneObjectHandle(runner) || String(runner);
                if (seen.has(key)) return;
                seen.add(key);
                results.push(runner);
            } catch(_) {}
        };
        try {
            const sfx = SFXManager.field("_instance").value;
            if (sfx && !sfx.isNull?.()) {
                try { pushRunner(getSfxCurrentRunner()); } catch(_) {}
                try { pushRunner(sfx.field("_currentRunner").value); } catch(_) {}
            }
        } catch(_) {}
        try {
            const pgInst = PrefabGen.field("_instance").value;
            if (pgInst && !pgInst.isNull?.()) {
                try { pushRunner(pgInst.method("get_runner").invoke()); } catch(_) {}
            }
        } catch(_) {}
        try {
            const nm = NManager.field("<Instance>k__BackingField").value;
            if (nm && !nm.isNull?.()) {
                try { pushRunner(nm.method("get_runner").invoke()); } catch(_) {}
            }
        } catch(_) {}
        return results;
    }
    function getPrimaryVfxRunner(): any {
        try {
            const sfx = SFXManager.field("_instance").value;
            if (sfx && !sfx.isNull?.()) {
                try {
                    const runner = getSfxCurrentRunner();
                    if (runner && !runner.isNull?.()) return runner;
                } catch(_) {}
                try {
                    const runner = sfx.field("_currentRunner").value;
                    if (runner && !runner.isNull?.()) return runner;
                } catch(_) {}
            }
        } catch(_) {}
        try {
            const pgInst = PrefabGen.field("_instance").value;
            if (pgInst && !pgInst.isNull?.()) {
                const runner = pgInst.method("get_runner").invoke();
                if (runner && !runner.isNull?.()) return runner;
            }
        } catch(_) {}
        try {
            const nm = NManager.field("<Instance>k__BackingField").value;
            if (nm && !nm.isNull?.()) {
                const runner = nm.method("get_runner").invoke();
                if (runner && !runner.isNull?.()) return runner;
            }
        } catch(_) {}
        return null;
    }
    function getSfxCurrentRunner(): any {
        try {
            const sfx = SFXManager.field("_instance").value;
            if (!sfx || sfx.isNull?.()) return null;
            const methodNames = [
                "get__currentRunner",
                "get_currentRunner",
                "getCurrentRunner",
                "get_runner",
                "getRunner"
            ];
            for (const name of methodNames) {
                try {
                    const method = sfx.method(name);
                    if (!method) continue;
                    const runner = method.invoke();
                    if (runner && !runner.isNull?.()) return runner;
                } catch(_) {}
            }
            const fieldNames = ["_currentRunner", "_runner", "currentRunner", "runner"];
            for (const fieldName of fieldNames) {
                try {
                    const runner = sfx.field(fieldName).value;
                    if (runner && !runner.isNull?.()) return runner;
                } catch(_) {}
            }
        } catch(_) {}
        return null;
    }
    function tryInvokeVfxMethod(methodName: string, runner: any, vfxValue: number, pos: any): boolean {
        const variants: any[] = [
            [vfxValue, pos, identityQuaternion],
            [pos, vfxValue, identityQuaternion],
            [runner, vfxValue, pos, identityQuaternion],
            [runner, pos, vfxValue, identityQuaternion],
            [vfxValue, pos],
            [pos, vfxValue],
            [vfxValue],
            [pos]
        ];
        try {
            for (const klass of [ParticleManagerClass, VFXManagerClass]) {
                if (!klass) continue;
                for (const argSet of variants) {
                    try {
                        const method = tryMethodName(klass, [methodName], argSet.length);
                        if (!method) continue;
                        method.invoke(...argSet);
                        return true;
                    } catch(_) {}
                }
            }
        } catch(_) {}
        try {
            const managers = [SFXManager, ParticleManagerClass, VFXManagerClass];
            for (const managerClass of managers) {
                if (!managerClass) continue;
                for (const instance of getSingletonInstanceCandidates(managerClass)) {
                    for (const argSet of variants) {
                        try {
                            if (tryCallNames(instance, [methodName], argSet.length, ...argSet)) return true;
                        } catch(_) {}
                    }
                }
            }
        } catch(_) {}
        return false;
    }
    function tryDirectPlayVfx(runner: any, vfxValue: number, pos: any): boolean {
        try {
            if (ParticleManagerClass) {
                try { ParticleManagerClass.method("RPC_PlayVFX", 4).invoke(runner, vfxValue, pos, identityQuaternion); return true; } catch(_) {}
                try { ParticleManagerClass.method("RPC_PlayVFXRemoteOnly", 4).invoke(runner, vfxValue, pos, identityQuaternion); return true; } catch(_) {}
                try { ParticleManagerClass.method("RPC_VFX", 4).invoke(runner, vfxValue, pos, identityQuaternion); return true; } catch(_) {}
            }
        } catch(_) {}
        try {
            if (VFXManagerClass) {
                try { VFXManagerClass.method("RPC_PlayVFX", 4).invoke(runner, vfxValue, pos, identityQuaternion); return true; } catch(_) {}
                try { VFXManagerClass.method("RPC_VFX", 4).invoke(runner, vfxValue, pos, identityQuaternion); return true; } catch(_) {}
            }
        } catch(_) {}
        return false;
    }
    function getDynamicVfxMethodNames(): string[] {
        if (vfxMethodNamesCache) return vfxMethodNamesCache;
        const names = new Set<string>([
            "RPC_PlayVFX", "PlayVFX", "SpawnVFX", "TriggerVFX", "PlayEffect", "SpawnEffect",
            "RPC_PlayVfx", "PlayVfx", "SpawnVfx", "TriggerVfx", "PlayParticle", "SpawnParticle",
            "RPC_VFX", "RPC_PlayVFXRemoteOnly", "ExecuteNetworkVFX", "NetworkVFXInternal",
            "RPC_NetworkVFX0", "RPC_NetworkVFX1", "RPC_NetworkVFX2", "RPC_NetworkVFX3", "RPC_NetworkVFX4",
            "PlayEffects", "DoEffects"
        ]);
        try {
            for (const klass of [ParticleManagerClass, SFXManager, VFXManagerClass]) {
                if (!klass) continue;
                for (const method of klass.methods) {
                    try {
                        const name = String(method.name ?? "");
                        if (/vfx|effect|particle/i.test(name)) names.add(name);
                    } catch(_) {}
                }
            }
        } catch(_) {}
        vfxMethodNamesCache = Array.from(names);
        return vfxMethodNamesCache;
    }
    function playSelectedVfxAt(pos: any) {
        try {
            if (time < vfxDispatchUnavailableUntil) return false;
            const [selectedName, selectedValue] = getSelectedVfxEntry();
            const vfxValues = [
                selectedValue === VFXTypes.None ? VFXTypes.ConfettiBurst : selectedValue,
                VFXTypes.ConfettiBurst,
                VFXTypes.GreenBlink,
                VFXTypes.FuelExplosion
            ].filter((value, index, arr) => arr.indexOf(value) === index);
            let success = false;
            const primaryRunner = getPrimaryVfxRunner();
            const methodNames = getDynamicVfxMethodNames();
            if (primaryRunner && !primaryRunner.isNull?.()) {
                for (const vfxValue of vfxValues) {
                    if (tryDirectPlayVfx(primaryRunner, vfxValue, pos)) {
                        success = true;
                        if (vfxValue === vfxValues[0]) return true;
                    }
                    for (const methodName of methodNames) {
                        if (tryInvokeVfxMethod(methodName, primaryRunner, vfxValue, pos)) {
                            success = true;
                            if (vfxValue === vfxValues[0]) return true;
                            break;
                        }
                    }
                }
            }
            for (const runner of getRunnerCandidates()) {
                for (const vfxValue of vfxValues) {
                    if (tryDirectPlayVfx(runner, vfxValue, pos)) {
                        success = true;
                        if (vfxValue === vfxValues[0]) return true;
                    }
                    for (const methodName of methodNames) {
                        if (tryInvokeVfxMethod(methodName, runner, vfxValue, pos)) {
                            success = true;
                            if (vfxValue === vfxValues[0]) return true;
                            break;
                        }
                    }
                }
            }
            if (!success) {
                vfxDispatchUnavailableUntil = time + 4.0;
                if (time >= vfxNoRunnerLogTime) {
                    vfxNoRunnerLogTime = time + 15.0;
                    console.error("[G2] no runner accepted VFX", selectedName);
                }
            }
            return success;
        } catch(e) {
            console.error("[G2] playSelectedVfxAt failed:", e);
            return false;
        }
    }
    function spawnLocalVfxFallback(pos: any) {
        try {
            const base = readVec3Components(pos);
            const colors: [number, number, number, number][] = [
                [1.0, 0.55, 0.08, 0.92],
                [1.0, 0.82, 0.18, 0.92],
                [0.96, 0.96, 0.96, 0.88]
            ];
            for (let i = 0; i < 4; i++) {
                const fx = createObject([
                    base[0] + ((Math.random() * 0.35) - 0.175),
                    base[1] + ((Math.random() * 0.35) - 0.05),
                    base[2] + ((Math.random() * 0.35) - 0.175)
                ], identityQuaternion, [
                    0.09 + (Math.random() * 0.08),
                    0.09 + (Math.random() * 0.08),
                    0.09 + (Math.random() * 0.08)
                ], 1, colors[i % colors.length], null, false);
                try { Object.method("Destroy", 2).invoke(fx, 0.45); } catch(_) {}
            }
        } catch(_) {}
    }

    
    interface ButtonInfoConfig {
        buttonText: string;
        method?: () => void;
        enableMethod?: () => void;
        disableMethod?: () => void;
        isTogglable?: boolean;
        toolTip?: string;
        enabled?: boolean;
    }

    class ButtonInfo {
        buttonText: string;
        method?: () => void;
        enableMethod?: () => void;
        disableMethod?: () => void;
        isTogglable: boolean;
        toolTip?: string;
        enabled: boolean;

        constructor(config: ButtonInfoConfig) {
            this.buttonText   = config.buttonText;
            this.method       = config.method;
            this.enableMethod = config.enableMethod;
            this.disableMethod = config.disableMethod;
            this.isTogglable  = config.isTogglable ?? true;
            this.toolTip      = config.toolTip ?? null;
            this.enabled      = config.enabled ?? false;
        }
    }

    function applyMenuStructurePatches() {
        if (menuStructurePatched) return;
        try {
            const renameButton = (list: ButtonInfo[], from: string, to: string, tip: string | null = null) => {
                for (const btn of list) {
                    if (btn.buttonText === from) {
                        btn.buttonText = to;
                        if (tip != null) btn.toolTip = tip;
                        return;
                    }
                }
            };
            const removeButton = (list: ButtonInfo[], text: string) => {
                const idx = list.findIndex(btn => btn.buttonText === text);
                if (idx >= 0) list.splice(idx, 1);
            };
            const mainButtons = buttons[0] ?? [];
            renameButton(mainButtons, "Other player mods", "Whitelist mods", "Opens the whitelist player mods page.");
            renameButton(mainButtons, "Misc", "Over Powered", "Opens the over powered category.");
            // Unity Explorer and Extra WL are intentional main menu buttons — do not remove

            const miscButtons = buttons[9] ?? [];
            renameButton(miscButtons, "Exit Misc", "Exit Over Powered");

            const themeButtons = buttons[12] ?? [];
            removeButton(themeButtons, "Prefab Orbit -> Misc");

            // Extra WL content is embedded in buttons[14] (Monster RPCs array)
            // buttons[16] is now Orbit Mods — do not merge it
        } catch(_) {}
        menuStructurePatched = true;
        try { rebuildButtonMap(); } catch(_) {}
    }
    function dumpMenuToTextFile(): string | null {
        const dumpPath = "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Animal Company\\DabeansSkiddedMenuDump.txt";
        try {
            applyMenuStructurePatches();
            const lines: string[] = [];
            lines.push("[G2] MENU DUMP");
            lines.push("version=" + version);
            lines.push("themeMode=" + themeMode);
            lines.push("time=" + time);
            lines.push("");
            lines.push("Categories:");
            for (let i = 0; i < buttons.length; i++) {
                const page = buttons[i] ?? [];
                lines.push("[" + i + "] count=" + page.length);
                for (let j = 0; j < page.length; j++) {
                    const btn = page[j];
                    lines.push("  (" + j + ") " + btn.buttonText + " | togglable=" + (!!btn.isTogglable) + " | enabled=" + (!!btn.enabled));
                }
            }
            lines.push("");
            lines.push("Item IDs (" + itemIDs.length + "):");
            for (const id of itemIDs) lines.push("  " + id);
            lines.push("");
            lines.push("Prefab IDs (" + prefabIDs.length + "):");
            for (const id of prefabIDs) lines.push("  " + id);
            lines.push("");
            lines.push("Mob IDs (" + mobIDs.length + "):");
            for (const mob of mobIDs) lines.push("  " + mob.name + " | id=" + mob.id);
            lines.push("");
            lines.push("VFX IDs (" + vfxTypeEntries.length + "):");
            for (const [name, value] of vfxTypeEntries) lines.push("  " + name + " = " + value);
            lines.push("");
            lines.push("Assemblies / Classes / Methods:");
            try {
                const assemblies = (Il2Cpp.domain.assemblies ?? []) as any[];
                for (const asm of assemblies) {
                    try {
                        const img = asm.image;
                        const imgName = String(img?.name ?? asm?.name ?? "?");
                        lines.push("[Assembly] " + imgName);
                        for (const klass of ((img?.classes ?? []) as any[])) {
                            try {
                                const className = String(klass?.type?.name ?? klass?.name ?? "?");
                                lines.push("  [Class] " + className);
                                for (const method of ((klass?.methods ?? []) as any[])) {
                                    try {
                                        const paramCount = Number(method?.parameterCount ?? method?.parameters?.length ?? 0);
                                        lines.push("    - " + String(method?.name ?? "?") + "(" + paramCount + ")");
                                    } catch(_) {}
                                }
                            } catch(_) {}
                        }
                    } catch(_) {}
                }
            } catch(_) {}
            const file = new File(dumpPath, "w");
            for (const line of lines) file.write(line + "\n");
            file.flush();
            file.close();
            console.log("[G2] wrote", dumpPath);
            return dumpPath;
        } catch(e) {
            console.error("[G2]", e);
            return null;
        }
    }
    function forceGrantAllStashSlots(): void {
        const tryPatchObject = (obj: any) => {
            try {
                if (!obj || obj.isNull?.()) return;
                for (const fieldName of ["_unlockedStashSlots", "unlockedStashSlots", "_stashSlots", "stashSlots", "_maxStashSlots", "maxStashSlots", "_stashSlotCount", "stashSlotCount", "_stashRowsUnlocked", "stashRowsUnlocked", "_stashColsUnlocked", "stashColsUnlocked"]) {
                    try { obj.field(fieldName).value = 999; } catch(_) {}
                }
                tryCallNames(obj, ["UnlockAllStashSlots", "GrantAllStashSlots", "RefreshStashSlots", "SetUnlockedStashSlots", "SetStashSlots"], 0);
                tryCallNames(obj, ["SetUnlockedStashSlots", "SetStashSlots", "GrantStashSlots"], 1, 999);
                tryCallNames(obj, ["set_stashRowsUnlocked", "set_stashColsUnlocked"], 1, 99);
            } catch(_) {}
        };
        try {
            const AppClass = AssemblyCSharp.class("AnimalCompany.App");
            const appState = AppClass.method("get_state").invoke();
            if (appState && !appState.isNull?.()) {
                tryPatchObject(appState);
                try { tryPatchObject(appState.method("get_user").invoke()); } catch(_) {}
                try { tryPatchObject(appState.method("get_mapMachine").invoke()); } catch(_) {}
                try { tryPatchObject(appState.method("get_stash").invoke()); } catch(_) {}
            }
        } catch(_) {}
        try {
            const UserStashStateClass = AssemblyCSharp.class("AnimalCompany.UserStashState");
            const stashObjects = Object.method("FindObjectsByType", 1).inflate(UserStashStateClass).invoke(0);
            if (stashObjects && !stashObjects.isNull?.()) {
                for (let i = 0; i < stashObjects.length; i++) {
                    try { tryPatchObject(stashObjects.get(i)); } catch(_) {}
                }
            }
        } catch(_) {}
        try {
            const StashViewClass = AssemblyCSharp.class("AnimalCompany.StashMachine.StashMachineStashTabUIView");
            const stashViews = Object.method("FindObjectsByType", 1).inflate(StashViewClass).invoke(0);
            if (stashViews && !stashViews.isNull?.()) {
                for (let i = 0; i < stashViews.length; i++) {
                    try {
                        const view = stashViews.get(i);
                        tryPatchObject(view);
                        tryCallNames(view, ["InitializeCommand", "Refresh", "RefreshSlots", "UpdateSlots", "Reload"], 0);
                    } catch(_) {}
                }
            }
        } catch(_) {}
        try { tryPatchObject(NetPlayer.method("get_localPlayer").invoke()); } catch(_) {}
    }
    function applyContainerFreedomSweep(): void {
        if (time <= containerFreedomSweepDelay) return;
        containerFreedomSweepDelay = time + 0.45;
        try {
            for (const item of getAllLobbyItemGameObjects()) {
                try {
                    const gbi = item.method("GetComponent", 1).inflate(GBIClass).invoke();
                    if (!gbi || gbi.isNull?.()) continue;
                    try { gbi.method("set_allowAddToBag").invoke(true); } catch(_) {}
                    try { gbi.field("_allowAddToBag").value = true; } catch(_) {}
                    try {
                        const itemData = gbi.method("get_itemData").invoke();
                        if (itemData && !itemData.isNull?.()) {
                            const flagsSP = itemData.method("get_flags").invoke();
                            if (flagsSP && !flagsSP.isNull?.()) {
                                try { flagsSP.method("set_value").invoke(8190); } catch(_) {}
                                try { flagsSP.field("_value").value = 8190; } catch(_) {}
                            }
                        }
                    } catch(_) {}
                } catch(_) {}
            }
        } catch(_) {}
    }

    
    let _selfRPCBypass = false;
    function selfRPC(fn) {
        _selfRPCBypass = true;
        try { fn(); } finally { _selfRPCBypass = false; }
    }

    const buttons: ButtonInfo[][] = [

        [ 
            new ButtonInfo({
                buttonText: "Settings",
                method: () => { currentCategory = 2; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens settings."
            }),
            new ButtonInfo({
                buttonText: "Movement mods",
                method: () => { currentCategory = 3; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the player mods category."
            }),
            new ButtonInfo({
                buttonText: "Player mods",
                method: () => { currentCategory = 4; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the movement mods category."
            }),
            new ButtonInfo({
                buttonText: "Whitelist mods",
                method: () => { currentCategory = 10; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the whitelist player mods category."
            }),
            new ButtonInfo({
                buttonText: "Item mods",
                method: () => { currentCategory = 6; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the item mods category."
            }),
            new ButtonInfo({
                buttonText: "Spawning",
                method: () => { currentCategory = 7; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the Spawning category."
            }),
            new ButtonInfo({
                buttonText: "Gun mods",
                method: () => { currentCategory = 8; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the gun mods category."
            }),
            new ButtonInfo({
                buttonText: "Over Powered",
                method: () => { currentCategory = 9; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the over powered category."
            }),
            new ButtonInfo({
                buttonText: "Target Player/ Touch Mods",
                method: () => { currentCategory = 11; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the Target Player/ Touch Mods category."
            }),
            new ButtonInfo({
                buttonText: "Arena Mods",
                method: () => { currentCategory = 12; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the Arena Mods category."
            }),
            new ButtonInfo({
                buttonText: "Orbit Mods",
                method: () => { currentCategory = 21; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the Orbit Mods category."
            }),
            new ButtonInfo({
                buttonText: "RPC Stuff",
                method: () => { currentCategory = 13; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the RPC Stuff category."
            }),

            new ButtonInfo({
                buttonText: "Credits",
                method: () => { currentCategory = 14; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the Credits category."
            }),
            new ButtonInfo({
                buttonText: "Monster RPCs",
                method: () => { currentCategory = 15; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the Monster RPCs category."
            }),
            new ButtonInfo({
                buttonText: "Soundboard",
                method: () => { currentCategory = 22; currentPage = 0; soundboardScanClips(); },
                isTogglable: false,
                toolTip: "Opens the Soundboard — play in-game audio clips."
            }),
            new ButtonInfo({
                buttonText: "Mom Boss",
                method: () => { currentCategory = 23; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens Mom Boss controls."
            }),
        ],

        [ 
            new ButtonInfo({
                buttonText: "Disconnect",
                method: () => {
                    try {
                        const NManagerInst = NManager.method("get_instance").invoke();
                        if (!NManagerInst || NManagerInst.isNull()) return;
                        NManagerInst.method("TryShutdownAndCancelConnecting").invoke();
                    } catch(e) { console.error("[Disconnect]", e); }
                },
                isTogglable: false,
                toolTip: "Disconnects you from the room cleanly."
            }),
            new ButtonInfo({
                buttonText: "PreviousPage",
                method: () => {
                    const lastPage = Math.ceil(buttons[currentCategory].length / 8) - 1;
                    currentPage--;
                    if (currentPage < 0) currentPage = lastPage;
                },
                isTogglable: false
            }),
            new ButtonInfo({
                buttonText: "NextPage",
                method: () => {
                    const lastPage = Math.ceil(buttons[currentCategory].length / 8) - 1;
                    currentPage++;
                    currentPage %= lastPage + 1;
                },
                isTogglable: false
            }),
            new ButtonInfo({
                buttonText: "GlobalReturn",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns you back to the main category."
            }),
        ],

        [ 
            new ButtonInfo({
                buttonText: "Exit Settings",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns you back to the main category."
            }),
            new ButtonInfo({
                buttonText: "Change Item ID",
                method: () => {
                    if(rightGrab){
                       itemIndex--;
                    }
                    else{
                        itemIndex++;
                    }
                    itemIndex = ((itemIndex % itemIDs.length) + itemIDs.length) % itemIDs.length;
                    console.log(itemIDs[itemIndex]);
                    sendNotification("<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> " + "New item index: " + itemIDs[itemIndex], false);
                },
                isTogglable: false,
                toolTip: "Changes the item ID. Hold right grip to go down"
            }),

              new ButtonInfo({
                buttonText: "Change Target Player",
                isTogglable: false,
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        const others: any[] = [];
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            others.push(p);
                        }
                        if (others.length === 0) { sendNotification("No other players found!", false); return; }
                        if (rightGrab) { targetPlayerIndex--; } else { targetPlayerIndex++; }
                        targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
                        const target = others[targetPlayerIndex];
                        const name = getPlayerName(target);
                        sendNotification("<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> Target: " + name + " [" + (targetPlayerIndex + 1) + "/" + others.length + "]", false);
                    } catch(e) { smartError("[Change Target Player]", e); }
                },
                toolTip: "Cycles through other players to select a target for teleport/telekinesis. Hold right grip to go back."
            }),

            new ButtonInfo({
                buttonText: "Change VFX ID",
                method: () => {
                    if (rightGrab) selectedVfxIndex--;
                    else selectedVfxIndex++;
                    selectedVfxIndex = ((selectedVfxIndex % vfxTypeEntries.length) + vfxTypeEntries.length) % vfxTypeEntries.length;
                    const [vfxName, vfxId] = getSelectedVfxEntry();
                    sendNotification("<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> VFX: " + vfxName + " (" + vfxId + ")", false);
                },
                isTogglable: false,
                toolTip: "Changes the selected VFX. Hold right grip to go down."
            }),
            new ButtonInfo({
                buttonText: "Log VFX IDs",
                method: () => {
                    try {
                        console.log("[G2] Available VFX IDs:");
                        for (const [name, value] of vfxTypeEntries) {
                            console.log("[G2] " + name + " = " + value);
                        }
                        sendNotification("Logged " + vfxTypeEntries.length + " VFX IDs to console", false, 6);
                    } catch(e) { console.error("[G2] Log failed:", e); }
                },
                isTogglable: false,
                toolTip: "Logs the full list of selectable VFX names and ids to the console."
            }),
            new ButtonInfo({
                buttonText: "Change Mob ID",
                method: () => {
                    if (rightGrab) {
                        mobIndex--;
                    } else {
                        mobIndex++;
                    }
                    mobIndex = ((mobIndex % mobIDs.length) + mobIDs.length) % mobIDs.length;
                    sendNotification("<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> Mob: " + mobIDs[mobIndex].name + " (id=" + mobIDs[mobIndex].id + ")", false);
                },
                isTogglable: false,
                toolTip: "Changes the mob to spawn. Hold right grip to go back."
            }),
            new ButtonInfo({
                buttonText: "Change Prefab ID",
                method: () => {
                    if (rightGrab) {
                        prefabIndex--;
                    } else {
                        prefabIndex++;
                    }
                    prefabIndex = ((prefabIndex % prefabIDs.length) + prefabIDs.length) % prefabIDs.length;
                    sendNotification("<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> Prefab: " + prefabIDs[prefabIndex], false);
                },
                isTogglable: false,
                toolTip: "Changes the prefab to spawn. Hold right grip to go back."
            }),
            new ButtonInfo({
                buttonText: "Log App ID",
                method: () => {
                    try {
                        const mobileAppID = OculusPlatformSettings.method("get_MobileAppID").invoke();
                        console.log("[G2] Mobile App ID: " + mobileAppID);
                        sendNotification("<color=grey>[</color><color=#8000ff>MENU</color><color=grey>]</color> App ID: " + mobileAppID, false, 10);
                    } catch (e) {
                        console.error("[G2] Failed to get App ID: " + e);
                    }
                },
                isTogglable: false,
                toolTip: "Logs the Meta/Oculus App ID to the console."
            }),
            new ButtonInfo({
                buttonText: "Round Bounds",
                enableMethod: () => { roundCornersEnabled = true; sendNotification("Round Bounds: disabled on this build", false); reloadMenu(); },
                disableMethod: () => { roundCornersEnabled = false; sendNotification("Round Bounds: OFF", false); reloadMenu(); },
                isTogglable: true,
                toolTip: "Reserved setting. Disabled so it does not break the menu look."
            }),
            new ButtonInfo({
                buttonText: "Outline Toggle",
                enableMethod: () => { menuOutlineEnabled = true; sendNotification("Outline: disabled on this build", false); reloadMenu(); },
                disableMethod: () => { menuOutlineEnabled = false; sendNotification("Outline: OFF", false); reloadMenu(); },
                isTogglable: true,
                toolTip: "Reserved setting. Disabled so it does not break the menu look."
            }),
        ],
        [
            new ButtonInfo({
                buttonText: "Exit Movement mods",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns you back to the main category."
            }),
            new ButtonInfo({
        buttonText: "Fly",
        method: () => {
            const rightFist = rightGrab && rightTrigger;
            const leftFist  = leftGrab  && leftTrigger;
            if (!rightFist && !leftFist) {
                smoothVec3(fistFlyVelocity, [0, 0, 0], 0.2);
                return;
            }
            try {
                const player = NetPlayer.method("get_localPlayer").invoke();
                if (!player || player.handle.isNull()) return;

                let desired: [number, number, number] = [0, 0, 0];
                if (rightFist) {
                    const rightForward = readVec3Components(rightHandTransform.method("get_forward").invoke());
                    desired[0] += rightForward[0];
                    desired[1] += rightForward[1];
                    desired[2] += rightForward[2];
                }
                if (leftFist) {
                    const leftForward = readVec3Components(leftHandTransform.method("get_forward").invoke());
                    desired[0] += leftForward[0];
                    desired[1] += leftForward[1];
                    desired[2] += leftForward[2];
                }
                const desiredMag = Math.sqrt((desired[0] * desired[0]) + (desired[1] * desired[1]) + (desired[2] * desired[2]));
                if (desiredMag < 0.01) return;
                const speed = 0.69;
                desired = [
                    (desired[0] / desiredMag) * speed,
                    (desired[1] / desiredMag) * speed,
                    (desired[2] / desiredMag) * speed
                ];
                const smoothed = smoothVec3(fistFlyVelocity, desired, 0.16);
                selfRPC(() => player.method("RPC_AddForce").invoke(smoothed));
            } catch(e) { console.error("Fly:", e); }
        },
                isTogglable: true,
                enableMethod: () => { sendNotification("Fly ON", false); },
                disableMethod: () => { smoothVec3(fistFlyVelocity, [0,0,0], 0.05); sendNotification("Fly OFF", false); },
                toolTip: "Make a fist to fly where you point with slower smoother force."
      }),

new ButtonInfo({
    buttonText: "Joystick Fly (NOT WORKING)",
    isTogglable: true,
    enableMethod: () => { sendNotification("Joystick Fly ON", false); },
    disableMethod: () => { joystickFlyVelocity = [0,0,0]; sendNotification("Joystick Fly OFF", false); },
    toolTip: "Right stick = move, Left stick Y = up/down",

    method: () => {
        try {
            const player = NetPlayer.method("get_localPlayer").invoke();
            if (!player || player.handle.isNull()) return;

            const transform =
                getPlayerHeadTransform(player) ??
                getTransform(player);

            const forward = readVec3Components(
                transform.method("get_forward").invoke()
            );

            const right = readVec3Components(
                transform.method("get_right").invoke()
            );

            const [fx, fz] = normalizeXZ(forward[0], forward[2]);
            const [rx, rz] = normalizeXZ(right[0], right[2]);

            const input = {
                rightX: typeof rightStickX === "number" ? rightStickX : 0,
                rightY: typeof rightStickY === "number" ? rightStickY : 0,
                leftY:  typeof leftStickY  === "number" ? leftStickY  : 0
            };

            const moveForward = input.rightY;
            const moveSide    = input.rightX;
            const moveUp      = input.leftY;

            let vx = (fx * moveForward) + (rx * moveSide);
            let vy = moveUp;
            let vz = (fz * moveForward) + (rz * moveSide);

            const mag = Math.sqrt(vx*vx + vy*vy + vz*vz);

            if (mag < 0.02) {
                joystickFlyVelocity = smoothVec3(
                    joystickFlyVelocity,
                    [0, 0, 0],
                    0.25
                );
                return;
            }

            const speed = 1.8;

            const desired: [number, number, number] = [
                (vx / mag) * speed,
                vy * speed,
                (vz / mag) * speed
            ];

            joystickFlyVelocity = smoothVec3(
                joystickFlyVelocity,
                desired,
                0.2
            );

            selfRPC(() =>
                player.method("RPC_AddForce").invoke(joystickFlyVelocity)
            );

        } catch (e) {
            console.error("JoystickFly ERROR:", e);
        }
    }
}),
            new ButtonInfo({
                buttonText: "Inf Fart Jump",
                enableMethod: () => {
                    infFartJumpEnabled = true;
                    infFartJumpDelay = 0;
                    infFartJumpOriginals.clear();
                    sendNotification("Inf Fart Jump ON", false);
                },
                disableMethod: () => {
                    infFartJumpEnabled = false;
                    try {
                        if (GTPlayer && !GTPlayer.isNull?.()) {
                            for (const [fname, original] of infFartJumpOriginals) {
                                try { GTPlayer.field(fname).value = original; } catch(_) {}
                            }
                        }
                    } catch(_) {}
                    try {
                        if (infFartJumpOriginals.size === 0 && GTPlayer && !GTPlayer.isNull?.()) {
                            const fields = GTPlayerClass.fields as any[];
                            for (const f of fields) {
                                try {
                                    const fname = String(f.name).toLowerCase();
                                    if (fname.includes("fart") || fname.includes("bean") || fname.includes("midair") || fname.includes("jump")) {
                                        const val = GTPlayer.field(f.name).value;
                                        if (typeof val === "boolean") GTPlayer.field(f.name).value = false;
                                        else if (typeof val === "number") GTPlayer.field(f.name).value = 0;
                                    }
                                } catch(_) {}
                            }
                        }
                    } catch(_) {}
                    infFartJumpOriginals.clear();
                    sendNotification("Inf Fart Jump OFF", false);
                },
                method: () => {
                    if (!infFartJumpEnabled) return;
                    if (time < infFartJumpDelay) return;
                    infFartJumpDelay = time + 0.3;
                    try {
                        if (!GTPlayer || GTPlayer.isNull?.()) return;
                        const fields = GTPlayerClass.fields as any[];
                        for (const f of fields) {
                            try {
                                const fname = String(f.name).toLowerCase();
                                if (fname.includes("fart") || fname.includes("bean") ||
                                    fname.includes("midairjump") || fname.includes("mid_air") ||
                                    fname.includes("doublejump") || fname.includes("double_jump") ||
                                    fname.includes("canfart") || fname.includes("hasfart") ||
                                    fname.includes("fartboost") || fname.includes("jumpboost") ||
                                    fname.includes("jumpsleft") || fname.includes("jumpsremaining") ||
                                    fname.includes("extrajump") || fname.includes("jumpcount") ||
                                    fname.includes("midaircount") || fname.includes("fartcount")) {
                                    try {
                                        const val = GTPlayer.field(f.name).value;
                                        if (!infFartJumpOriginals.has(f.name)) infFartJumpOriginals.set(f.name, val);
                                        if (typeof val === "boolean") GTPlayer.field(f.name).value = true;
                                        else if (typeof val === "number") GTPlayer.field(f.name).value = 99;
                                    } catch(_) {}
                                }
                            } catch(_) {}
                        }
                    } catch(e) { console.error("FartJump err:", e); }
                },
                isTogglable: true,
                toolTip: "Keeps fart/bean jump fields maxed every 0.3s."
            }),
            new ButtonInfo({
                buttonText: "Platforms",
                enableMethod: () => {
                    Destroy(movementPlatformLeft);
                    Destroy(movementPlatformRight);
                    movementPlatformLeft = null;
                    movementPlatformRight = null;
                    sendNotification("Platforms ON", false);
                },
                disableMethod: () => {
                    Destroy(movementPlatformLeft);
                    Destroy(movementPlatformRight);
                    movementPlatformLeft = null;
                    movementPlatformRight = null;
                    sendNotification("Platforms OFF", false);
                },
                isTogglable: true,
                method: () => {
                    try {
                        const updateHandPlatform = (handTransform: any, isHeld: boolean, wasHeld: boolean, side: "left" | "right") => {
                            const current = side === "left" ? movementPlatformLeft : movementPlatformRight;
                            if (!isHeld) {
                                Destroy(current);
                                if (side === "left") movementPlatformLeft = null;
                                else movementPlatformRight = null;
                                return;
                            }
                            if (!wasHeld) {
                                const handPos = handTransform.method("get_position").invoke();
                                const downPos = [
                                    (handPos.field("x").value as number),
                                    (handPos.field("y").value as number) - 0.18,
                                    (handPos.field("z").value as number)
                                ];
                                const created = createSolidPlatform(downPos, [0.24, 0.025, 0.24], [0.95, 0.40, 0.03, 0.92]);
                                if (side === "left") movementPlatformLeft = created;
                                else movementPlatformRight = created;
                            }
                        };
                        updateHandPlatform(leftHandTransform, leftGrab, prevLeftGrab, "left");
                        updateHandPlatform(rightHandTransform, rightGrab, prevRightGrab, "right");
                    } catch(e) { console.error("Platforms:", e); }
                },
                toolTip: "Hold either grip to keep a solid platform directly under that hand."
            }),
            new ButtonInfo({
        buttonText: "Long Arms",
        method: () => {
          getTransform(GTPlayer).method("set_localScale").invoke([1.25, 1.25, 1.25]);
        },
        disableMethod: () => {
          getTransform(GTPlayer).method("set_localScale").invoke(oneVector);
        },
        toolTip: "Gives you longer arms."
      }),
            new ButtonInfo({
        buttonText: "Longer Arms",
        method: () => {
          getTransform(GTPlayer).method("set_localScale").invoke([1.75, 1.75, 1.75]);
        },
        disableMethod: () => {
          getTransform(GTPlayer).method("set_localScale").invoke(oneVector);
        },
        toolTip: "Gives you longer arms."
      }),
                  new ButtonInfo({
        buttonText: "Longerer Arms",
        method: () => {
          getTransform(GTPlayer).method("set_localScale").invoke([2, 2, 2]);
        },
        disableMethod: () => {
          getTransform(GTPlayer).method("set_localScale").invoke(oneVector);
        },
        toolTip: "Gives you longer arms."
      }),
                  new ButtonInfo({
        buttonText: "Longererer Arms",
        method: () => {
          getTransform(GTPlayer).method("set_localScale").invoke([3, 3, 3]);
        },
        disableMethod: () => {
          getTransform(GTPlayer).method("set_localScale").invoke(oneVector);
        },
        toolTip: "Gives you longer arms."
      }),
        ],
        [
            new ButtonInfo({
                buttonText: "Exit Player mods",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns you back to the main category."
            }),
      new ButtonInfo({
        buttonText: "Invisible Toggleable",
        enableMethod: () => {
          const player = PCClass.method("get_instance").invoke();
          const RIGTESTBETA = player.method("get_playerView").invoke();
          if (!RIGTESTBETA) return null;
          const bodyRootTF = RIGTESTBETA.field("_cameraTransform").value;
          if (!bodyRootTF) return null;
          bodyRootTF.method("set_position").invoke([0, -99999, 0]);
        },
        disableMethod: () => {
          const player = PCClass.method("get_instance").invoke();
          const RIGTESTBETA = player.method("get_playerView").invoke();
          if (!RIGTESTBETA) return null;
          const bodyRootTF = RIGTESTBETA.field("_cameraTransform").value;
          if (!bodyRootTF) return null;
          bodyRootTF.method("set_position").invoke(getTransform(headCollider).method("get_position").invoke());
        },
        isTogglable: true,
        toolTip: "Turns you invisible."
      }),
                  new ButtonInfo({
    buttonText: "Invincible",
    enableMethod: () => {
        const localPlayer = NetPlayer.method("get_localPlayer").invoke();
        localPlayer.method("set_isInvincible").invoke(true);
    },
    disableMethod: () => {
        const localPlayer = NetPlayer.method("get_localPlayer").invoke();
        localPlayer.method("set_isInvincible").invoke(false);
    },
    isTogglable: true,
    toolTip: "Makes you invincible"
}),
new ButtonInfo({
    buttonText: "Inf Health",
    enableMethod: () => { infHealthEnabled = true; sendNotification("Inf Health ON", false); },
    disableMethod: () => { infHealthEnabled = false; sendNotification("Inf Health OFF", false); },
    isTogglable: true,
    toolTip: "Hooks get_maxHealth to return 999999 for you only."
}),
new ButtonInfo({
    buttonText: "Blue Name Tags",
    enableMethod: () => { nameTagsEnabled = true; sendNotification("Blue Name Tags ON", false); },
    disableMethod: () => { nameTagsEnabled = false; destroyOverlayEntries(playerNameTagEntries); sendNotification("Blue Name Tags OFF", false); },
    isTogglable: true,
    method: () => { updatePlayerNameTags(); },
    toolTip: "Shows blue usernames above every player's head and keeps them facing you."
}),
new ButtonInfo({
    buttonText: "Arena ESP",
    enableMethod: () => { arenaEspEnabled = true; sendNotification("Arena ESP ON", false); },
    disableMethod: () => { arenaEspEnabled = false; destroyOverlayEntries(playerEspEntries); sendNotification("Arena ESP OFF", false); },
    isTogglable: true,
    method: () => { updatePlayerEspOverlays(); },
    toolTip: "Client-side through-wall player rays and 2D style boxes using always-on-top arena-style overlay materials."
}),
new ButtonInfo({
    buttonText: "Dual Revolver Punch Launch",
    isTogglable: true,
    method: () => {
        if (time <= dualRevolverPunchDelay) return;
        try {
            const me = NetPlayer.method("get_localPlayer").invoke();
            if (!me || me.isNull?.()) return;
            const myHead = getTransform(headCollider).method("get_position").invoke();
            const myBody = getTransform(bodyCollider).method("get_position").invoke();
            for (const p of getAllNetPlayersList(false)) {
                try {
                    const leftHeld = getPlayerHeldGrabbable(p, 0);
                    const rightHeld = getPlayerHeldGrabbable(p, 1);
                    if (!grabbableLooksLikeRevolver(leftHeld) || !grabbableLooksLikeRevolver(rightHeld)) continue;
                    const leftTf = getPlayerHandAnchorTransform(p, 0);
                    const rightTf = getPlayerHandAnchorTransform(p, 1);
                    let hitTf = null;
                    try {
                        if (leftTf && !leftTf.isNull?.()) {
                            const leftPos = leftTf.method("get_position").invoke();
                            if ((Vector3.method("Distance").invoke(myHead, leftPos) as number) <= 0.52 || (Vector3.method("Distance").invoke(myBody, leftPos) as number) <= 0.7) hitTf = leftTf;
                        }
                    } catch(_) {}
                    try {
                        if (!hitTf && rightTf && !rightTf.isNull?.()) {
                            const rightPos = rightTf.method("get_position").invoke();
                            if ((Vector3.method("Distance").invoke(myHead, rightPos) as number) <= 0.52 || (Vector3.method("Distance").invoke(myBody, rightPos) as number) <= 0.7) hitTf = rightTf;
                        }
                    } catch(_) {}
                    if (!hitTf) continue;
                    dualRevolverPunchDelay = time + 0.12;
                    const launchDir = getLaunchForward(hitTf, getTransform(headCollider));
                    const launchForce = Vector3.method("op_Addition").invoke(
                        Vector3.method("op_Multiply", 2).invoke(launchDir, 3.4),
                        [0, 1.05, 0]
                    );
                    selfRPC(() => me.method("RPC_AddForce").invoke(launchForce));
                    break;
                } catch(_) {}
            }
        } catch(e) { console.error("Dual Revolver Punch Launch:", e); }
    },
    toolTip: "Anyone holding revolvers in both hands can punch-launch you when they get close."
}),
        ],
        [
            new ButtonInfo({
                buttonText: "Exit Other Players",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns you back to the main category."
            }),
            new ButtonInfo({
                buttonText: "Whitelist mods",
                method: () => { currentCategory = 10; currentPage = 0; },
                isTogglable: false,
                toolTip: "Opens the test category."
            }),
        ],
        [
            new ButtonInfo({
                buttonText: "Exit Item mods",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns you back to the main category."
            }),

    new ButtonInfo({
        buttonText: "Custom hue Held Item",
        method: () => {
          try {
            const grabbable = getLocalHeldGrabbable(true);
            if (!grabbable || grabbable.isNull?.()) return;
            if (rightGrab) {
              hueVal++;
              if (hueVal > 127) hueVal = -127;
            }
            if (leftGrab) {
              hueVal--;
              if (hueVal < -127) hueVal = 127;
            }
            grabbable.method("set_colorHue").invoke(hueVal);
          } catch (e) {
            console.error(e);
          }
        },
        isTogglable: true,
        toolTip: "Hold A to increase, grip to decrease scale of held item."
      }),
    new ButtonInfo({
        buttonText: "Custom saturation Held Item",
        method: () => {
          try {
            const grabbable = getLocalHeldGrabbable(true);
            if (!grabbable || grabbable.isNull?.()) return;
            if (rightGrab) {
              satVal++;
              if (satVal > 127) satVal = -127;
            }
            if (leftGrab) {
              satVal--;
              if (satVal < -127) satVal = 127;
            }
            grabbable.method("set_colorSaturation").invoke(satVal);
          } catch (e) {
            console.error(e);
          }
        },
        isTogglable: true,
        toolTip: "Hold A to increase, grip to decrease scale of held item."
      }),
                  new ButtonInfo({
        buttonText: "Custom Scale Held Item",
        method: () => {
          try {
            const grabbable = getLocalHeldGrabbable(true);
            if (!grabbable || grabbable.isNull?.()) return;
            if (rightGrab) {
              scaleVal++;
              if (scaleVal > 127) scaleVal = -127;
            }
            if (leftGrab) {
              scaleVal--;
              if (scaleVal < -127) scaleVal = 127;
            }
            grabbable.method("set_scaleModifier").invoke(scaleVal);
          } catch (e) {
            console.error(e);
          }
        },
        isTogglable: true,
        toolTip: "Hold A to increase, grip to decrease scale of held item."
      }),
            new ButtonInfo({
    buttonText: "Rainbow Held Item",
    method: () => {
        try {
            const player = NetPlayer.method("get_localPlayer").invoke();
            if (!player) return;
            const grabbable = getLocalHeldGrabbable(true);
            if (!grabbable || grabbable.isNull?.()) return;
            if (rightGrab) {
                hueVal++;
                satVal++;
                if (hueVal > 127) hueVal = -127;
                if (satVal > 127) satVal = -127;
            }
            if (leftGrab) {
                hueVal--;
                satVal--;
                if (hueVal < -127) hueVal = 127;
                if (satVal > 127) satVal = -127;
            }
            grabbable.method("set_colorHue").invoke(hueVal);
            grabbable.method("set_colorSaturation").invoke(satVal);
        } catch (e) {
            console.error(e);
        }
    },
    isTogglable: true,
    toolTip: "Hold A to increase, grip to decrease hue of held item."
}),
                new ButtonInfo({
                buttonText: "Bag Inf Capacity",
                enableMethod: () => {
                    try {
                        BackpackItemClass.method("get_capacity").implementation = function() { return 255; };
                        BackpackItemClass.method("get_capacitySafe").implementation = function() { return 255; };
                        sendNotification("Bag Inf Capacity ON", false);
                    } catch(e) { sendNotification("Bag Cap: " + e, false); }
                },
                disableMethod: () => {
                    try {
                        BackpackItemClass.method("get_capacity").implementation = null;
                        BackpackItemClass.method("get_capacitySafe").implementation = null;
                        sendNotification("Bag Inf Capacity OFF", false);
                    } catch(e) {}
                },
                isTogglable: true,
                toolTip: "Backpacks report 255 capacity. Equivalent to BackpackCapacity skill maxed."
            }),
            new ButtonInfo({
                buttonText: "Quiver Inf Capacity",
                enableMethod: () => {
                    try {
                        QuiverClass.method("get_capacity").implementation = function() { return 255; };
                        sendNotification("Quiver Inf Capacity ON", false);
                    } catch(e) { sendNotification("Quiver Cap: " + e, false); }
                },
                disableMethod: () => {
                    try {
                        QuiverClass.method("get_capacity").implementation = null;
                        sendNotification("Quiver Inf Capacity OFF", false);
                    } catch(e) {}
                },
                isTogglable: true,
                toolTip: "Quivers report 255 capacity. Equivalent to QuiverCapacity skill maxed."
            }),


        ],
        [
            new ButtonInfo({
                buttonText: "Exit Spawning mods",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns you back to the main category."
            }),
            new ButtonInfo({
                buttonText: "Spawn blood",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const pos = getTransform(player).method("get_position").invoke();
                        PrefabGen.method("GeneratePrefab").invoke(0, pos, identityQuaternion, false);
                    } catch(e) { console.error("Spawn poop error:", e); }
                },
                isTogglable: true,
                toolTip: "Spawns a blood prefab at your position."
            }),
                
            new ButtonInfo({
            buttonText: "Set Shredder Nuts",
            method: () => {
                try {
                    const ShredderClass = AssemblyCSharp.class("AnimalCompany.ItemShredder");
                    const shredders = Object.method("FindObjectsByType", 1).inflate(ShredderClass).invoke(0);
                    let count = 0;
                    if (shredders && !shredders.isNull()) {
                        for (let i = 0; i < shredders.length; i++) {
                            try { shredders.get(i).method("set_shreddedValue").invoke(customShredderNuts); count++; } catch(_) {}
                        }
                    }
                    sendNotification("Set " + count + " shredder(s) to " + customShredderNuts + " nuts", false);
                } catch(e) { sendNotification("Shredder error: " + e, false); }
            },
            isTogglable: false,
            toolTip: "Sets nut count on all shredders in scene. Adjust customShredderNuts in console."
        }),
    
                    new ButtonInfo({
            buttonText: "Shredder Nuts +",
            method: () => { customShredderNuts = Math.min(customShredderNuts + 100000, 999999999); sendNotification("Shredder nuts: " + customShredderNuts, false); },
            isTogglable: false,
            toolTip: "Increases shredder nut value by 100,000."
        }),
        new ButtonInfo({
            buttonText: "Shredder Nuts -",
            method: () => { customShredderNuts = Math.max(customShredderNuts - 100000, 0); sendNotification("Shredder nuts: " + customShredderNuts, false); },
            isTogglable: false,
            toolTip: "Decreases shredder nut value by 100,000"
        }),
        
                        new ButtonInfo({
                buttonText: "Delete Obj Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.3;
                        try {
                            const hitCollider = ray.method("get_collider").invoke();
                            if (!hitCollider || hitCollider.isNull()) return;
                            const hitGO = hitCollider.method("get_gameObject").invoke();
                            if (!hitGO || hitGO.isNull()) return;
                            
                            let runner: any = null;
            try { runner = getSfxCurrentRunner(); } catch(_) {}
            try { if (!runner || runner.isNull()) runner = Il2Cpp.domain.assembly("Fusion.Runtime").image.class("Fusion.NetworkRunner").method("get_Instance").invoke(); } catch(_) {}
            if (!runner || runner.isNull()) { sendNotification("No runner found", false); return; }
                            
                            let despawned = false;
                            try {
                                const gbo = hitGO.method("GetComponentInParent", 0).inflate(GBOClass).invoke();
                                if (gbo && !gbo.isNull()) {
                                    const netObj = gbo.method("get_Object").invoke();
                                    if (netObj && !netObj.isNull()) {
                                        runner.method("Despawn").invoke(netObj);
                                        sendNotification("Deleted (synced)!", false);
                                        despawned = true;
                                    }
                                }
                            } catch(_) {}
                            if (!despawned) {
                                
                                try {
                                    const NetworkObjectClass = Il2Cpp.domain.assembly("Fusion.Runtime").image.class("Fusion.NetworkObject");
                                    const netObj2 = hitGO.method("GetComponentInParent", 0).inflate(NetworkObjectClass).invoke();
                                    if (netObj2 && !netObj2.isNull()) {
                                        runner.method("Despawn").invoke(netObj2);
                                        sendNotification("Deleted (synced)!", false);
                                        despawned = true;
                                    }
                                } catch(_) {}
                            }
                            if (!despawned) {
                                
                                Destroy(hitGO);
                                sendNotification("Destroyed (local only)", false);
                            }
                        } catch(e) { sendNotification("Delete failed: " + e, false); }
                    }
                },
                toolTip: "Point at any object and pull trigger to delete it synced for all players (hold grip)."
            }),
        
            new ButtonInfo({
                buttonText: "Freez Item on Position",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const interactor = player.method("GetHandInteractor", 1).invoke(1);
                        if (!interactor) return;
                        const itemAnchor = interactor.field("_itemAnchor").value;
                        if (!itemAnchor) return;
                        const grabbable = itemAnchor.method("get_grabbableObject").invoke();
                        if (!grabbable || grabbable.isNull()) { sendNotification("Not holding anything", false); return; }
                        const pos = getTransform(grabbable).method("get_position").invoke();
                        
                        try {
                            const rb = getComponent(grabbable.method("get_gameObject").invoke(), RigidbodyClass);
                            if (rb && !rb.isNull()) rb.method("set_isKinematic").invoke(true);
                        } catch(_) {}
                        const entry = grabbable;
                        (entry as any)._lockedPos = pos;
                        lockedItems.push(entry);
                        sendNotification("Item locked in place!", false);
                    } catch(e) { sendNotification("Lock item: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Freezes your held item in place."
            }),

            
            new ButtonInfo({
        buttonText: "Spawn Items",
        method: () => {
          const handTransform = rightHandTransform;
          if (rightSecondary && rightGrab) {
            try {
              const forward = getLaunchForward(handTransform);
              const up = getLaunchUp(handTransform, forward);
              const spawnPos = Vector3.method("op_Addition").invoke(
                handTransform.method("get_position").invoke(),
                Vector3.method("op_Addition").invoke(
                  Vector3.method("op_Multiply", 2).invoke(forward, 0.38),
                  Vector3.method("op_Multiply", 2).invoke(up, -0.03)
                )
              );
              const result = spawnItemAtPos(itemIDs[itemIndex], spawnPos, getLaunchRotation(handTransform, forward, up));
              if (!result || result.handle.isNull()) {
                sendNotification("Spawn returned null: " + itemIDs[itemIndex], false);
              } else {
                sendNotification("Spawned: " + itemIDs[itemIndex], false);
              }
            } catch (e) {
              console.error("Hand spawn error:", e);
              sendNotification("Spawn failed: " + e, false);
            }
          }
        },
        isTogglable: true,
        toolTip: "Spawns items in your right hand (hold grip + B)."
      }),



        new ButtonInfo({
        buttonText: "Spawn Items Gun",
        isTogglable: true,
        method: () => {
          if (!rightGrab) return;
          let gunData = null;
          try { gunData = renderGun(); } catch(_) { return; }
          if (!gunData) return;
          const ray = gunData.ray;
          if (!ray || ray.handle.isNull()) return;
          if (rightTrigger && time > itemGunDelay) {
            itemGunDelay = time + 0.1;
            try {
              const hitPoint = ray.method("get_point").invoke();
              const result = spawnItemAtPos(itemIDs[itemIndex], hitPoint, identityQuaternion);
              if (!result || result.handle.isNull()) {
                sendNotification("Spawn returned null: " + itemIDs[itemIndex], false);
              } else {
                console.log("\u2713 Spawned item:", itemIDs[itemIndex]);
                sendNotification("Spawned: " + itemIDs[itemIndex], false);
              }
            } catch (e) {
              console.error("Item spawn error:", e);
              sendNotification("Spawn failed: " + e, false);
            }
          }
        },
        toolTip: "Spawns items where you aim (hold grip, pull trigger)."
      }),

        new ButtonInfo({
            buttonText: "Spawn Mob",
            method: () => {
                const handTransform = rightHandTransform;
                if (rightSecondary && rightGrab) {
                    const mob = mobIDs[mobIndex];
                    const forward = getLaunchForward(handTransform);
                    const up = getLaunchUp(handTransform, forward);
                    const pos = Vector3.method("op_Addition").invoke(
                        handTransform.method("get_position").invoke(),
                        Vector3.method("op_Addition").invoke(
                            Vector3.method("op_Multiply", 2).invoke(forward, 0.55),
                            Vector3.method("op_Multiply", 2).invoke(up, -0.03)
                        )
                    );
                    const rot = getLaunchRotation(handTransform, forward, up);
                    spawnMobAtPos(mob, pos, rot);
                    sendNotification("Spawning mob: " + mob.name + " (id=" + mob.id + ")", false);
                }
            },
            isTogglable: true,
            toolTip: "Spawns mob at your right hand via SpawnMobAsync (hold grip + B)."
        }),

        new ButtonInfo({
            buttonText: "Spawn Mob Gun",
            isTogglable: true,
            method: () => {
                if (!rightGrab) return;
                const gunData = renderGun();
                const ray = gunData.ray;
                if (!ray || ray.handle.isNull()) return;
                if (rightTrigger && time > mobGunDelay2) {
                    mobGunDelay2 = time + 0.3;
                    const hitPoint = ray.method("get_point").invoke();
                    const mob = mobIDs[mobIndex];
                    spawnMobAtPos(mob, hitPoint, identityQuaternion);
                    sendNotification("Spawning: " + mob.name + " (id=" + mob.id + ")", false);
                }
            },
            toolTip: "Spawns mob where you aim via SpawnMobAsync (hold grip, pull trigger)."
        }),
        new ButtonInfo({
            buttonText: "Force Spawned Mobs Stay",
            enableMethod: () => { mobForceStayEnabled = true; sendNotification("Force Spawned Mobs Stay ON", false); },
            disableMethod: () => { mobForceStayEnabled = false; sendNotification("Force Spawned Mobs Stay OFF", false); },
            isTogglable: true,
            toolTip: "Keeps tracked spawned mobs active and respawns them if they drop out."
        }),

        new ButtonInfo({
                buttonText: "Prefab Spawn Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > itemGunDelay) {
                        itemGunDelay = time + 0.3;
                        try {
                            const hitPoint = ray.method("get_point").invoke();
                            const name = prefabIDs[prefabIndex];
                            const result = spawnNetworkPrefab(name, hitPoint, identityQuaternion);
                            if (result && !result.isNull()) {
                                sendNotification("Spawned: " + name, false);
                            } else {
                                sendNotification("Not found in PrefabTable: " + name, false);
                            }
                        } catch(e) { sendNotification("Prefab spawn failed: " + e, false); }
                    }
                },
                toolTip: "Spawns selected prefab where you aim via NetworkRunner (hold grip + trigger)."
            }),


            

        ],
        [
            new ButtonInfo({
                buttonText: "Exit Gun mods",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns you back to the main category."
            }),
             new ButtonInfo({
                buttonText: "Stinky Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.01;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            target.player.method("RPC_TagAsStinky").invoke();
                            sendNotification("Stinkied " + target.id + "!", false);
                        } catch(e) { console.error("WL Stinky:", e); }
                    }
                },
                toolTip: "Tags a  player as stinky (hold grip + trigger)."
            }),
            new ButtonInfo({
                buttonText: "Color Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.01;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            const h = (time * 0.01) % 1.0;
                            target.player.method("RPC_SetColorHSV").invoke(99999.0, h, 1.0, 1.0);
                            sendNotification("Rainbow'd " + target.id + "!", false);
                        } catch(e) { console.error("WL Color:", e); }
                    }
                },
                toolTip: "Sets a  player to a rainbow color (hold grip + trigger)."
            }),
    

            new ButtonInfo({
                buttonText: "Disintegrate Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            const targetPos = getTransform(target.player).method("get_position").invoke();
                            const NetworkRunner2 = getSfxCurrentRunner();
                            const allVFX = [
                                VFXTypes.MeatExplosion_1, VFXTypes.MeatExplosion_2, VFXTypes.MeatExplosion_Headshot,
                                VFXTypes.Explosion_Coins, VFXTypes.Explosion_Feathers, VFXTypes.ConfettiBurst,
                                VFXTypes.Ethereal_Void, VFXTypes.Electricity_Small, VFXTypes.FuelExplosion
                            ];
                            for (const vfxType of allVFX) {
                                try { ParticleManagerClass.method("RPC_PlayVFX", 4).invoke(NetworkRunner2, vfxType, targetPos, identityQuaternion); } catch(_) {}
                            }
                            target.player.method("RPC_Teleport").invoke([0, -9999999, 0]);
                            target.player.method("RPC_AddForce").invoke([0, 2000, 0]);
                            sendNotification("Disintegrated WL player: " + target.id, false);
                        } catch(e) { console.error("WL Disintegrate Gun:", e); }
                    }
                },
                toolTip: "Disintegrates a  player with VFX (hold grip + trigger)."
            }),




new ButtonInfo({
    buttonText: "Freeze Gun NW",
    isTogglable: true,
    enableMethod: () => {
        _freezeGunActive = true;
        _freezeGunPos = null;
        _freezeGunTargetPlayer = null;
        sendNotification("Freeze Gun ON — schieße auf Spieler um ihn einzufrieren", false, 3);
    },
    disableMethod: () => {
        _freezeGunActive = false;
        _freezeGunPos = null;
        _freezeGunTargetPlayer = null;
        sendNotification("Freeze Gun OFF", false, 2);
    },
    method: () => {
        if (!_freezeGunActive) return;

        // Gun visuelle Effekte
        if (!rightGrab) {
            if (GunPointer) GunPointer.method("SetActive").invoke(false);
            if (GunLine) GunLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            return;
        }

        const gunData = renderGun();
        
        // Schießen: Spieler auswählen und Position speichern (wie enableMethod vom Target)
        if (rightTrigger && time > _freezeGunDelay) {
            _freezeGunDelay = time + 0.3;
            if (gunData.ray && !gunData.ray.isNull()) {
                try {
                    const hitPoint = gunData.endPosition;
                    const allPlayers = Object.method("FindObjectsByType", 1).inflate(NetPlayer).invoke(0);
                    let closestPlayer = null;
                    let closestDist = 5.0;

                    for (let i = 0; i < allPlayers.length; i++) {
                        const p = allPlayers.get(i);
                        if (!p || p.isNull() || playerIsLocal(p)) continue;
                        const pPos = getTransform(p).method("get_position").invoke();
                        const dist = Vector3.method("Distance").invoke(hitPoint, pPos);
                        if (dist < closestDist) {
                            closestDist = dist;
                            closestPlayer = p;
                        }
                    }

                    if (closestPlayer && !closestPlayer.isNull()) {
                        // Speichere Position des getroffenen Spielers
                        _freezeGunPos = getTransform(closestPlayer).method("get_position").invoke();
                        _freezeGunTargetPlayer = closestPlayer;
                        sendNotification("Gefroren: " + getPlayerName(closestPlayer), false, 3);
                    }
                } catch(e) {}
            }
        }

        // Kontinuierliche Teleport-Schleife (wie method vom Target)
        if (_freezeGunActive && _freezeGunPos && _freezeGunTargetPlayer && !_freezeGunTargetPlayer.isNull()) {
            if (time < _freezeGunDelay) return;
            _freezeGunDelay = time + 0.05;
            try {
                _freezeGunTargetPlayer.method("RPC_Teleport").invoke(_freezeGunPos);
            } catch(e) {}
        }
    },
    toolTip: "Schieße auf einen Spieler um seine Position zu speichern. Er wird dauerhaft dorthin zurückteleportiert (alle 0.05s)."
}),
            new ButtonInfo({
                buttonText: "Hit 50 Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.4;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            const pos = getTransform(target.player).method("get_position").invoke();
                            const dmgNull = DamageSourceInfoClass.method("get_Null").invoke();
                            target.player.method("RPC_PlayerHit", 3).invoke(50, pos, dmgNull);
                            sendNotification("Hit WL player 50dmg: " + target.id, false);
                        } catch(e) { console.error("WL Hit 50:", e); }
                    }
                },
                toolTip: "Deals 50 damage to a  player (hold grip + trigger)."
            }),

            new ButtonInfo({
                buttonText: "kill gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.4;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            const pos = getTransform(target.player).method("get_position").invoke();
                            const dmgNull = DamageSourceInfoClass.method("get_Null").invoke();
                            target.player.method("RPC_PlayerHit", 3).invoke(9999999, pos, dmgNull);
                            sendNotification("Hit WL player 999999dmg: " + target.id, false);
                        } catch(e) { console.error("WL Hit 99999999:", e); }
                    }
                },
                toolTip: "kills player"
            }),

            new ButtonInfo({
                buttonText: "WL Void Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            target.player.method("RPC_Teleport").invoke([0, -99999, 0]);
                            sendNotification("Voided WL player: " + target.id, false);
                        } catch(e) { console.error("WL Void Gun:", e); }
                    }
                },
                toolTip: "Teleports a  player to the void (hold grip + trigger)."
            }),
            
            new ButtonInfo({
              buttonText: "TP ALL Gun",
              method: () => {
                if (!rightGrab) return;
                const gunData = renderGun();
                const ray = gunData.ray;
                if (!rightTrigger) return;
                if (!ray || ray.isNull()) return;
                try {
                    const hitPoint = ray.method("get_point").invoke();
                    const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                    const playerValues = playerDict.method("get_Values").invoke();
                    const enumerator = playerValues.method("GetEnumerator").invoke();
                    while (enumerator.method("MoveNext").invoke()) {
                        const netPlayer = enumerator.method("get_Current").invoke();
                        if (!netPlayer || netPlayer.handle.isNull()) continue;
                        if (netPlayer.method("get_IsMine").invoke()) continue;
                        netPlayer.method("RPC_Teleport").invoke(hitPoint);
                    }
                } catch (e) {
                    console.error("TP ALL Gun error:", e);
                }
              },
              isTogglable: true,
              toolTip: "Teleports all players to your gun pointer."
            }),
            new ButtonInfo({
              buttonText: "Give Fly Gun",
              enableMethod: () => { sendNotification("Give Fly Gun ON", false); },
              disableMethod: () => { sendNotification("Give Fly Gun OFF", false); },
              method: () => {
                if (!rightGrab) return;
                const gunData = renderGun();
                if (rightTrigger && time > lagGunDelay) {
                    lagGunDelay = time + 0.03;
                    try {
                        const target = resolveGunTargetPlayer(gunData, 10.0);
                        if (!target || target.isNull?.()) { sendNotification("No player there", false); return; }
                        if (playerIsLocal(target)) return;
                        const originTf = getPlayerHandAnchorTransform(target, 1) ?? getPlayerProjectileOriginTransform(target);
                        const forward = originTf && !originTf.isNull?.()
                            ? getLaunchForward(originTf, getTransform(target))
                            : getLaunchForward(getTransform(target), getTransform(headCollider));
                        const smoothFly = Vector3.method("op_Addition").invoke(
                            Vector3.method("op_Multiply", 2).invoke(forward, 0.34),
                            [0, 0.03, 0]
                        );
                        target.method("RPC_AddForce").invoke(smoothFly);
                        sendNotification("Gave fly boost to " + getPlayerName(target), false);
                    } catch(e) { console.error("Give Fly Gun:", e); }
                }
              },
              isTogglable: true,
              toolTip: "Point at any player and give them a smooth forward fly force (hold grip + trigger)."
            }),

    new ButtonInfo({
    buttonText: "Kick Gun",
    enableMethod: () => { kickGunEnabled = true; flingGunEnabled = false; teleportGunEnabled = false; colorGunEnabled = false; spazColorGunEnabled = false; prefabGunEnabled = false; spawnGunEnabled = false; telekinesisGunEnabled = false; },
    disableMethod: () => { kickGunEnabled = false; },
    method: () => {
        if (!kickGunEnabled) return;
        if (!rightGrab) {
            if (GunPointer) GunPointer.method("SetActive").invoke(false);
            if (GunLine) GunLine.method("get_gameObject").invoke().method("SetActive").invoke(false);
            return;
        }
        const gunData = renderGun();
        if (!rightTrigger) return;
        if (!gunData.ray || gunData.ray.isNull()) return;
        
        try {
            const hitPoint = gunData.endPosition;
            const allPlayers = Object.method("FindObjectsByType", 1).inflate(NetPlayer).invoke(0);
            let closestPlayer = null;
            let closestDist = 5.0;
            
            for (let i = 0; i < allPlayers.length; i++) {
                const p = allPlayers.get(i);
                if (!p || p.isNull() || playerIsLocal(p)) continue;
                const pPos = getTransform(p).method("get_position").invoke();
                const dist = Vector3.method("Distance").invoke(hitPoint, pPos) as number;
                if (dist < closestDist) {
                    closestDist = dist;
                    closestPlayer = p;
                }
            }
            
            if (closestPlayer && !closestPlayer.isNull()) {
                kickPlayer(closestPlayer);
                sendNotification("Kicked player!", false);
            }
        } catch(e) {}
    },
    isTogglable: true,
    toolTip: "Shoot a player to kick them from the lobby."
}),
            new ButtonInfo({
              buttonText: "Get Player Info Gun",
              method: () => {
                if (!rightGrab) return;
                const gunData = renderGun();
                if (!rightTrigger || time <= idGunDelay) return;
                idGunDelay = time + 0.25;
                try {
                    const target = resolveGunTargetPlayer(gunData, 10.0);
                    if (!target || target.isNull?.()) { sendNotification("No player there", false); return; }
                    dumpPlayerInfoToTerminal(target);
                    sendNotification("Dumped info for " + getPlayerName(target), false);
                } catch(e) { console.error("Get Player Info Gun:", e); }
              },
              isTogglable: true,
              toolTip: "Aim at a player and dump their names, IDs, tokens, and related info into the terminal."
            }),
            new ButtonInfo({
              buttonText: "Delete Player Gun",
              method: () => {
                if (!rightGrab) return;
                const gunData = renderGun();
                if (!rightTrigger || time <= deletePlayerGunDelay) return;
                deletePlayerGunDelay = time + 0.3;
                try {
                    const target = resolveGunTargetPlayer(gunData, 10.0);
                    if (!target || target.isNull?.()) { sendNotification("No player there", false); return; }
                    if (playerIsLocal(target)) return;
                    const targetName = getPlayerName(target);
                    try { target.method("RPC_DoPlayerDie").invoke(true); } catch(_) {}
                    try { target.method("RPC_Teleport").invoke([0, -9999999, 0]); } catch(_) {}
                    try { getTransform(target).method("set_position").invoke([0, -9999999, 0]); } catch(_) {}
                    try {
                        const go = target.method("get_gameObject").invoke();
                        if (go && !go.isNull?.()) {
                            try { go.method("SetActive").invoke(false); } catch(_) {}
                            try { Destroy(go); } catch(_) {}
                        }
                    } catch(_) {}
                    sendNotification("Deleted " + targetName, false);
                } catch(e) { console.error("Delete Player Gun:", e); }
              },
              isTogglable: true,
              toolTip: "Aims at a player and voids/deletes them hard (hold grip + trigger)."
            }),
            new ButtonInfo({
              buttonText: "Blind Gun",
              method: () => {
                if (!rightGrab) return;
                const gunData = renderGun();
                if (!rightTrigger || time <= blindGunDelay) return;
                blindGunDelay = time + 0.5;
                try {
                    const target = resolveGunTargetPlayer(gunData, 10.0);
                    if (!target || target.isNull?.()) { sendNotification("No player aimed at", false); return; }
                    if (playerIsLocal(target)) return;
                    const headTf = getPlayerHeadTransform(target);
                    if (!headTf || headTf.isNull?.()) { sendNotification("Can't find head", false); return; }
                    const headPos = readVec3Components(headTf.method("get_position").invoke());
                    spawnItemAtPos("item_goopfish", headPos, identityQuaternion);
                    sendNotification("Blinded: " + getPlayerName(target), false);
                } catch(e) { console.error("Blind Gun:", e); }
              },
              isTogglable: true,
              toolTip: "Aim at a player and pull trigger to spawn a goopfish on their face (hold grip + trigger)."
            }),
            
            new ButtonInfo({
              buttonText: "VFX Spammer Gun",
              method: () => {
                if (!rightGrab) return;
                const gunData = renderGun();
                const ray = gunData.ray;
                if (!rightTrigger) return;
                if (time <= lagGunDelay) return;
                lagGunDelay = time + 0.08;
                try {
                    const hitPoint = (ray && !ray.isNull?.())
                        ? ray.method("get_point").invoke()
                        : getTransform(gunData.gunPointer).method("get_position").invoke();
                    try { playSelectedVfxAt(hitPoint); } catch(_) {}
                } catch(e) { console.error("VFX Spammer Gun:", e); }
              },
              isTogglable: true,
              toolTip: "Spams the selected VFX at your gun pointer."
            }),
      new ButtonInfo({
        buttonText: "Stinky Gun",
        method: () => {
          if (rightGrab) {
            let gunData = null;
            try { gunData = renderGun(); } catch(_) { return; }
            if (!gunData) return;
            if (rightTrigger) {
              try {
              if (time > tagGunDelay) {
                tagGunDelay = time + 0.35;
                const gunTarget = resolveGunTargetPlayer(gunData, 10.0);
                if (gunTarget && !gunTarget.handle.isNull() && !playerIsLocal(gunTarget)) {
                  gunTarget.method("RPC_TagAsStinky").invoke();
                }
              }
              } catch(_) {}
            }
          }
        },
        isTogglable: true,
        toolTip: "Stinkies whoever your hand desires."
      }),

        ],
        [
            new ButtonInfo({
                buttonText: "Exit Over Powered",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns you back to the main category."
            }),

            new ButtonInfo({
                buttonText: "RPG Hands All",
                enableMethod: () => { rpgHandsDelay = 0; sendNotification("RPG Hands All ON", false); },
                disableMethod: () => { sendNotification("RPG Hands All OFF", false); },
                isTogglable: true,
                method: () => {
                    if (time <= rpgHandsDelay) return;
                    rpgHandsDelay = time + 0.035;
                    try {
                        for (const p of getAllNetPlayersList(false)) {
                            try {
                                const rightHeld = getPlayerHeldGrabbable(p, 1);
                                if (!grabbableLooksLikeRevolver(rightHeld)) continue;
                                const tf = getPlayerHandAnchorTransform(p, 1) ?? getPlayerProjectileOriginTransform(p);
                                if (!tf || tf.isNull?.()) continue;
                                const pos = tf.method("get_position").invoke();
                                const forward = getPlayerStraightForward(p);
                                const up = [0, 1, 0];
                                const rot = getLookRotationFromForward(forward);
                                const spawnPos = Vector3.method("op_Addition").invoke(
                                    pos,
                                    Vector3.method("op_Addition").invoke(
                                        Vector3.method("op_Multiply", 2).invoke(forward, 0.72),
                                        [0, -0.025, 0]
                                    )
                                );
                                const rocket = spawnNetworkPrefab("RPGRocket", spawnPos, rot);
                                if (rocket && !rocket.isNull()) {
                                    const vel = Vector3.method("op_Addition").invoke(
                                        Vector3.method("op_Multiply", 2).invoke(forward, 96.0),
                                        Vector3.method("op_Multiply", 2).invoke(up, 1.0)
                                    );
                                    trySetObjectVelocity(rocket, vel);
                                }
                            } catch(_) {}
                        }
                    } catch(e) { console.error("RPG Hands All:", e); }
                },
                toolTip: "Anyone holding a revolver in their right hand gets fast RPG hands from that right-hand anchor."
            }),
            new ButtonInfo({
                buttonText: "Buggy Hands",
                isTogglable: true,
                method: () => {
                    try {
                        const useRight = rightGrab && rightTrigger;
                        const useLeft  = leftGrab  && leftTrigger;
                        if (!useRight && !useLeft) return;
                        if (time <= lagGunDelay) return;
                        lagGunDelay = time + 0.05;
                        const handTransform = useRight ? rightHandTransform : leftHandTransform;
                        const spawned = spawnForwardLaunchedNetworkPrefab("Vehicle_Buggy", handTransform, 155.0, 1.95);
                        if (!spawned || spawned.isNull?.()) {
                            sendNotification("Buggy spawn failed", false);
                        }
                    } catch(e) { console.error("Buggy Hands:", e); }
                },
                toolTip: "Hold grip + trigger to keep launching buggies forward from your hand."
            }),
            new ButtonInfo({
                buttonText: "Item Launcher",
                isTogglable: true,
                method: () => {
                    try {
                        const useRight = rightGrab && rightTrigger;
                        const useLeft = leftGrab && leftTrigger;
                        if (!useRight && !useLeft) return;
                        if (time <= itemLauncherSelfDelay) return;
                        itemLauncherSelfDelay = time + 0.055;
                        const currentItemId = itemIDs[itemIndex];
                        const handTransform = useRight ? rightHandTransform : leftHandTransform;
                        const spawned = spawnForwardLaunchedItem(currentItemId, handTransform, 28.0, 0.92);
                        if (!spawned || spawned.isNull?.()) {
                            sendNotification("Item launch failed", false);
                        }
                    } catch(e) { console.error("Item Launcher:", e); }
                },
                toolTip: "Hold grip + trigger to keep launching the currently selected Item ID from your hand."
            }),
            new ButtonInfo({
                buttonText: "Right Hand Duper",
                enableMethod: () => { heldItemDuplicateDelay = 0; sendNotification("Right Hand Duper ON", false); },
                disableMethod: () => { sendNotification("Right Hand Duper OFF", false); },
                isTogglable: true,
                method: () => {
                    if (time <= heldItemDuplicateDelay) return;
                    heldItemDuplicateDelay = time + 0.075;
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.isNull?.()) return;
                        spawnHeldItemDuplicateForPlayer(player, 14.0);
                    } catch(e) { console.error("Right Hand Duper:", e); }
                },
                toolTip: "Rapidly duplicates the item in your right hand and throws the copies forward."
            }),
            new ButtonInfo({
                buttonText: "Give Fly All",
                enableMethod: () => { giveFlyAllDelay = 0; sendNotification("Give Fly All ON", false); },
                disableMethod: () => { sendNotification("Give Fly All OFF", false); },
                isTogglable: true,
                method: () => {
                    if (time <= giveFlyAllDelay) return;
                    giveFlyAllDelay = time + 0.03;
                    try {
                        for (const p of getAllNetPlayersList(false)) {
                            try {
                                const rightHeld = getPlayerHeldGrabbable(p, 1);
                                if (!grabbableLooksLikeRevolver(rightHeld)) continue;
                                const forward = getPlayerStraightForward(p);
                                const smoothFly = Vector3.method("op_Addition").invoke(
                                    Vector3.method("op_Multiply", 2).invoke(forward, 0.54),
                                    [0, 0.06, 0]
                                );
                                p.method("RPC_AddForce").invoke(smoothFly);
                            } catch(_) {}
                        }
                    } catch(e) { console.error("Give Fly All:", e); }
                },
                toolTip: "Anyone holding a revolver in their right hand gets smooth forward fly like the local movement fly."
            }),

            
            
            new ButtonInfo({
                buttonText: "All Player Gun Buffs",
                enableMethod: () => { InfAmmo = true; noRecoil = true; rapidFireEnabled = true; },
                isTogglable: true,
                method: () => {
                    if (time <= allPlayerGunBuffsDelay) return;
                    allPlayerGunBuffsDelay = time + 0.12;
                    try {
                        for (const p of getAllNetPlayersList(true)) {
                            for (const handIndex of [0, 1]) {
                                try {
                                    const grabbable = getPlayerHeldGrabbable(p, handIndex);
                                    applyGunBuffsToGrabbable(grabbable, false);
                                } catch(_) {}
                            }
                        }
                    } catch(e) { console.error("All Player Gun Buffs:", e); }
                },
                toolTip: "Best-effort local patch that keeps other players' held guns rapid-fire, high-ammo, and no-recoil."
            }),
            new ButtonInfo({
                buttonText: "Item Rain",
                enableMethod: () => { itemRainDelay = 0; sendNotification("Item Rain ON", false); },
                disableMethod: () => { sendNotification("Item Rain OFF", false); },
                isTogglable: true,
                method: () => {
                    if (time <= itemRainDelay) return;
                    itemRainDelay = time + 0.08;
                    try {
                        const headPos = getTransform(headCollider).method("get_position").invoke();
                        const spawnPos = [
                            (headPos.field("x").value as number) + ((Math.random() * 8.0) - 4.0),
                            (headPos.field("y").value as number) + 9.0 + (Math.random() * 4.0),
                            (headPos.field("z").value as number) + ((Math.random() * 8.0) - 4.0)
                        ];
                        spawnItemAtPos(itemIDs[itemIndex], spawnPos, identityQuaternion);
                    } catch(e) { console.error("Item Rain:", e); }
                },
                toolTip: "Rains the currently selected Item ID above your head while enabled."
            }),
            new ButtonInfo({
                buttonText: "Goop Spammer",
                enableMethod: () => { goopSpamDelay = 0; sendNotification("Goop Spammer ON", false); },
                disableMethod: () => { sendNotification("Goop Spammer OFF", false); },
                isTogglable: true,
                method: () => {
                    if (time <= goopSpamDelay) return;
                    goopSpamDelay = time + 0.032;
                    try {
                        const bodyTf = getTransform(bodyCollider);
                        const bodyPos = bodyTf.method("get_position").invoke();
                        const bodyForward = readVec3Components(bodyTf.method("get_forward").invoke());
                        const [fx, fz] = normalizeXZ(bodyForward[0], bodyForward[2]);
                        const spawnPos = [
                            (bodyPos.field("x").value as number) + (fx * 0.16) + ((Math.random() * 0.03) - 0.015),
                            (bodyPos.field("y").value as number) - 0.32,
                            (bodyPos.field("z").value as number) + (fz * 0.16) + ((Math.random() * 0.03) - 0.015)
                        ];
                        const goop = spawnItemAtPos("item_goop", spawnPos, identityQuaternion);
                        if (goop && !goop.isNull()) {
                            spawnedGoopObjects.push({ object: goop, expireAt: time + 2.2 });
                            const vel = [
                                (fx * 8.0) + ((Math.random() * 0.9) - 0.45),
                                -1.0 + (Math.random() * 0.35),
                                (fz * 8.0) + ((Math.random() * 0.9) - 0.45)
                            ];
                            trySetObjectVelocity(goop, vel);
                        }
                    } catch(e) { console.error("Goop Spammer:", e); }
                },
                toolTip: "Shoots a temporary stream of goop forward/down from your lower body."
            }),
            new ButtonInfo({
                buttonText: "Piss Mod",
                enableMethod: () => { goopSpamDelay = 0; sendNotification("Piss Mod ON", false); },
                disableMethod: () => { sendNotification("Piss Mod OFF", false); },
                isTogglable: true,
                method: () => {
                    if (time <= goopSpamDelay) return;
                    goopSpamDelay = time + 0.055;
                    try {
                        const bodyTf = getTransform(bodyCollider);
                        spawnGoopBurstAtTransform(bodyTf, 56, 100, 1, 2.2, 5.2);
                    } catch(e) { console.error("Piss Mod:", e); }
                },
                toolTip: "Shoots a yellow temporary piss stream from your lower body."
            }),
            new ButtonInfo({
                buttonText: "Grab Selling Machine",
                enableMethod: () => { heldSellingMachine = null; },
                disableMethod: () => {
                    try {
                        if (heldSellingMachine && !heldSellingMachine.isNull?.()) {
                            try {
                                const runner = heldSellingMachine.method("get_Runner").invoke();
                                if (runner && !runner.isNull?.()) runner.method("Despawn").invoke(heldSellingMachine);
                            } catch(_) {}
                            try { Destroy(heldSellingMachine.method("get_gameObject").invoke()); } catch(_) {}
                        }
                    } catch(_) {}
                    heldSellingMachine = null;
                },
                isTogglable: true,
                method: () => {
                    try {
                        if (!rightGrab) {
                            if (heldSellingMachine && !heldSellingMachine.isNull?.()) {
                                try { heldSellingMachine.method("get_gameObject").invoke().method("SetActive").invoke(false); } catch(_) {}
                            }
                            return;
                        }
                        if (!heldSellingMachine || heldSellingMachine.isNull?.()) {
                            heldSellingMachine = spawnNetworkPrefab("ItemSellingMachineController", zeroVector, identityQuaternion);
                            if (!heldSellingMachine || heldSellingMachine.isNull?.()) return;
                        }
                        const go = heldSellingMachine.method("get_gameObject").invoke();
                        if (go && !go.isNull?.()) go.method("SetActive").invoke(true);
                        const handPos = rightHandTransform.method("get_position").invoke();
                        const forward = getLaunchForward(rightHandTransform, headCollider ? getTransform(headCollider) : null);
                        const up = getLaunchUp(rightHandTransform, forward);
                        const targetPos = Vector3.method("op_Addition").invoke(
                            handPos,
                            Vector3.method("op_Addition").invoke(
                                Vector3.method("op_Multiply", 2).invoke(forward, 0.9),
                                Vector3.method("op_Multiply", 2).invoke(up, -0.08)
                            )
                        );
                        const tf = getTransform(heldSellingMachine);
                        tf.method("set_position").invoke(targetPos);
                        tf.method("set_rotation").invoke(getLaunchRotation(rightHandTransform, forward, up));
                    } catch(e) { console.error("Grab Selling Machine:", e); }
                },
                toolTip: "While right grip is held, a selling machine stays pushed out in front of your hand."
            }),
            
            new ButtonInfo({
    buttonText: "Floating Selling Machine",
    enableMethod: () => {
        if (floatingMachineEnabled) return;
        floatingMachineEnabled = true;
        
        const spawnPos = rightHandTransform.method("get_position").invoke();
        const spawnPosAbove = Vector3.method("op_Addition").invoke(spawnPos, [0, 2, 0]);
        floatingMachine = spawnNetworkPrefab("ItemSellingMachineController", spawnPosAbove, identityQuaternion);
        
        if (floatingMachine && !floatingMachine.isNull()) {
            sendNotification("Floating Selling Machine Spawned!", false);
            floatingMachineState = "up";
            floatingMachineRotation = 0;
        } else {
            sendNotification("Failed to spawn! Join a lobby first.", false);
            floatingMachineEnabled = false;
        }
    },
    disableMethod: () => {
        floatingMachineEnabled = false;
        if (floatingMachine && !floatingMachine.isNull()) {
            try {
                const runner = floatingMachine.method("get_Runner").invoke();
                if (runner && !runner.isNull()) {
                    runner.method("Despawn").invoke(floatingMachine);
                }
            } catch(e) {}
            floatingMachine = null;
        }
        sendNotification("Floating Selling Machine Removed", false);
    },
    method: () => {
        if (!floatingMachineEnabled || !floatingMachine || floatingMachine.isNull()) return;
        
        try {
            const tf = floatingMachine.method("get_transform").invoke();
            const currentPos = tf.method("get_position").invoke();
            const up = Vector3.field("upVector").value;
            const speed = 1.5;
            const pauseDuration = 0.8;
            const maxHeight = 3.5;
            const minHeight = 0.5;
            
            const currentY = currentPos.field("y").value;
            const startY = currentPos.field("y").value - (floatingMachineState === "up" ? 0 : 0);
            
            if (floatingMachineState === "up") {
                let newY = currentY + (speed * deltaTime);
                if (newY >= maxHeight) {
                    newY = maxHeight;
                    floatingMachineState = "pauseUp";
                    floatingMachinePauseTimer = time + pauseDuration;
                }
                tf.method("set_position").invoke([currentPos.field("x").value, newY, currentPos.field("z").value]);
                
            } else if (floatingMachineState === "pauseUp") {
                if (time >= floatingMachinePauseTimer) {
                    floatingMachineState = "down";
                }
                
            } else if (floatingMachineState === "down") {
                let newY = currentY - (speed * deltaTime);
                if (newY <= minHeight) {
                    newY = minHeight;
                    floatingMachineState = "pauseDown";
                    floatingMachinePauseTimer = time + pauseDuration;
                }
                tf.method("set_position").invoke([currentPos.field("x").value, newY, currentPos.field("z").value]);
                
            } else if (floatingMachineState === "pauseDown") {
                if (time >= floatingMachinePauseTimer) {
                    floatingMachineState = "up";
                }
            }
            
            floatingMachineRotation += 30 * deltaTime;
            if (floatingMachineRotation > 360) floatingMachineRotation -= 360;
            const rotation = Quaternion.method("Euler").invoke(floatingMachineRotation, 0, 0);
            tf.method("set_rotation").invoke(rotation);
            
        } catch(e) {
            console.log("Floating machine error: " + e);
        }
    },
    isTogglable: true,
    toolTip: "Spawns a selling machine that floats up and down slowly while rotating."
}),

new ButtonInfo({
    buttonText: "Floating Christmas Box",
    enableMethod: () => {
        if (floatingChristmasEnabled) return;
        floatingChristmasEnabled = true;
        
        const spawnPos = rightHandTransform.method("get_position").invoke();
        const spawnPosAbove = Vector3.method("op_Addition").invoke(spawnPos, [0, 2, 0]);
        floatingChristmas = spawnNetworkPrefab("ChristmasBox", spawnPosAbove, identityQuaternion);
        
        if (floatingChristmas && !floatingChristmas.isNull()) {
            sendNotification("Floating Christmas Box Spawned!", false);
            floatingChristmasState = "up";
            floatingChristmasRotation = 0;
        } else {
            sendNotification("Failed to spawn! Join a lobby first.", false);
            floatingChristmasEnabled = false;
        }
    },
    disableMethod: () => {
        floatingChristmasEnabled = false;
        if (floatingChristmas && !floatingChristmas.isNull()) {
            try {
                const runner = floatingChristmas.method("get_Runner").invoke();
                if (runner && !runner.isNull()) {
                    runner.method("Despawn").invoke(floatingChristmas);
                }
            } catch(e) {}
            floatingChristmas = null;
        }
        sendNotification("Floating Christmas Box Removed", false);
    },
    method: () => {
        if (!floatingChristmasEnabled || !floatingChristmas || floatingChristmas.isNull()) return;
        
        try {
            const tf = floatingChristmas.method("get_transform").invoke();
            const currentPos = tf.method("get_position").invoke();
            const speed = 1.5;
            const pauseDuration = 0.8;
            const maxHeight = 3.5;
            const minHeight = 0.5;
            
            const currentY = currentPos.field("y").value;
            
            if (floatingChristmasState === "up") {
                let newY = currentY + (speed * deltaTime);
                if (newY >= maxHeight) {
                    newY = maxHeight;
                    floatingChristmasState = "pauseUp";
                    floatingChristmasPauseTimer = time + pauseDuration;
                }
                tf.method("set_position").invoke([currentPos.field("x").value, newY, currentPos.field("z").value]);
                
            } else if (floatingChristmasState === "pauseUp") {
                if (time >= floatingChristmasPauseTimer) {
                    floatingChristmasState = "down";
                }
                
            } else if (floatingChristmasState === "down") {
                let newY = currentY - (speed * deltaTime);
                if (newY <= minHeight) {
                    newY = minHeight;
                    floatingChristmasState = "pauseDown";
                    floatingChristmasPauseTimer = time + pauseDuration;
                }
                tf.method("set_position").invoke([currentPos.field("x").value, newY, currentPos.field("z").value]);
                
            } else if (floatingChristmasState === "pauseDown") {
                if (time >= floatingChristmasPauseTimer) {
                    floatingChristmasState = "up";
                }
            }
            
            floatingChristmasRotation += 45 * deltaTime;
            if (floatingChristmasRotation > 360) floatingChristmasRotation -= 360;
            const rotation = Quaternion.method("Euler").invoke(0, floatingChristmasRotation, 0);
            tf.method("set_rotation").invoke(rotation);
            
        } catch(e) {
            console.log("Floating Christmas error: " + e);
        }
    },
    isTogglable: true,
    toolTip: "Spawns a Christmas Box that floats up and down slowly while rotating."
}),
            
            new ButtonInfo({
                buttonText: "Spaz Explode Machine",
                enableMethod: () => { spazMachineEntries = []; sendNotification("Spaz Explode Machine ON", false); },
                disableMethod: () => {
                    spazMachineEntries = [];
                    sendNotification("Spaz Explode Machine OFF", false);
                },
                isTogglable: true,
                method: () => {
                    try {
                        if (time <= lagGunDelay) return;
                        lagGunDelay = time + 0.09;
                        const machines = Object.method("FindObjectsByType", 1).inflate(ItemSellingMachineController).invoke(0);
                        if (!machines || machines.isNull?.() || machines.length === 0) return;
                        for (let i = 0; i < machines.length; i++) {
                            try {
                                const machine = machines.get(i);
                                if (!machine || machine.isNull?.()) continue;
                                const pos = getTransform(machine).method("get_position").invoke();
                                let exploded = false;
                                for (const methodName of ["RPC_Explode", "Explode", "RPC_Detonate", "Detonate", "RPC_BlowUp", "BlowUp", "RPC_TriggerExplosion", "TriggerExplosion", "RPC_StartExplosion", "StartExplosion", "RPC_ExplodeMachine", "ExplodeMachine", "RPC_BreakMachine", "BreakMachine", "RPC_DestroyMachine", "DestroyMachine"]) {
                                    try {
                                        if (tryCallNames(machine, [methodName], 0)) { exploded = true; break; }
                                    } catch(_) {}
                                    try {
                                        if (tryCallNames(machine, [methodName], 1, true)) { exploded = true; break; }
                                    } catch(_) {}
                                }
                                if (!exploded) {
                                    try { playSelectedVfxAt(pos); } catch(_) {}
                                }
                            } catch(_) {}
                        }
                    } catch(e) { console.error("Spaz Explode Machine:", e); }
                },
                toolTip: "Rapidly spams the selling machine explosion path on existing machines instead of spawning new ones."
            }),
            new ButtonInfo({
                buttonText: "Item Tornado",
                enableMethod: () => { itemTornadoEntries = []; sendNotification("Item Tornado ON", false); },
                disableMethod: () => {
                    for (const entry of itemTornadoEntries) {
                        try {
                            const obj = entry?.object;
                            if (!obj || obj.isNull?.()) continue;
                            let go = obj;
                            try {
                                const maybeGo = obj.method("get_gameObject").invoke();
                                if (maybeGo && !maybeGo.isNull?.()) go = maybeGo;
                            } catch(_) {}
                            Destroy(go);
                        } catch(_) {}
                    }
                    itemTornadoEntries = [];
                    sendNotification("Item Tornado OFF", false);
                },
                isTogglable: true,
                method: () => {
                    try {
                        const center = getTransform(bodyCollider).method("get_position").invoke();
                        while (itemTornadoEntries.length < 34) {
                            const itemId = itemIDs[Math.floor(Math.random() * itemIDs.length)];
                            const spawned = spawnItemAtPos(itemId, [
                                (center.field("x").value as number) + ((Math.random() * 3.2) - 1.6),
                                (center.field("y").value as number) + 0.6 + (Math.random() * 6.5),
                                (center.field("z").value as number) + ((Math.random() * 3.2) - 1.6)
                            ], identityQuaternion);
                            if (!spawned || spawned.isNull?.()) break;
                            itemTornadoEntries.push({
                                object: spawned,
                                angle: Math.random() * Math.PI * 2,
                                radius: 2.2 + (Math.random() * 3.8),
                                height: 0.2 + (Math.random() * 9.6),
                                spin: 1.6 + (Math.random() * 2.6)
                            });
                        }
                        for (let i = itemTornadoEntries.length - 1; i >= 0; i--) {
                            const entry = itemTornadoEntries[i];
                            if (!entry || !entry.object || entry.object.isNull?.()) {
                                itemTornadoEntries.splice(i, 1);
                                continue;
                            }
                            entry.angle += deltaTime * entry.spin * 4.2;
                            const baseY = (center.field("y").value as number);
                            const heightPhase = entry.height + (time * (1.05 + (entry.spin * 0.18))) + (i * 0.38);
                            const ty = baseY + 0.4 + (heightPhase % 10.6);
                            const normalizedHeight = Math.max(0, ty - baseY);
                            const radius = (1.0 + (normalizedHeight * 0.44)) + (Math.sin((time * 2.9) + i) * 0.22);
                            const tx = (center.field("x").value as number) + Math.cos(entry.angle) * radius;
                            const tz = (center.field("z").value as number) + Math.sin(entry.angle) * radius;
                            try { getTransform(entry.object).method("set_position").invoke([tx, ty, tz]); } catch(_) {}
                            trySetObjectVelocity(entry.object, [
                                Math.cos(entry.angle + 0.3) * (4.8 + (radius * 0.7)),
                                0.55 + (Math.sin((time * 1.7) + i) * 0.3),
                                Math.sin(entry.angle + 0.3) * (4.8 + (radius * 0.7))
                            ]);
                            try { entry.object.method("set_colorHue").invoke(Math.floor((Math.sin(time + i) * 110))); } catch(_) {}
                            try { entry.object.method("set_colorSaturation").invoke(Math.floor((Math.cos((time * 1.2) + i) * 90))); } catch(_) {}
                            try { entry.object.method("set_scaleModifier").invoke(Math.floor((Math.sin((time * 0.9) + i) * 45))); } catch(_) {}
                        }
                    } catch(e) { console.error("Item Tornado:", e); }
                },
                toolTip: "Spawns a much larger spinning tornado of colorful items around you."
            }),
            
            new ButtonInfo({
                buttonText: "Cage All Players",
                enableMethod: () => {
                    playerCagePrefabs = [];
                    playerCageEntries = [];
                    sendNotification("Cage All Players ON", false);
                },
                disableMethod: () => {
                    for (const prefab of playerCagePrefabs) {
                        if (!prefab || prefab.isNull?.()) continue;
                        try {
                            const runner = prefab.method("get_Runner").invoke();
                            if (runner && !runner.isNull()) {
                                runner.method("Despawn").invoke(prefab);
                                continue;
                            }
                        } catch(_) {}
                        try {
                            const go = prefab.method("get_gameObject").invoke();
                            if (go && !go.isNull()) Destroy(go);
                        } catch(_) {}
                    }
                    playerCagePrefabs = [];
                    playerCageEntries = [];
                    sendNotification("Cage All Players OFF", false);
                },
                isTogglable: true,
                method: () => {
                    try {
                        const targets = getAllNetPlayersList(false);
                        if (targets.length === 0) return;
                        if (playerCageEntries.length === 0) {
                            const cageLayout = [
                                [-1.8, -0.45, -1.8], [0.0, -0.45, -1.8], [1.8, -0.45, -1.8],
                                [-1.8, -0.45,  1.8], [0.0, -0.45,  1.8], [1.8, -0.45,  1.8],
                                [-1.8,  0.95, -1.8], [0.0,  0.95, -1.8], [1.8,  0.95, -1.8],
                                [-1.8,  0.95,  1.8], [0.0,  0.95,  1.8], [1.8,  0.95,  1.8],
                                [-1.8,  0.25,  0.0], [1.8, 0.25, 0.0], [0.0, 0.25, -1.8], [0.0, 0.25, 1.8]
                            ];
                            for (const p of targets) {
                                if (!p || p.isNull?.()) continue;
                                for (const offset of cageLayout) {
                                    const spawned = spawnNetworkPrefab("ItemSellingMachineController", zeroVector, identityQuaternion);
                                    if (!spawned || spawned.isNull?.()) continue;
                                    playerCagePrefabs.push(spawned);
                                    const go = spawned.method("get_gameObject").invoke();
                                    if (!go || go.isNull()) continue;
                                    const tf = go.method("get_transform").invoke();
                                    playerCageEntries.push({ player: p, transform: tf, offset });
                                }
                            }
                        }
                        for (const cage of playerCageEntries) {
                            try {
                                const p = cage.player;
                                if (!p || p.isNull?.()) continue;
                                const pPos = getTransform(p).method("get_position").invoke();
                                const x = (pPos.field("x").value as number) + cage.offset[0];
                                const y = (pPos.field("y").value as number) + cage.offset[1];
                                const z = (pPos.field("z").value as number) + cage.offset[2];
                                cage.transform.method("set_position").invoke([x, y, z]);
                            } catch(_) {}
                        }
                    } catch(e) { console.error("Cage All Players:", e); }
                },
                toolTip: "Cages every other player with selling machines and despawns them when disabled."
            }),
            new ButtonInfo({
                buttonText: "Delete All Lobby Items",
                method: () => {
                    if (time <= deleteAllLobbyItemsDelay) return;
                    deleteAllLobbyItemsDelay = time + 0.35;
                    try {
                        let count = 0;
                        const localPos = getTransform(bodyCollider).method("get_position").invoke();
                        const seen = new Set<string>();
                        for (const go of collectAllLobbyItemsWithHeld()) {
                            try {
                                if (!go || go.isNull?.()) continue;
                                const rootGo = getRootLikeObject(go);
                                const rootKey = normalizeSceneObjectHandle(rootGo) || normalizeSceneObjectHandle(go);
                                if (rootKey && seen.has(rootKey)) continue;
                                if (rootKey) seen.add(rootKey);
                                requestAuthorityDeep(go);
                                requestAuthorityDeep(rootGo);
                                forceReleaseItemFromAllPlayers(go);
                                forceReleaseItemFromAllPlayers(rootGo);
                                tryReleaseHeldItem(go);
                                tryReleaseHeldItem(rootGo);
                                try { forceMoveLobbyItem(rootGo, localPos); } catch(_) {}
                                try { forceMoveLobbyItem(rootGo, localPos); } catch(_) {}
                                if (destroyNetworkedObjectDeep(rootGo) || destroyNetworkedObjectDeep(go)) count++;
                            } catch(_) {}
                        }
                        sendNotification("Deleted " + count + " lobby items!", false);
                    } catch(e) { sendNotification("Delete All Lobby Items: " + e, false); }
                },
                isTogglable: false,
                toolTip: "One-click deletes or despawns all lobby items after trying to take authority."
            }),
            new ButtonInfo({
                buttonText: "Spawn NetPlayer Trigger",
                enableMethod: () => { netPlayerSpawnDelay = 0; sendNotification("Spawn NetPlayer Trigger ON", false); },
                disableMethod: () => { sendNotification("Spawn NetPlayer Trigger OFF", false); },
                isTogglable: true,
                method: () => {
                    if (!rightTrigger || time <= netPlayerSpawnDelay) return;
                    netPlayerSpawnDelay = time + 0.12;
                    try {
                        spawnForwardLaunchedNetworkPrefab("NetPlayer", rightHandTransform, 18.0, 1.0);
                    } catch(e) { console.error("Spawn NetPlayer Trigger:", e); }
                },
                toolTip: "While enabled, pressing right trigger spawns a NetPlayer prefab forward from your hand."
            }),
            new ButtonInfo({
                buttonText: "Give Masterclient",
                isTogglable: false,
                method: () => {
                    try {
                        let runner = null;
                        try {
                            const pgInst = PrefabGen.field("_instance").value;
                            if (pgInst && !pgInst.isNull()) runner = pgInst.method("get_runner").invoke();
                        } catch(_) {}
                        if (!runner || runner.isNull?.()) {
                            try {
                                runner = getSfxCurrentRunner();
                            } catch(_) {}
                        }
                        if (!runner || runner.isNull?.()) { sendNotification("Runner is null", false); return; }
                        const localRef = runner.method("get_LocalPlayer").invoke();
                        if (!localRef) { sendNotification("LocalPlayer ref null", false); return; }
                        runner.method("SetMasterClient").invoke(localRef);
                        sendNotification("You are now the master client!", false);
                    } catch(e) { sendNotification("Masterclient: " + e, false); console.error("[Masterclient]:", e); }
                },
                toolTip: "Promotes you to master client / host using NetworkRunner.SetMasterClient."
            }),
                  new ButtonInfo({
        buttonText: "Stash Dupe",
        method: () => stashDupeEnabled = true,
        disableMethod: () => stashDupeEnabled = false,
        toolTip: "Lets you eject more times using your stash."
      }),
      new ButtonInfo({
        buttonText: "Change Eject Dupe Amount",
        method: () => {
          ejectDupeIndex++;
          ejectDupeIndex %= ejectDupeValues.length;
          ejectDupeAmount = ejectDupeValues[ejectDupeIndex];
          sendNotification(
            "[MENU] New eject dupe amount: " + ejectDupeAmount,
            false
          );
        },
        isTogglable: false,
        toolTip: "Cycles through preset dupe amounts."
      }),
     new ButtonInfo({
buttonText: "Rocket Launcher",
    method: () => {
        if (!rightGrab) return;
        if (!rightTrigger) return;
        try {
            const forward = getLaunchForward(rightHandTransform);
            const up = getLaunchUp(rightHandTransform, forward);
            const position = Vector3.method("op_Addition").invoke(
                rightHandTransform.method("get_position").invoke(),
                Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, 0.85),
                    Vector3.method("op_Multiply", 2).invoke(up, -0.04)
                )
            );
            const rotation = getLaunchRotation(rightHandTransform, forward, up);
            spawnNetworkPrefab("RPGRocket", position, rotation);
        } catch(e) {
            console.error("RocketLauncher error: " + e);
        }
    },
    isTogglable: true,
    toolTip: "hi"
}),
new ButtonInfo({
    buttonText: "flaregun",
    method: () => {
        if (!rightGrab) return;
        if (!rightTrigger) return;
        try {
            const forward = getLaunchForward(rightHandTransform);
            const up = getLaunchUp(rightHandTransform, forward);
            const position = Vector3.method("op_Addition").invoke(
                rightHandTransform.method("get_position").invoke(),
                Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, 0.85),
                    Vector3.method("op_Multiply", 2).invoke(up, -0.04)
                )
            );
            const rotation = getLaunchRotation(rightHandTransform, forward, up);
            spawnNetworkPrefab("FlareGunProjectile", position, rotation);
        } catch(e) {
            console.error("boomspear error: " + e);
        }
    },
    isTogglable: true,
    toolTip: "tuff"
}),
new ButtonInfo({
    buttonText: "boomspear",
    method: () => {
        if (!rightGrab) return;
        if (!rightTrigger) return;
        try {
            const forward = getLaunchForward(rightHandTransform);
            const up = getLaunchUp(rightHandTransform, forward);
            const position = Vector3.method("op_Addition").invoke(
                rightHandTransform.method("get_position").invoke(),
                Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, 0.85),
                    Vector3.method("op_Multiply", 2).invoke(up, -0.04)
                )
            );
            const rotation = getLaunchRotation(rightHandTransform, forward, up);
            spawnNetworkPrefab("RPGRocketSpear", position, rotation);
        } catch(e) {
            console.error("boomspear error: " + e);
        }
    },
    isTogglable: true,
    toolTip: "tuff"
}),
new ButtonInfo({
    buttonText: "Robot Dog RPG",
    method: () => {
        if (!rightGrab) return;
        if (!rightTrigger) return;
        try {
            const forward = getLaunchForward(rightHandTransform);
            const up = getLaunchUp(rightHandTransform, forward);
            const position = Vector3.method("op_Addition").invoke(
                rightHandTransform.method("get_position").invoke(),
                Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, 0.85),
                    Vector3.method("op_Multiply", 2).invoke(up, -0.04)
                )
            );
            const rotation = getLaunchRotation(rightHandTransform, forward, up);
            spawnNetworkPrefab("RobotDogRPG", position, rotation);
        } catch(e) {
            console.error("RobotDogRPG error: " + e);
        }
    },
    isTogglable: true,
    toolTip: "tuff"
}),
     
new ButtonInfo({
    buttonText: "egg",
    method: () => {
        if (!rightGrab) return;
        if (!rightTrigger) return;
        try {
            const forward = getLaunchForward(rightHandTransform);
            const up = getLaunchUp(rightHandTransform, forward);
            const position = Vector3.method("op_Addition").invoke(
                rightHandTransform.method("get_position").invoke(),
                Vector3.method("op_Addition").invoke(
                    Vector3.method("op_Multiply", 2).invoke(forward, 0.85),
                    Vector3.method("op_Multiply", 2).invoke(up, -0.04)
                )
            );
            const rotation = getLaunchRotation(rightHandTransform, forward, up);
            spawnNetworkPrefab("RPGRocketEgg", position, rotation);
        } catch(e) {
            console.error("boomspear error: " + e);
        }
    },
    isTogglable: true,
    toolTip: "tuff"
}),
      

new ButtonInfo({
    buttonText: "Infinite Ammo",
    enableMethod: () => { InfAmmo = true; },
    disableMethod: () => { InfAmmo = false; },
    isTogglable: true,
    toolTip: "Infinite ammo"
}),
new ButtonInfo({
    buttonText: "No Recoil",
    enableMethod: () => { noRecoil = true; },
    disableMethod: () => { noRecoil = false; },
    isTogglable: true,
    toolTip: "Removes recoil force and spread on all guns (Revolver, Shotgun, Arena guns)."
}),
new ButtonInfo({
    buttonText: "No Shotgun Cooldown",
    enableMethod: () => { noShotgunCooldown = true; },
    disableMethod: () => { noShotgunCooldown = false; },
    isTogglable: true,
    toolTip: "Removes the reload/cooldown delay between shotgun shots."
}),
new ButtonInfo({
        buttonText: "Rapid Fire",
        enableMethod: () => { rapidFireEnabled = true; },
        disableMethod: () => { rapidFireEnabled = false; },
        method: () => {
          try {
            const pulseMethod = (held: any, names: string[], parameterCount: number, ...args: any[]) => {
              for (const name of names) {
                try {
                  const method = tryMethodName(held.class, [name], parameterCount);
                  if (method) invokeInstance(method, held, ...args);
                } catch(_) {}
              }
            };
            const pulseRevolverSecondary = (held: any) => {
              try {
                pulseMethod(held, ["HandleSecondaryUse", "HandleGripUse", "CockHammer", "PullBackHammer"], 0);
                pulseMethod(held, ["HandleSecondaryButton", "HandleSecondaryUse", "HandleGripUse", "CockHammer", "PullBackHammer"], 1, true);
                pulseMethod(held, ["HandleSecondaryButton", "HandleSecondaryUse", "HandleGripUse"], 1, false);
                pulseMethod(held, ["OnSecondaryButtonDown", "OnSecondaryUseDown"], 0);
                pulseMethod(held, ["OnSecondaryButtonUp", "OnSecondaryUseUp"], 0);
              } catch(_) {}
            };
            const fireHeldRapid = (held: any, pressed: boolean) => {
              if (!held || !pressed) return;
              if (time <= rapidFirePulseDelay) return;
              rapidFirePulseDelay = time + 0.018;
              try {
                const heldClassName = String(held.class?.type?.name ?? "").toLowerCase();
                try { applyGunBuffsToGrabbable(held, false); } catch(_) {}
                if (heldClassName.indexOf("revolver") >= 0) {
                  try { held.field("_isHammerCocked").value = true; } catch(_) {}
                  try { held.field("isHammerCocked").value = true; } catch(_) {}
                  try { held.field("_ammoLoaded").value = 255; } catch(_) {}
                  try { held.field("ammoLoaded").value = 255; } catch(_) {}
                  try { held.field("_reloadTimer").value = 0.0; } catch(_) {}
                  try { held.field("_triggerUseCooldown").value = 0.0; } catch(_) {}
                  try { held.field("_secondaryUseCooldown").value = 0.0; } catch(_) {}
                  try { held.field("_hammerPullbackAmount").value = 1.0; } catch(_) {}
                  try { held.method("set_isHammerCocked").invoke(true); } catch(_) {}
                  pulseRevolverSecondary(held);
                }
                try { held.method("HandleTriggerUse").invoke(); } catch(_) {}
                if (heldClassName.indexOf("revolver") >= 0) {
                  try { held.field("_triggerUseCooldown").value = 0.0; } catch(_) {}
                  try { held.field("_secondaryUseCooldown").value = 0.0; } catch(_) {}
                  try { held.method("set_isHammerCocked").invoke(true); } catch(_) {}
                  for (let i = 0; i < 3; i++) {
                    tryCallNames(held, ["OnBButtonDown", "HandleBButtonDown", "PressBButton"], 0);
                    tryCallNames(held, ["HandleBButton", "HandleSecondaryButton", "HandleSecondaryUse"], 1, true);
                    tryCallNames(held, ["HandleBButton", "HandleSecondaryButton", "HandleSecondaryUse"], 1, false);
                  }
                  pulseRevolverSecondary(held);
                }
              } catch(_) {}
            };
            const player = NetPlayer.method("get_localPlayer").invoke();
            if (!player) return;
            const interactor = player.method("GetHandInteractor", 1).invoke(1);
            let grabbable = null;
            if (interactor) {
              try {
                const itemAnchor = interactor.field("_itemAnchor").value;
                if (itemAnchor) grabbable = itemAnchor.method("get_grabbableObject").invoke();
              } catch(_) {}
            }
            const interactor2 = player.method("GetHandInteractor", 1).invoke(0);
            let grabbable2 = null;
            if (interactor2) {
              try {
                const itemAnchor2 = interactor2.field("_itemAnchor").value;
                if (itemAnchor2) grabbable2 = itemAnchor2.method("get_grabbableObject").invoke();
              } catch(_) {}
            }
            fireHeldRapid(grabbable, rightTrigger);
            fireHeldRapid(grabbable2, leftTrigger);
          } catch (e) {
            console.error(e);
          }
        },
        isTogglable: true,
        toolTip: "Rapid fires trigger items and also force-cocks revolvers when possible."
      }),
            new ButtonInfo({
                buttonText: "Nut Pickup Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.15;
                        try {
                            const hitPoint = ray.method("get_point").invoke();
                            
                            PickupManager.method("SpawnPickup", 4).invoke(2, hitPoint, 5, true);
                        } catch(e) { sendNotification("Nut Pickup Gun: " + e, false); }
                    }
                },
                toolTip: "Spawns nut pickups where you aim (hold grip + trigger)."
            }),
            new ButtonInfo({
                buttonText: "Ammo Pickup Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.15;
                        try {
                            const hitPoint = ray.method("get_point").invoke();
                            
                            PickupManager.method("SpawnPickup", 4).invoke(1, hitPoint, 5, true);
                        } catch(e) { sendNotification("Ammo Pickup Gun: " + e, false); }
                    }
                },
                toolTip: "Spawns ammo pickups where you aim (hold grip + trigger)."
            }),
            new ButtonInfo({
                buttonText: "Dump Net Objects",
                method: () => {
                    try {
                        const runner = PrefabGen.field("_instance").value.method("get_runner").invoke();
                        if (!runner || runner.isNull()) {
                            sendNotification("No runner — join a room first", false, 4);
                            return;
                        }
                        const sources = runner.field("_config").value
                            .field("PrefabTable").value
                            .field("_sources").value;
                        const count = sources.method("get_Count").invoke() as number;
                        console.log("[G2] ═══════════════════════════════════════");
                        console.log("[G2] NetworkObject prefab table — " + count + " entries:");
                        const names: string[] = [];
                        for (let i = 0; i < count; i++) {
                            try {
                                const source = sources.method("get_Item").invoke(i);
                                const desc = source.method("get_Description").invoke().toString();
                                console.log("[G2]  [" + i + "] " + desc);
                                names.push(desc);
                            } catch(_) {
                                console.log("[G2]  [" + i + "] <error reading entry>");
                            }
                        }
                        console.log("[G2] ═══════════════════════════════════════");
                        sendNotification("Dumped " + count + " net prefabs — see Frida log", false, 5);
                    } catch(e) {
                        sendNotification("Dump Net Objects: " + e, false, 5);
                        console.error("[G2] Error:", e);
                    }
                },
                isTogglable: false,
                toolTip: "Logs every spawnable NetworkObject prefab name from the Fusion PrefabTable to the Frida console."
            }),
                new ButtonInfo({
                buttonText: "Unlock All",
                isTogglable: false,
                method: () => {
                    try {
                        const AppClass = AssemblyCSharp.class("AnimalCompany.App");
                        const appState = AppClass.method("get_state").invoke();
                        if (!appState || appState.isNull()) { sendNotification("No app state", false); return; }

                        
                        try {
                            const GISCls = AssemblyCSharp.class("AnimalCompany.GameplayItemState");
                            GISCls.method("get_isHidden").implementation = function() { return false; };
                        } catch(_) {}

                        
                        let unlockedSet: any = null;
                        try {
                            const userState = appState.method("get_user").invoke();
                            if (userState && !userState.isNull()) {
                                const inv = userState.method("get_inventory").invoke();
                                if (inv && !inv.isNull()) {
                                    unlockedSet = inv.method("get_unlockedGameplayItems").invoke();
                                    
                                    try {
                                        const devOverride = inv.method("get_devOwnAllAvatarItemsOverride").invoke();
                                        if (devOverride && !devOverride.isNull()) devOverride.method("set_value").invoke(true);
                                    } catch(_) {}
                                }
                            }
                        } catch(e) { console.error("[UnlockAll] inventory:", e); }

                        
                        let unlockedItems = 0;
                        try {
                            const gameplayItems = appState.method("get_gameplayItems").invoke();
                            if (gameplayItems && !gameplayItems.isNull()) {
                                const allDict = gameplayItems.method("get_all").invoke();
                                if (allDict && !allDict.isNull()) {
                                    const values = allDict.method("get_Values").invoke();
                                    if (values && !values.isNull()) {
                                        const enumerator = values.method("GetEnumerator").invoke();
                                        while (enumerator.method("MoveNext").invoke()) {
                                            try {
                                                const item = enumerator.method("get_Current").invoke();
                                                if (!item || item.isNull()) continue;
                                                
                                                try {
                                                    const isUnlocked = item.method("get_isUnlocked").invoke();
                                                    if (isUnlocked && !isUnlocked.isNull()) isUnlocked.method("set_value").invoke(true);
                                                } catch(_) {}
                                                
                                                try {
                                                    const depsSatisfied = item.method("get_unlockDependenciesSatisfied").invoke();
                                                    if (depsSatisfied && !depsSatisfied.isNull()) depsSatisfied.method("set_value").invoke(true);
                                                } catch(_) {}
                                                
                                                try {
                                                    const unlockable = item.method("get_unlockable").invoke();
                                                    if (unlockable && !unlockable.isNull()) unlockable.method("set_value").invoke(true);
                                                } catch(_) {}
                                                
                                                
                                                try {
                                                    const itemID = item.method("get_id").invoke();
                                                    if (itemID && unlockedSet && !unlockedSet.isNull()) {
                                                        unlockedSet.method("Add").invoke(itemID);
                                                    }
                                                } catch(_) {}
                                                unlockedItems++;
                                            } catch(_) {}
                                        }
                                    }
                                }
                            }
                        } catch(e) { console.error("[UnlockAll] gameplayItems:", e); }

                        
                        let unlockedAvatarItems = 0;
                        try {
                            const avatarItems = appState.method("get_avatarItems").invoke();
                            if (avatarItems && !avatarItems.isNull()) {
                                const allDict = avatarItems.method("get_all").invoke();
                                if (allDict && !allDict.isNull()) {
                                    const values = allDict.method("get_Values").invoke();
                                    if (values && !values.isNull()) {
                                        const enumerator = values.method("GetEnumerator").invoke();
                                        while (enumerator.method("MoveNext").invoke()) {
                                            try {
                                                const item = enumerator.method("get_Current").invoke();
                                                if (!item || item.isNull()) continue;
                                                try {
                                                    const isOwned = item.method("get_isOwned").invoke();
                                                    if (isOwned && !isOwned.isNull()) isOwned.method("set_value").invoke(true);
                                                } catch(_) {}
                                                try {
                                                    const canPurchase = item.method("get_canPurchaseDirectly").invoke();
                                                    if (canPurchase && !canPurchase.isNull()) canPurchase.method("set_value").invoke(true);
                                                } catch(_) {}
                                                
                                                try {
                                                    const isDevItem = item.method("get_isDevItem")?.invoke();
                                                    if (isDevItem && !isDevItem.isNull()) isDevItem.method("set_value").invoke(true);
                                                } catch(_) {}
                                                unlockedAvatarItems++;
                                            } catch(_) {}
                                        }
                                    }
                                }
                            }
                        } catch(e) { console.error("[UnlockAll] avatarItems:", e); }

                        sendNotification("Unlocked " + unlockedItems + " items + " + unlockedAvatarItems + " cosmetics (dev included)!", false);
                    } catch(e) { sendNotification("Unlock All: " + e, false); console.error("[UnlockAll]", e); }
                },
                toolTip: "Unlocks all gameplay + cosmetic items including hidden/dev items. Hooks get_isHidden=false so dev items show in UI."
            }),
            new ButtonInfo({
                buttonText: "Dev Mode",
                isTogglable: false,
                method: () => {
                    try {
                        const AppClass = AssemblyCSharp.class("AnimalCompany.App");
                        const appState = AppClass.method("get_state").invoke();
                        if (!appState || appState.isNull()) { sendNotification("No app state", false); return; }

                        
                        
                        try {
                            const userState = appState.method("get_user").invoke();
                            if (userState && !userState.isNull()) {
                                const isDev = userState.method("get_isDeveloper").invoke();
                                if (isDev && !isDev.isNull()) {
                                    isDev.method("set_value").invoke(true);
                                }
                            }
                        } catch(e) { console.error("[GiveDev] isDeveloper:", e); }

                        
                        
                        try {
                            const mapMachine = appState.method("get_mapMachine").invoke();
                            if (mapMachine && !mapMachine.isNull()) {
                                const useDevMode = mapMachine.method("get_useDevMode").invoke();
                                if (useDevMode && !useDevMode.isNull()) {
                                    useDevMode.method("set_value").invoke(true);
                                }
                            }
                        } catch(e) { console.error("[GiveDev] useDevMode:", e); }

                        sendNotification("Dev mode enabled!", false);
                    } catch(e) { sendNotification("Give Dev: " + e, false); console.error("[GiveDev]", e); }
                },
                toolTip: "One-shot developer mode enable using the old app-state write path."
            }),
            new ButtonInfo({
                buttonText: "Force Dev Mode",
                enableMethod: () => {
                    forceDevModeEnabled = true;
                    tryForceDeveloperMode();
                    sendNotification("Force Dev Mode ON", false);
                },
                disableMethod: () => {
                    forceDevModeEnabled = false;
                    sendNotification("Force Dev Mode OFF", false);
                },
                isTogglable: true,
                toolTip: "Continuously forces developer mode and dev menu state every frame."
            }),

            new ButtonInfo({
                buttonText: "Inf Damage",
                enableMethod: () => { infDamage = true; },
                disableMethod: () => { infDamage = false; },
                isTogglable: true,
                toolTip: "Makes all weapons deal 999999 damage per shot/hit."
            }),
        ],
        [ 
            new ButtonInfo({
                buttonText: "Exit Whitelist mods",
                method: () => { currentCategory = 5; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to menu."
            }),
            new ButtonInfo({
                buttonText: "Toggle Whitelist",
                method: () => {
                    whitelistEnabled = !whitelistEnabled;
                    sendNotification("Whitelist: " + (whitelistEnabled ? "ON" : "OFF"), false);
                    reloadMenu();
                },
                isTogglable: false,
                toolTip: "Enables or disables the whitelist system."
            }),
            new ButtonInfo({
                buttonText: "WL Gun Add",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, false, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            const id = getPlayerName(target.player);
                            if (!whitelistHasPlayer(target.player)) {
                                whitelistAddPlayer(target.player);
                                sendNotification("Added to whitelist: " + id, false);
                            } else {
                                sendNotification("Already whitelisted: " + id, false);
                            }
                        } catch(e) { console.error("WL Gun Add:", e); }
                    }
                },
                toolTip: "Point at a player and pull trigger to add to whitelist (hold grip)."
            }),
            new ButtonInfo({
                buttonText: "WL Gun Remove",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, false, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            const id = getPlayerName(target.player);
                            if (whitelistHasPlayer(target.player)) {
                                whitelistRemovePlayer(target.player);
                                sendNotification("Removed from whitelist: " + id, false);
                            } else {
                                sendNotification("Not in whitelist: " + id, false);
                            }
                        } catch(e) { console.error("WL Gun Remove:", e); }
                    }
                },
                toolTip: "Point at a player and pull trigger to remove from whitelist (hold grip)."
            }),
            new ButtonInfo({
                buttonText: "Clear Whitelist",
                method: () => {
                    whitelist = [];
                    sendNotification("Whitelist cleared!", false);
                },
                isTogglable: false,
                toolTip: "Removes all players from the whitelist."
            }),
            new ButtonInfo({
                buttonText: "List Whitelist",
                method: () => {
                    if (whitelist.length === 0) { sendNotification("Whitelist is empty", false, 4); return; }
                    sendNotification("WL: " + whitelist.join(", "), false, 8);
                },
                isTogglable: false,
                toolTip: "Shows all whitelisted players."
            }),
            new ButtonInfo({
                buttonText: "WL Give Fly Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.03;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            const originTf = getPlayerHandAnchorTransform(target.player, 1) ?? getPlayerProjectileOriginTransform(target.player);
                            const forward = originTf && !originTf.isNull?.()
                                ? getLaunchForward(originTf, getTransform(target.player))
                                : getLaunchForward(getTransform(target.player), getTransform(headCollider));
                            target.player.method("RPC_AddForce").invoke(
                                Vector3.method("op_Addition").invoke(
                                    Vector3.method("op_Multiply", 2).invoke(forward, 0.34),
                                    [0, 0.03, 0]
                                )
                            );
                            sendNotification("Gave fly boost to " + target.id, false);
                        } catch(e) { console.error("Give Fly Gun:", e); }
                    }
                },
                toolTip: "Point at a player and give them a smooth forward fly force (hold grip)."
            }),

            new ButtonInfo({
                buttonText: "Give Items Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            const targetPos = getTransform(target.player).method("get_position").invoke();
                            PrefabGen.method("SpawnItem", 4).invoke(
                                Il2Cpp.string("item_prefab/" + itemIDs[itemIndex]),
                                targetPos, identityQuaternion,
                                
                                NULL
                            );
                            sendNotification("Gave " + itemIDs[itemIndex] + " to " + target.id, false);
                        } catch(e) { console.error("Give Items Gun:", e); }
                    }
                },
                toolTip: "Point at a player to spawn the selected item near them."
            }),

            new ButtonInfo({
                buttonText: "WL TP To Me Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            const me = NetPlayer.method("get_localPlayer").invoke();
                            if (!me || me.handle.isNull()) return;
                            const myPos = getTransform(me).method("get_position").invoke();
                            target.player.method("RPC_Teleport").invoke(myPos);
                            sendNotification("TP'd " + target.id + " to you!", false);
                        } catch(e) { console.error("WL TP To Me:", e); }
                    }
                },
                toolTip: "Teleports a whitelisted player to your position (hold grip + trigger)."
            }),

            new ButtonInfo({
                buttonText: "WL Selling Orbit Gun",
                disableMethod: () => {
                    for (const prefab of wlSellingOrbitPrefabs) {
                        if (!prefab || prefab.isNull?.()) continue;
                        try {
                            const runner = prefab.method("get_Runner").invoke();
                            if (runner && !runner.isNull()) {
                                runner.method("Despawn").invoke(prefab);
                                continue;
                            }
                        } catch(_) {}
                        try {
                            const go = prefab.method("get_gameObject").invoke();
                            if (go && !go.isNull()) Destroy(go);
                        } catch(_) {}
                    }
                    wlSellingOrbitPrefabs = [];
                    wlSellingOrbitEntries = [];
                },
                isTogglable: true,
                method: () => {
                    try {
                        if (rightGrab) {
                            const gunData = renderGun();
                            if (rightTrigger && time > lagGunDelay) {
                                lagGunDelay = time + 0.18;
                                const target = getWhitelistGunTarget(gunData, true, 10.0);
                                if (target && target.player) {
                                    const already = wlSellingOrbitEntries.some(e => e.player && !e.player.isNull?.() && e.player.handle.equals(target.player.handle));
                                    if (!already) {
                                        for (let i = 0; i < 8; i++) {
                                            const spawned = spawnNetworkPrefab("ItemSellingMachineController", zeroVector, identityQuaternion);
                                            if (!spawned || spawned.isNull?.()) continue;
                                            wlSellingOrbitPrefabs.push(spawned);
                                            const go = spawned.method("get_gameObject").invoke();
                                            if (!go || go.isNull()) continue;
                                            const tf = go.method("get_transform").invoke();
                                            wlSellingOrbitEntries.push({
                                                player: target.player,
                                                transform: tf,
                                                angle: (Math.PI * 2 / 8) * i
                                            });
                                        }
                                        sendNotification("Selling orbit added to " + target.id, false);
                                    }
                                }
                            }
                        }
                        for (const orb of wlSellingOrbitEntries) {
                            try {
                                const p = orb.player;
                                if (!p || p.isNull?.()) continue;
                                const pos = getTransform(p).method("get_position").invoke();
                                orb.angle += deltaTime * 1.8;
                                const x = (pos.field("x").value as number) + Math.cos(orb.angle) * 2.6;
                                const y = (pos.field("y").value as number) + 0.35 + Math.sin((orb.angle * 2.0) + time) * 0.18;
                                const z = (pos.field("z").value as number) + Math.sin(orb.angle) * 2.6;
                                orb.transform.method("set_position").invoke([x, y, z]);
                            } catch(_) {}
                        }
                    } catch(e) { console.error("WL Selling Orbit Gun:", e); }
                },
                toolTip: "Touches a WL player with the gun and makes selling machines orbit them."
            }),
            new ButtonInfo({
                buttonText: "WL Orbit All Target Gun",
                enableMethod: () => { wlOrbitAllTarget = null; wlOrbitAllPhase = 0; },
                disableMethod: () => { wlOrbitAllTarget = null; },
                isTogglable: true,
                method: () => {
                    try {
                        if (rightGrab) {
                            const gunData = renderGun();
                            if (rightTrigger && time > wlTargetActionDelay) {
                                wlTargetActionDelay = time + 0.25;
                                const target = getWhitelistGunTarget(gunData, true, 10.0);
                                if (target?.player) {
                                    wlOrbitAllTarget = target.player;
                                    sendNotification("Orbit target: " + target.id, false);
                                }
                            }
                        }
                        if (!wlOrbitAllTarget || wlOrbitAllTarget.isNull?.()) return;
                        const center = getTransform(wlOrbitAllTarget).method("get_position").invoke();
                        const others = getAllNetPlayersList(false);
                        wlOrbitAllPhase += deltaTime * 3.5;
                        let idx = 0;
                        for (const p of others) {
                            try {
                                if (!p || p.isNull?.()) continue;
                                if (normalizeSceneObjectHandle(p) === normalizeSceneObjectHandle(wlOrbitAllTarget)) continue;
                                const angle = wlOrbitAllPhase + ((Math.PI * 2 * idx) / Math.max(1, others.length));
                                p.method("RPC_Teleport").invoke([
                                    (center.field("x").value as number) + (Math.cos(angle) * 2.9),
                                    (center.field("y").value as number) + 1.15 + (Math.sin((time * 2.0) + idx) * 0.45),
                                    (center.field("z").value as number) + (Math.sin(angle) * 2.9)
                                ]);
                                idx++;
                            } catch(_) {}
                        }
                    } catch(e) { console.error("WL Orbit All Target Gun:", e); }
                },
                toolTip: "Aim a WL player once, then all players orbit them until toggled off."
            }),
            new ButtonInfo({
                buttonText: "WL Piss Gun",
                enableMethod: () => { wlPissTarget = null; },
                disableMethod: () => { wlPissTarget = null; },
                isTogglable: true,
                method: () => {
                    try {
                        if (rightGrab) {
                            const gunData = renderGun();
                            if (rightTrigger && time > wlTargetActionDelay) {
                                wlTargetActionDelay = time + 0.25;
                                const target = getWhitelistGunTarget(gunData, true, 10.0);
                                if (target?.player) {
                                    wlPissTarget = target.player;
                                    sendNotification("Piss target: " + target.id, false);
                                }
                            }
                        }
                        if (!wlPissTarget || wlPissTarget.isNull?.() || time <= goopSpamDelay) return;
                        goopSpamDelay = time + 0.055;
                        spawnGoopBurstAtTransform(getTransform(wlPissTarget), 56, 100, 1, 2.2, 5.2);
                    } catch(e) { console.error("WL Piss Gun:", e); }
                },
                toolTip: "Aim a WL player once and continuously gives them the piss stream."
            }),
            
            new ButtonInfo({
                buttonText: "WL Right Hand Duper Gun",
                enableMethod: () => { wlRightHandDuperTarget = null; },
                disableMethod: () => { wlRightHandDuperTarget = null; },
                isTogglable: true,
                method: () => {
                    try {
                        if (rightGrab) {
                            const gunData = renderGun();
                            if (rightTrigger && time > wlTargetActionDelay) {
                                wlTargetActionDelay = time + 0.25;
                                const target = getWhitelistGunTarget(gunData, true, 10.0);
                                if (target?.player) {
                                    wlRightHandDuperTarget = target.player;
                                    sendNotification("Right-hand duper: " + target.id, false);
                                }
                            }
                        }
                        if (!wlRightHandDuperTarget || wlRightHandDuperTarget.isNull?.() || time <= heldItemDuplicateDelay) return;
                        heldItemDuplicateDelay = time + 0.08;
                        spawnHeldItemDuplicateForPlayer(wlRightHandDuperTarget, 12.5);
                    } catch(e) { console.error("WL Right Hand Duper Gun:", e); }
                },
                toolTip: "Aim a WL player once and makes them spam-dupe whatever is in their right hand."
            }),
            new ButtonInfo({
                buttonText: "WL Item Duper Hand Gun",
                enableMethod: () => { wlItemDuperHandTarget = null; wlItemDuperHandDelay = 0; },
                disableMethod: () => { wlItemDuperHandTarget = null; wlItemDuperHandDelay = 0; },
                isTogglable: true,
                method: () => {
                    try {
                        if (rightGrab) {
                            const gunData = renderGun();
                            if (rightTrigger && time > wlTargetActionDelay) {
                                wlTargetActionDelay = time + 0.25;
                                const target = getWhitelistGunTarget(gunData, true, 10.0);
                                if (target?.player) {
                                    wlItemDuperHandTarget = target.player;
                                    wlItemDuperHandDelay = 0;
                                    sendNotification("Item duper hand: " + target.id, false);
                                }
                            }
                        }
                        if (!wlItemDuperHandTarget || wlItemDuperHandTarget.isNull?.() || time <= wlItemDuperHandDelay) return;
                        wlItemDuperHandDelay = time + 0.075;
                        spawnHeldItemDuplicateForPlayer(wlItemDuperHandTarget, 12.5);
                    } catch(e) { console.error("WL Item Duper Hand Gun:", e); }
                },
                toolTip: "Aim a WL player once and gives them the right-hand item duper hand effect."
            }),
            


            new ButtonInfo({
                buttonText: "WL TP All WL 2 Me",
                method: () => {
                    try {
                        const me = NetPlayer.method("get_localPlayer").invoke();
                        if (!me || me.handle.isNull()) return;
                        const myPos = getTransform(me).method("get_position").invoke();
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                            while (en.method("MoveNext").invoke()) {
                                const p = en.method("get_Current").invoke();
                                if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                                if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                                try { p.method("RPC_Teleport").invoke(myPos); count++; } catch(_) {}
                            }
                        sendNotification("TP'd " + count + " WL players to you!", false);
                    } catch(e) { sendNotification("WL TP All 2 Me: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Teleports all whitelisted players to your position."
            }),
        ],

        [ 
            new ButtonInfo({
                buttonText: "Exit Target Player / Touch mods",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to main menu."
            }),

                        new ButtonInfo({
                buttonText: "TP Target to Me",
                isTogglable: false,
                method: () => {
                    try {
                        const me = NetPlayer.method("get_localPlayer").invoke();
                        if (!me || me.handle.isNull()) return;
                        const myPos = getTransform(me).method("get_position").invoke();
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        const others: any[] = [];
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            others.push(p);
                        }
                        if (others.length === 0) { sendNotification("No other players!", false); return; }
                        targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
                        const target = others[targetPlayerIndex];
                        target.method("RPC_Teleport").invoke(myPos);
                        sendNotification("Teleported " + getPlayerName(target) + " to you!", false);
                    } catch(e) { smartError("[TP Target to Me]", e); }
                },
                toolTip: "Teleports the selected target player to your position. Set target in Settings > Change Target Player."
            }),



            new ButtonInfo({
                buttonText: "TP Me to Target",
                isTogglable: false,
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        const others: any[] = [];
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            others.push(p);
                        }
                        if (others.length === 0) { sendNotification("No other players!", false); return; }
                        targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
                        const target = others[targetPlayerIndex];
                        const targetPos = getTransform(target).method("get_position").invoke();
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        selfRPC(() => player.method("RPC_Teleport").invoke(targetPos));
                        sendNotification("Teleported to " + getPlayerName(target) + "!", false);
                    } catch(e) { smartError("[TP Me to Target]", e); }
                },
                toolTip: "Teleports you to the selected target player. Set target in Settings > Change Target Player."
            }),
            new ButtonInfo({
                buttonText: "Telekinesis target",
                isTogglable: true,
                enableMethod: () => { _telekinesisActive = true; sendNotification("Telekinesis ON — target set in Settings", false, 3); },
                disableMethod: () => { _telekinesisActive = false; sendNotification("Telekinesis OFF", false, 2); },
                method: () => {
                    if (!_telekinesisActive) return;
                    if (time < _telekinesisDelay) return;
                    _telekinesisDelay = time + 0.12;
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        const others: any[] = [];
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            others.push(p);
                        }
                        if (others.length === 0) return;
                        targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
                        const target = others[targetPlayerIndex];
                        target.method("RPC_AddForce").invoke([0, 350, 0]);
                    } catch(e) { smartError("[Telekinesis]", e); }
                },
                toolTip: "Continuously lifts the selected target player into the air every 0.12s. Set target in Settings > Change Target Player."
            }),
            
            new ButtonInfo({
                buttonText: "Hand Puppet Target",
                isTogglable: true,
                enableMethod: () => {
                    _puppetActive = true;
                    try {
                        // Snap target to me on activation
                        const me = NetPlayer.method("get_localPlayer").invoke();
                        const myPos = getTransform(me).method("get_position").invoke();
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        const others: any[] = [];
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            others.push(p);
                        }
                        if (others.length === 0) { sendNotification("No players found!", false, 2); return; }
                        targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
                        const target = others[targetPlayerIndex];
                        target.method("RPC_Teleport").invoke(myPos);
                        sendNotification("Hand Puppet ON — point your hand to control!", false, 3);
                    } catch(e) { smartError("[Hand Puppet enable]", e); }
                },
                disableMethod: () => { _puppetActive = false; sendNotification("Hand Puppet OFF", false, 2); },
                method: () => {
                    if (!_puppetActive) return;
                    if (time < _puppetDelay) return;
                    _puppetDelay = time + 0.05;
                    try {
                        const me = NetPlayer.method("get_localPlayer").invoke();
                        if (!me || me.handle.isNull()) return;

                        // Get right hand position and forward direction
                        const handPos = rightHandTransform.method("get_position").invoke();
                        const handFwd = rightHandTransform.method("get_forward").invoke();

                        const hx = handPos.field("x").value as number;
                        const hy = handPos.field("y").value as number;
                        const hz = handPos.field("z").value as number;
                        const fx = handFwd.field("x").value as number;
                        const fy = handFwd.field("y").value as number;
                        const fz = handFwd.field("z").value as number;

                        // Target position = hand + forward * 4 metres
                        const dist = 4.0;
                        const tx = hx + fx * dist;
                        const ty = hy + fy * dist;
                        const tz = hz + fz * dist;

                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        const others: any[] = [];
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            others.push(p);
                        }
                        if (others.length === 0) return;
                        targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
                        const target = others[targetPlayerIndex];
                        target.method("RPC_Teleport").invoke([tx, ty, tz]);
                    } catch(e) { smartError("[Hand Puppet]", e); }
                },
                toolTip: "Teleports selected player to you on activation, then follows your right hand direction (4m ahead). Set target in Settings > Change Target Player."
            }),
            new ButtonInfo({
                buttonText: "Grab & Throw Target Player",
                isTogglable: true,
                enableMethod: () => {
                    _grabPlayerActive = true;
                    _grabPlayerPrevB = rightSecondary;
                    sendNotification("Holding player in hand — press B to throw!", false, 3);
                },
                disableMethod: () => {
                    _grabPlayerActive = false;
                    sendNotification("Grab OFF", false, 2);
                },
                method: () => {
                    if (!_grabPlayerActive) return;
                    if (time < _grabPlayerDelay) return;
                    _grabPlayerDelay = time + 0.05;
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        const others: any[] = [];
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            others.push(p);
                        }
                        if (others.length === 0) return;
                        targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
                        const target = others[targetPlayerIndex];

                        // B pressed — throw!
                        const bPressed = rightSecondary && !_grabPlayerPrevB;
                        _grabPlayerPrevB = rightSecondary;

                        if (bPressed) {
                            // Get hand forward direction and apply throw force
                            const fwd = rightHandTransform.method("get_forward").invoke();
                            const fx = fwd.field("x").value as number;
                            const fy = fwd.field("y").value as number;
                            const fz = fwd.field("z").value as number;
                            const throwForce = 1800;
                            target.method("RPC_AddForce").invoke([fx * throwForce, fy * throwForce, fz * throwForce]);
                            _grabPlayerActive = false;
                            sendNotification("Player thrown!", false, 2);
                            return;
                        }

                        // Keep player stuck to hand
                        const handPos = rightHandTransform.method("get_position").invoke();
                        target.method("RPC_Teleport").invoke(handPos);

                    } catch(e) { smartError("[Grab & Throw]", e); }
                },
                toolTip: "Holds selected player in your right hand. Press B to throw them in the direction you're pointing. Set target in Settings > Change Target Player."
            }),
            new ButtonInfo({
                buttonText: "Void Touch",
                isTogglable: true,
                enableMethod: () => {
                    _voidTouchActive = true;
                    sendNotification("Void Touch ON — touch a player to send them away!", false, 3);
                },
                disableMethod: () => {
                    _voidTouchActive = false;
                    sendNotification("Void Touch OFF", false, 2);
                },
                method: () => {
                    if (!_voidTouchActive) return;
                    if (time < _voidTouchDelay) return;
                    _voidTouchDelay = time + 0.1;
                    try {
                        const handPos = rightHandTransform.method("get_position").invoke();
                        const hx = handPos.field("x").value as number;
                        const hy = handPos.field("y").value as number;
                        const hz = handPos.field("z").value as number;

                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            const pPos = getTransform(p).method("get_position").invoke();
                            const px = pPos.field("x").value as number;
                            const py = pPos.field("y").value as number;
                            const pz = pPos.field("z").value as number;
                            const dist = Math.sqrt(
                                (hx - px) * (hx - px) +
                                (hy - py) * (hy - py) +
                                (hz - pz) * (hz - pz)
                            );
                            if (dist < 0.5) {
                                p.method("RPC_Teleport").invoke([0, -9999, 0]);
                                sendNotification("Sent to void!", false, 2);
                                break;
                            }
                        }
                    } catch(e) { smartError("[Void Touch]", e); }
                },
                toolTip: "Touch any player with your right hand (within 1.5m) to instantly teleport them to Y=-9999. Toggle to activate."
            }),

            // ── RAGDOLL TOUCH ──────────────────────────────────────────────
            new ButtonInfo({
                buttonText: "Ragdoll Touch",
                isTogglable: true,
                enableMethod: () => { _ragdollTouchActive = true; sendNotification("Ragdoll Touch ON", false, 3); },
                disableMethod: () => { _ragdollTouchActive = false; sendNotification("Ragdoll Touch OFF", false, 2); },
                method: () => {
                    if (!_ragdollTouchActive) return;
                    if (time < _ragdollTouchDelay) return;
                    _ragdollTouchDelay = time + 0.1;
                    try {
                        const handPos = rightHandTransform.method("get_position").invoke();
                        const hx = handPos.field("x").value as number;
                        const hy = handPos.field("y").value as number;
                        const hz = handPos.field("z").value as number;
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            const pPos = getTransform(p).method("get_position").invoke();
                            const dx = hx - (pPos.field("x").value as number);
                            const dy = hy - (pPos.field("y").value as number);
                            const dz = hz - (pPos.field("z").value as number);
                            if (Math.sqrt(dx*dx + dy*dy + dz*dz) < 0.5) {
                                const rx = (Math.random() - 0.5) * 1400;
                                const ry = (Math.random() - 0.5) * 1400;
                                const rz = (Math.random() - 0.5) * 1400;
                                p.method("RPC_AddForce").invoke([rx, ry, rz]);
                            }
                        }
                    } catch(e) { smartError("[Ragdoll Touch]", e); }
                },
                toolTip: "Touch a player with your right hand (within 1.5m) to ragdoll them with random forces every 0.1s."
            }),

            // ── STICKY FLOOR → TARGET ──────────────────────────────────────
            new ButtonInfo({
                buttonText: "Sticky Floor Target",
                isTogglable: true,
                enableMethod: () => { _stickyFloorActive = true; sendNotification("Sticky Floor ON — set target in Settings", false, 3); },
                disableMethod: () => { _stickyFloorActive = false; sendNotification("Sticky Floor OFF", false, 2); },
                method: () => {
                    if (!_stickyFloorActive) return;
                    if (time < _stickyFloorDelay) return;
                    _stickyFloorDelay = time + 0.05;
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        const others: any[] = [];
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            others.push(p);
                        }
                        if (others.length === 0) return;
                        targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
                        others[targetPlayerIndex].method("RPC_AddForce").invoke([0, -1500, 0]);
                    } catch(e) { smartError("[Sticky Floor Target]", e); }
                },
                toolTip: "Continuously pushes selected player down — they can't jump or move. Set target in Settings."
            }),

            // ── STICKY FLOOR TOUCH ─────────────────────────────────────────
            new ButtonInfo({
                buttonText: "Sticky Floor Touch",
                isTogglable: true,
                enableMethod: () => { _stickyFloorTouchActive = true; sendNotification("Sticky Floor Touch ON", false, 3); },
                disableMethod: () => { _stickyFloorTouchActive = false; sendNotification("Sticky Floor Touch OFF", false, 2); },
                method: () => {
                    if (!_stickyFloorTouchActive) return;
                    if (time < _stickyFloorTouchDelay) return;
                    _stickyFloorTouchDelay = time + 0.05;
                    try {
                        const handPos = rightHandTransform.method("get_position").invoke();
                        const hx = handPos.field("x").value as number;
                        const hy = handPos.field("y").value as number;
                        const hz = handPos.field("z").value as number;
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            const pPos = getTransform(p).method("get_position").invoke();
                            const dx = hx - (pPos.field("x").value as number);
                            const dy = hy - (pPos.field("y").value as number);
                            const dz = hz - (pPos.field("z").value as number);
                            if (Math.sqrt(dx*dx + dy*dy + dz*dz) < 0.5) {
                                p.method("RPC_AddForce").invoke([0, -1500, 0]);
                            }
                        }
                    } catch(e) { smartError("[Sticky Floor Touch]", e); }
                },
                toolTip: "Touch a player (within 1.5m) to apply strong downward force — they can't jump while in range."
            }),

            // ── BALLOON TOUCH ──────────────────────────────────────────────
            new ButtonInfo({
                buttonText: "Balloon Touch",
                isTogglable: true,
                enableMethod: () => { _balloonTouchActive = true; sendNotification("Balloon Touch ON", false, 3); },
                disableMethod: () => { _balloonTouchActive = false; sendNotification("Balloon Touch OFF", false, 2); },
                method: () => {
                    if (!_balloonTouchActive) return;
                    if (time < _balloonTouchDelay) return;
                    _balloonTouchDelay = time + 0.05;
                    try {
                        const handPos = rightHandTransform.method("get_position").invoke();
                        const hx = handPos.field("x").value as number;
                        const hy = handPos.field("y").value as number;
                        const hz = handPos.field("z").value as number;
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            const pPos = getTransform(p).method("get_position").invoke();
                            const dx = hx - (pPos.field("x").value as number);
                            const dy = hy - (pPos.field("y").value as number);
                            const dz = hz - (pPos.field("z").value as number);
                            if (Math.sqrt(dx*dx + dy*dy + dz*dz) < 0.5) {
                                p.method("RPC_AddForce").invoke([0, 800, 0]);
                            }
                        }
                    } catch(e) { smartError("[Balloon Touch]", e); }
                },
                toolTip: "Touch a player (within 1.5m) to slowly send them floating upward like a balloon."
            }),

            // ── FREEZE PLAYER (TARGET) ─────────────────────────────────────
            new ButtonInfo({
                buttonText: "Freeze Target Player",
                isTogglable: true,
                enableMethod: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        const others: any[] = [];
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            others.push(p);
                        }
                        if (others.length === 0) { sendNotification("No players found!", false, 2); return; }
                        targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
                        const target = others[targetPlayerIndex];
                        _freezePos = getTransform(target).method("get_position").invoke();
                        _freezeActive = true;
                        sendNotification("Frozen: " + getPlayerName(target), false, 3);
                    } catch(e) { smartError("[Freeze enable]", e); }
                },
                disableMethod: () => { _freezeActive = false; _freezePos = null; sendNotification("Freeze OFF", false, 2); },
                method: () => {
                    if (!_freezeActive || !_freezePos) return;
                    if (time < _freezeDelay) return;
                    _freezeDelay = time + 0.05;
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        const others: any[] = [];
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            others.push(p);
                        }
                        if (others.length === 0) return;
                        targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
                        others[targetPlayerIndex].method("RPC_Teleport").invoke(_freezePos);
                    } catch(e) { smartError("[Freeze Player]", e); }
                },
                toolTip: "Saves selected player's position on activate, then teleports them back every 0.05s — completely stuck. Set target in Settings."
            }),

            // ── FREEZE TOUCH ───────────────────────────────────────────────
            new ButtonInfo({
                buttonText: "Freeze Touch",
                isTogglable: true,
                enableMethod: () => { _freezeTouchActive = true; _freezeTouchMap = {}; sendNotification("Freeze Touch ON — touch a player to freeze them", false, 3); },
                disableMethod: () => { _freezeTouchActive = false; _freezeTouchMap = {}; sendNotification("Freeze Touch OFF — all unfrozen", false, 2); },
                method: () => {
                    if (!_freezeTouchActive) return;
                    if (time < _freezeTouchDelay) return;
                    _freezeTouchDelay = time + 0.05;
                    try {
                        const handPos = rightHandTransform.method("get_position").invoke();
                        const hx = handPos.field("x").value as number;
                        const hy = handPos.field("y").value as number;
                        const hz = handPos.field("z").value as number;
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            const pPos = getTransform(p).method("get_position").invoke();
                            const px = pPos.field("x").value as number;
                            const py = pPos.field("y").value as number;
                            const pz = pPos.field("z").value as number;
                            const dx = hx - px, dy = hy - py, dz = hz - pz;
                            const key = p.handle.toString();
                            if (Math.sqrt(dx*dx + dy*dy + dz*dz) < 0.5 && !_freezeTouchMap[key]) {
                                _freezeTouchMap[key] = [px, py, pz];
                                sendNotification("Froze: " + getPlayerName(p), false, 2);
                            }
                            if (_freezeTouchMap[key]) {
                                p.method("RPC_Teleport").invoke(_freezeTouchMap[key]);
                            }
                        }
                    } catch(e) { smartError("[Freeze Touch]", e); }
                },
                toolTip: "Touch a player (within 1.5m) to freeze them in place. They stay frozen until button is toggled off."
            }),




new ButtonInfo({
    buttonText: "Kick Touch",
    isTogglable: true,
    enableMethod: () => {
        _kickTouchActive = true;
        sendNotification("Kick Touch ON — touch a player to kick them", false, 3);
    },
    disableMethod: () => {
        _kickTouchActive = false;
        sendNotification("Kick Touch OFF", false, 2);
    },
    method: () => {
        if (!_kickTouchActive) return;
        if (time < _kickTouchDelay) return;
        _kickTouchDelay = time + 0.05; // 20Hz cooldown

        try {
            const handPos = rightHandTransform.method("get_position").invoke();
            const hx = handPos.field("x").value;
            const hy = handPos.field("y").value;
            const hz = handPos.field("z").value;

            const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
            const vals = playerDict.method("get_Values").invoke();
            const en = vals.method("GetEnumerator").invoke();

            while (en.method("MoveNext").invoke()) {
                const p = en.method("get_Current").invoke();
                if (!p || p.handle.isNull() || playerIsLocal(p)) continue;

                const pPos = getTransform(p).method("get_position").invoke();
                const px = pPos.field("x").value;
                const py = pPos.field("y").value;
                const pz = pPos.field("z").value;

                const dx = hx - px, dy = hy - py, dz = hz - pz;
                const dist = Math.sqrt(dx*dx + dy*dy + dz*dz);

                if (dist < 0.5) {
                    kickPlayer(p);
                    sendNotification("Kicked: " + getPlayerName(p), false, 2);
                    _kickTouchDelay = time + 0.2; // longer cooldown after kick
                    break; // only kick one per touch event
                }
            }
        } catch(e) {
            smartError("[Kick Touch]", e);
        }
    },
    toolTip: "Touch a player (within 1.5m) to instantly kick them from the lobby."
}),
       


new ButtonInfo({
    buttonText: "Kick Target Player",
    isTogglable: true,
    enableMethod: () => {
        try {
            const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
            const vals = playerDict.method("get_Values").invoke();
            const en = vals.method("GetEnumerator").invoke();
            const others = [];
            while (en.method("MoveNext").invoke()) {
                const p = en.method("get_Current").invoke();
                if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                others.push(p);
            }
            if (others.length === 0) {
                sendNotification("No players found!", false, 2);
                _kickTargetActive = false;
                return;
            }
            targetPlayerIndex = ((targetPlayerIndex % others.length) + others.length) % others.length;
            const target = others[targetPlayerIndex];
            kickPlayer(target);
            sendNotification("Kicked: " + getPlayerName(target), false, 3);
            _kickTargetActive = true;
        } catch(e) {
            smartError("[Kick Target enable]", e);
        }
    },
    disableMethod: () => {
        _kickTargetActive = false;
        sendNotification("Kick Target OFF", false, 2);
    },
    method: () => {
        // Does nothing on every frame — kicks only once on enable
        if (!_kickTargetActive) return;
        // Optional: add a cooldown to prevent re-kicking same player if toggled rapidly
    },
    toolTip: "Select a target player in Settings (cycles through all others). Toggle ON to kick them instantly. Kicks once per enable."
}),

        ],

        [

            new ButtonInfo({
                buttonText: "Exit Arena mods",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to main menu."
            }),

                new ButtonInfo({
                buttonText: "Arena Spammer",
                method: () => {
                    if (time > lagGunDelay) {
                        lagGunDelay = time + 1.5;
                        try { ArenaGameManager.method("StartGame").invoke(); } catch(_) {}
                        try { ArenaGameManager.method("EndGame").invoke(); } catch(_) {}
                        sendNotification("Arena spam tick!", false);
                    }
                },
                isTogglable: true,
                toolTip: "Rapidly starts and ends the arena every 1.5 s while toggled."
            }),

                 new ButtonInfo({
                buttonText: "Start Arena",
                method: () => {
                    try { ArenaGameManager.method("StartGame").invoke(); sendNotification("Arena started!", false); }
                    catch(e) { sendNotification("Start Arena: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Starts the arena game."
            }),
            new ButtonInfo({
                buttonText: "End Arena",
                method: () => {
                    try { ArenaGameManager.method("EndGame").invoke(); sendNotification("Arena ended!", false); }
                    catch(e) { sendNotification("End Arena: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Ends the arena game."
            }),
             
                        new ButtonInfo({
                buttonText: "RPC Award Kill",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        selfRPC(() => player.method("RPC_AwardKill").invoke());
                        sendNotification("Kill awarded!", false);
                    } catch(e) { sendNotification("Award Kill: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Awards a kill to yourself."
            }),
            new ButtonInfo({
                buttonText: "RPC Set Red Team",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        selfRPC(() => player.method("RPC_SetTeam").invoke(1));
                        sendNotification("Red team!", false);
                    } catch(e) { sendNotification("Set Team: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets your team to Red."
            }),
            new ButtonInfo({
                buttonText: "RPC Set Blue Team",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        selfRPC(() => player.method("RPC_SetTeam").invoke(2));
                        sendNotification("Blue team!", false);
                    } catch(e) { sendNotification("Set Team: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets your team to Blue."
            }),

             new ButtonInfo({
                buttonText: "RPC End Arena",
                method: () => {
                    try {
                        const arena = ArenaGameManager.field("_instance").value;
                        if (!arena || arena.isNull()) { sendNotification("Not in arena", false); return; }
                        arena.method("RPC_EndEarly").invoke();
                        sendNotification("Arena ended!", false);
                    } catch(e) { sendNotification("End Arena: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Ends the arena early via RPC."
            }),
           
            
            new ButtonInfo({
                buttonText: "RPC No Team",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        selfRPC(() => player.method("RPC_SetTeam").invoke(0));
                        sendNotification("No team set!", false);
                    } catch(e) { sendNotification("Set Team: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Removes you from any team (team 0)."
            }),

                        new ButtonInfo({
                buttonText: "Award Kill All",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_AwardKill").invoke(); count++; } catch(_) {}
                        }
                        sendNotification("Awarded kill to " + count + " players!", false);
                    } catch(e) { sendNotification("Award Kill All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Awards a kill to all other players."
            }),

                       new ButtonInfo({
                buttonText: "Set Kills +10",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const kills = player.method("get_kills").invoke();
                        player.method("set_kills").invoke(kills + 10);
                        sendNotification("Kills: " + (kills + 10), false);
                    } catch(e) { sendNotification("Set Kills: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Adds 10 kills to your score."
            }),
            new ButtonInfo({
                buttonText: "Set Deaths 0",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        player.method("set_deaths").invoke(0);
                        sendNotification("Deaths reset to 0!", false);
                    } catch(e) { sendNotification("Set Deaths: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets your death count to 0."
            }),

                        new ButtonInfo({
                buttonText: "RPC Force All Red Team",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_SetTeam").invoke(1); count++; } catch(_) {}
                        }
                        sendNotification("Set " + count + " players to red team!", false);
                    } catch(e) { sendNotification("Force Team: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all other players to red team."
            }),
            new ButtonInfo({
                buttonText: "RPC Force All Blue Team",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_SetTeam").invoke(2); count++; } catch(_) {}
                        }
                        sendNotification("Set " + count + " players to blue team!", false);
                    } catch(e) { sendNotification("Force Team: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all other players to blue team."
            }),

        ],
            [
            new ButtonInfo({
                buttonText: "Exit RPC Stuff",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to main menu."
            }),
            new ButtonInfo({
                buttonText: "Launch Me Up",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        selfRPC(() => player.method("RPC_AddForce").invoke([0, 1500, 0]));
                        sendNotification("Launch!", false);
                    } catch(e) { sendNotification("Launch: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Launches yourself upward via RPC_AddForce."
            }),
            
            
            new ButtonInfo({
                buttonText: "RPC Tag Stinky",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        selfRPC(() => player.method("RPC_TagAsStinky").invoke());
                        sendNotification("Tagged as stinky!", false);
                    } catch(e) { sendNotification("Tag Stinky: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Tags yourself as stinky."
            }),
            new ButtonInfo({
                buttonText: "RPC Teleport Up",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const pos = getTransform(player).method("get_position").invoke();
                        const upPos = [pos.field("x").value, pos.field("y").value + 20, pos.field("z").value];
                        selfRPC(() => player.method("RPC_Teleport").invoke(upPos));
                        sendNotification("Teleported up!", false);
                    } catch(e) { sendNotification("TP Up: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Teleports you 20 units upward."
            }),
            new ButtonInfo({
                buttonText: "RPC Color Red",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        selfRPC(() => player.method("RPC_SetColorHSV").invoke(99999.0, 0.0, 1.0, 1.0));
                        sendNotification("Color: Red!", false);
                    } catch(e) { sendNotification("Color: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets your color to red permanently."
            }),
            new ButtonInfo({
                buttonText: "RPC Color Reset",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        selfRPC(() => player.method("RPC_SetColorHSV").invoke(0.0, 0.0, 0.0, 0.0));
                        sendNotification("Color reset!", false);
                    } catch(e) { sendNotification("Color reset: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets your color."
            }),
            
            new ButtonInfo({
                buttonText: "RPC Kill All",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_DoPlayerDie").invoke(true); count++; } catch(_) {}
                        }
                        sendNotification("Killed " + count + " players!", false);
                    } catch(e) { sendNotification("Kill All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Kills all players via RPC_DoPlayerDie."
            }),
            
            new ButtonInfo({
                buttonText: "RPC Launch All",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_AddForce").invoke([0, 1500, 0]); count++; } catch(_) {}
                        }
                        sendNotification("Launched " + count + " players!", false);
                    } catch(e) { sendNotification("Launch All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Launches all other players upward."
            }),
            new ButtonInfo({
                buttonText: "RPC TP All 2 Me",
                method: () => {
                    try {
                        const me = NetPlayer.method("get_localPlayer").invoke();
                        if (!me || me.handle.isNull()) return;
                        const myPos = getTransform(me).method("get_position").invoke();
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_Teleport").invoke(myPos); count++; } catch(_) {}
                        }
                        sendNotification("TP'd " + count + " players to you!", false);
                    } catch(e) { sendNotification("TP All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Teleports all players to your position."
            }),
            new ButtonInfo({
                buttonText: "RPC Stinky All",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_TagAsStinky").invoke(); count++; } catch(_) {}
                        }
                        sendNotification("Stinkied " + count + " players!", false);
                    } catch(e) { sendNotification("Stinky All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Tags all other players as stinky."
            }),
           
            new ButtonInfo({
                buttonText: "Set Scale Big",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        try { player.method("set_playerScale").invoke(5.0); } catch(_) {}
                        try { player.field("_playerScale").value = 5.0; } catch(_) {}
                        try { player.method("SetNormalizedScaleModifier").invoke(5.0); } catch(_) {}
                        sendNotification("Scale set to big!", false);
                    } catch(e) { sendNotification("Set Scale: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets your player scale to big."
            }),
            new ButtonInfo({
                buttonText: "Set Scale Normal",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        try { player.method("set_playerScale").invoke(1.0); } catch(_) {}
                        try { player.field("_playerScale").value = 1.0; } catch(_) {}
                        try { player.method("SetNormalizedScaleModifier").invoke(1.0); } catch(_) {}
                        sendNotification("Scale reset to normal!", false);
                    } catch(e) { sendNotification("Set Scale: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets your player scale to normal."
            }),
            new ButtonInfo({
                buttonText: "Set Scale Tiny",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        try { player.method("set_playerScale").invoke(0.1); } catch(_) {}
                        try { player.field("_playerScale").value = 0.1; } catch(_) {}
                        try { player.method("SetNormalizedScaleModifier").invoke(0.1); } catch(_) {}
                        sendNotification("Scale set to tiny!", false);
                    } catch(e) { sendNotification("Set Scale: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets your player scale to tiny."
            }),
 
            
            new ButtonInfo({
                buttonText: "Hide All Players",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("set_isHide").invoke(true); count++; } catch(_) {}
                        }
                        sendNotification("Hid " + count + " players!", false);
                    } catch(e) { sendNotification("Hide All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Hides all other players from the game."
            }),
            new ButtonInfo({
                buttonText: "Show All Players",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("set_isHide").invoke(false); count++; } catch(_) {}
                        }
                        sendNotification("Showed " + count + " players!", false);
                    } catch(e) { sendNotification("Show All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Makes all hidden players visible again."
            }),

            new ButtonInfo({
                buttonText: "Freeze All",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try {
                                const pos = getTransform(p).method("get_position").invoke();
                                
                                p.method("RPC_PlayerStun").invoke(pos, 999.0, 9999.0, 0);
                                count++;
                            } catch(_) {}
                        }
                        sendNotification("Froze " + count + " players!", false);
                    } catch(e) { sendNotification("Freeze All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Stuns all other players with max duration (freeze effect)."
            }),
            
            new ButtonInfo({
                buttonText: "RPC Rainbow All",
                isTogglable: true,
                method: () => {
                    try {
                        if (frameCount % 10 !== 0) return;
                        const h = (time * 0.5) % 1.0;
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_SetColorHSV").invoke(99999.0, h, 1.0, 1.0); } catch(_) {}
                        }
                    } catch(e) {}
                },
                toolTip: "Cycles all players through rainbow colors."
            }),
            
            new ButtonInfo({
                buttonText: "Launch All Down",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_AddForce").invoke([0, -1500, 0]); count++; } catch(_) {}
                        }
                        sendNotification("Slammed " + count + " players down!", false);
                    } catch(e) { sendNotification("Launch Down: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Slams all other players downward."
            }),
            
            new ButtonInfo({
                buttonText: "RPC TP All 2 Void",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_Teleport").invoke([0, -99999, 0]); count++; } catch(_) {}
                        }
                        sendNotification("Voided " + count + " players!", false);
                    } catch(e) { sendNotification("TP Void: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Teleports all other players to the void."
            }),
            

            new ButtonInfo({
                buttonText: "RPC Color All Rainbow",
                isTogglable: true,
                method: () => {
                    if (frameCount % 8 !== 0) return;
                    try {
                        const h = (time * 0.4) % 1.0;
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull()) continue;
                            try { p.method("RPC_SetColorHSV").invoke(99999.0, h, 1.0, 1.0); } catch(_) {}
                        }
                    } catch(_) {}
                },
                toolTip: "Cycles all players (incl. you) through rainbow colors continuously."
            }),
            
            new ButtonInfo({
                buttonText: "RPC Hit All 50",
                method: () => {
                    try {
                        const dmgNull = DamageSourceInfoClass.method("get_Null").invoke();
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try {
                                const pos = getTransform(p).method("get_position").invoke();
                                p.method("RPC_PlayerHit", 3).invoke(50, pos, dmgNull);
                                count++;
                            } catch(_) {}
                        }
                        sendNotification("Hit " + count + " players for 50dmg!", false);
                    } catch(e) { sendNotification("Hit All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Deals 50 damage to all other players."
            }),

                        new ButtonInfo({
                buttonText: "RPC kill all",
                method: () => {
                    try {
                        const dmgNull = DamageSourceInfoClass.method("get_Null").invoke();
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try {
                                const pos = getTransform(p).method("get_position").invoke();
                                p.method("RPC_PlayerHit", 3).invoke(999999, pos, dmgNull);
                                count++;
                            } catch(_) {}
                        }
                        sendNotification("Hit " + count + " players for 9999999dmg!", false);
                    } catch(e) { sendNotification("Hit All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Deals 9999999 damage to all other players."
            }),

            new ButtonInfo({
                buttonText: "RPC Bounce All",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            
                            const rX = (Math.random() - 0.5) * 2000;
                            const rZ = (Math.random() - 0.5) * 2000;
                            try { p.method("RPC_AddForce").invoke([rX, 1200, rZ]); count++; } catch(_) {}
                        }
                        sendNotification("Bounced " + count + " players!", false);
                    } catch(e) { sendNotification("Bounce All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Launches all other players in random directions."
            }),
            
            new ButtonInfo({
                buttonText: "RPC Add Kills All",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try {
                                const kills = p.method("get_kills").invoke();
                                p.method("set_kills").invoke(kills + 10);
                                count++;
                            } catch(_) {}
                        }
                        sendNotification("+10 kills to " + count + " players!", false);
                    } catch(e) { sendNotification("Add Kills: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Adds 10 kills to all players."
            }),
           
            new ButtonInfo({
                buttonText: "RPC Money All +10M",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_AddPlayerMoney").invoke(10000000); count++; } catch(_) {}
                        }
                        sendNotification("Gave 10M money to " + count + " players!", false);
                    } catch(e) { sendNotification("Money All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Gives 10,000,000 money to all other players."
            }),
            new ButtonInfo({
                buttonText: "RPC Inf Money All +10M",
                enableMethod: () => { rpcMoneyAllLoopDelay = 0; sendNotification("RPC Inf Money All ON", false); },
                disableMethod: () => { sendNotification("RPC Inf Money All OFF", false); },
                isTogglable: true,
                method: () => {
                    if (time <= rpcMoneyAllLoopDelay) return;
                    rpcMoneyAllLoopDelay = time + 0.9;
                    try {
                        for (const p of getAllNetPlayersList(false)) {
                            try { p.method("RPC_AddPlayerMoney").invoke(10000000); } catch(_) {}
                        }
                    } catch(e) { console.error("RPC Inf Money All:", e); }
                },
                toolTip: "Continuously gives 10,000,000 money to all other players with a low-frequency loop."
            }),
            new ButtonInfo({
                buttonText: "RPC Remove 10K Money All",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            try { p.method("RPC_AddPlayerMoney").invoke(-99999); count++; } catch(_) {}
                        }
                        sendNotification("Drained money from " + count + " players!", false);
                    } catch(e) { sendNotification("Money Drain: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Removes 99999 money from all other players."
            }),
            
            new ButtonInfo({
                buttonText: "RPC TP Me To Sky",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const pos = getTransform(player).method("get_position").invoke();
                        selfRPC(() => player.method("RPC_Teleport").invoke([pos.field("x").value, pos.field("y").value + 200, pos.field("z").value]));
                        sendNotification("Teleported to sky!", false);
                    } catch(e) { sendNotification("TP Sky: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Teleports you 200 units straight up."
            }),
            new ButtonInfo({
                buttonText: "RPC Explosive Launch Me",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        
                        const rX = (Math.random() - 0.5) * 3000;
                        const rZ = (Math.random() - 0.5) * 3000;
                        selfRPC(() => player.method("RPC_AddForce").invoke([rX, 2500, rZ]));
                        sendNotification("Explosive launch!", false);
                    } catch(e) { sendNotification("Explosive Launch: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Launches yourself in a random explosive direction."
            }),
            
            new ButtonInfo({
                buttonText: "RPC Gun Launch",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.4;
                        try {
                            const hitCollider = ray.method("get_collider").invoke();
                            if (!hitCollider || hitCollider.isNull()) return;
                            const hitGO = hitCollider.method("get_gameObject").invoke();
                            const hitPlayer = hitGO.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                            if (!hitPlayer || hitPlayer.isNull()) { sendNotification("No player there", false); return; }
                            if (playerIsLocal(hitPlayer)) return;
                            hitPlayer.method("RPC_AddForce").invoke([0, 1500, 0]);
                            sendNotification("Launched: " + getPlayerName(hitPlayer), false);
                        } catch(e) { console.error("RPC Gun Launch:", e); }
                    }
                },
                toolTip: "Point at any player, pull trigger to launch them (hold grip)."
            }),
            
            new ButtonInfo({
                buttonText: "RPC Gun Color",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.3;
                        try {
                            const hitCollider = ray.method("get_collider").invoke();
                            if (!hitCollider || hitCollider.isNull()) return;
                            const hitGO = hitCollider.method("get_gameObject").invoke();
                            const hitPlayer = hitGO.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                            if (!hitPlayer || hitPlayer.isNull()) { sendNotification("No player there", false); return; }
                            const h = (time * 0.5) % 1.0;
                            hitPlayer.method("RPC_SetColorHSV").invoke(99999.0, h, 1.0, 1.0);
                            sendNotification("Rainbow'd: " + getPlayerName(hitPlayer), false);
                        } catch(e) { console.error("RPC Gun Color:", e); }
                    }
                },
                toolTip: "Point at any player, pull trigger to rainbow them (hold grip)."
            }),
            new ButtonInfo({
                buttonText: "RPC Gun Scale Big",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.4;
                        try {
                            const hitCollider = ray.method("get_collider").invoke();
                            if (!hitCollider || hitCollider.isNull()) return;
                            const hitGO = hitCollider.method("get_gameObject").invoke();
                            const hitPlayer = hitGO.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                            if (!hitPlayer || hitPlayer.isNull()) { sendNotification("No player there", false); return; }
                            try { hitPlayer.method("set_playerScale").invoke(5.0); } catch(_) {}
                            try { hitPlayer.field("_playerScale").value = 5.0; } catch(_) {}
                            sendNotification("Scaled big: " + getPlayerName(hitPlayer), false);
                        } catch(e) { console.error("RPC Gun Scale:", e); }
                    }
                },
                toolTip: "Point at any player, pull trigger to make them big (hold grip)."
            }),
            new ButtonInfo({
                buttonText: "RPC Gun Scale Tiny",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.4;
                        try {
                            const hitCollider = ray.method("get_collider").invoke();
                            if (!hitCollider || hitCollider.isNull()) return;
                            const hitGO = hitCollider.method("get_gameObject").invoke();
                            const hitPlayer = hitGO.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                            if (!hitPlayer || hitPlayer.isNull()) { sendNotification("No player there", false); return; }
                            try { hitPlayer.method("set_playerScale").invoke(0.1); } catch(_) {}
                            try { hitPlayer.field("_playerScale").value = 0.1; } catch(_) {}
                            sendNotification("Shrunk: " + getPlayerName(hitPlayer), false);
                        } catch(e) { console.error("RPC Gun Scale Tiny:", e); }
                    }
                },
                toolTip: "Point at any player, pull trigger to shrink them (hold grip)."
            }),
            
            new ButtonInfo({
                buttonText: "RPC Gun Void",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.4;
                        try {
                            const hitCollider = ray.method("get_collider").invoke();
                            if (!hitCollider || hitCollider.isNull()) return;
                            const hitGO = hitCollider.method("get_gameObject").invoke();
                            const hitPlayer = hitGO.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                            if (!hitPlayer || hitPlayer.isNull()) { sendNotification("No player there", false); return; }
                            if (playerIsLocal(hitPlayer)) return;
                            hitPlayer.method("RPC_Teleport").invoke([0, -99999, 0]);
                            sendNotification("Voided: " + getPlayerName(hitPlayer), false);
                        } catch(e) { console.error("RPC Gun Void:", e); }
                    }
                },
                toolTip: "Point at any player, pull trigger to void them (hold grip)."
            }),
            new ButtonInfo({
                buttonText: "RPC Gun Hit 50",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.3;
                        try {
                            const hitCollider = ray.method("get_collider").invoke();
                            if (!hitCollider || hitCollider.isNull()) return;
                            const hitGO = hitCollider.method("get_gameObject").invoke();
                            const hitPlayer = hitGO.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                            if (!hitPlayer || hitPlayer.isNull()) { sendNotification("No player there", false); return; }
                            if (playerIsLocal(hitPlayer)) return;
                            const pos = getTransform(hitPlayer).method("get_position").invoke();
                            const dmgNull = DamageSourceInfoClass.method("get_Null").invoke();
                            hitPlayer.method("RPC_PlayerHit", 3).invoke(50, pos, dmgNull);
                            sendNotification("Hit 50dmg: " + getPlayerName(hitPlayer), false);
                        } catch(e) { console.error("RPC Gun Hit 50:", e); }
                    }
                },
                toolTip: "Point at any player, pull trigger to deal 50 damage (hold grip)."
            }),
            
            new ButtonInfo({
                buttonText: "RPC All Color Rainbow Loop",
                isTogglable: true,
                method: () => {
                    if (frameCount % 6 !== 0) return;
                    try {
                        const h = (time * 0.6) % 1.0;
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull()) continue;
                            try { p.method("RPC_SetColorHSV").invoke(99999.0, h, 1.0, 1.0); } catch(_) {}
                        }
                    } catch(_) {}
                },
                toolTip: "Cycles ALL players (incl. you) through faster rainbow (toggle)."
            }),

        ],

        // ── CATEGORY 23 ── Credits ─────────────────────────────────────────
        [
            new ButtonInfo({
                buttonText: "Exit Credits",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to main menu."
            }),
            new ButtonInfo({
                buttonText: "Credits to harry",
                method: () => { sendNotification("Credits to harry for menu!", false, 6); },
                isTogglable: false,
                toolTip: "Credits to harry for menu."
            }),
            new ButtonInfo({
                buttonText: "G2 Menu",
                method: () => { sendNotification("G2 Menu", false, 6); },
                isTogglable: false,
                toolTip: "G2 Menu."
            }),
            new ButtonInfo({
                buttonText: "Credits to Codex",
                method: () => { sendNotification("Credits to Codex", false, 6); },
                isTogglable: false,
                toolTip: "Credits to Codex."

            }),
            new ButtonInfo({
                buttonText: "credits to Giulian",
                method: () => { sendNotification("Credits to Giulian", false, 6); },
                isTogglable: false,
                toolTip: "Credits to Giulian."
        
            }),

            new ButtonInfo({
                buttonText: "credits to dabeans",
                method: () => { sendNotification("Credits to dabeans", false, 6); },
                isTogglable: false,
                toolTip: "Credits to dabeans."
        
            }),

        ],

        [ 
            new ButtonInfo({
                buttonText: "Exit Monster RPCs",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to main menu."
            }),
                

            new ButtonInfo({
                buttonText: "Kill All Mobs",
                method: () => {
                    try {
                        let count = 0;
                        const runnerInstance = SFXManager.field("_instance").value;
                        const runner = getSfxCurrentRunner();

                        for (const mobID of mobIDs) {
                            try {
                                const klass = AssemblyCSharp.class("AnimalCompany." + mobID.name + "Controller");
                                const objs = Object.method("FindObjectsByType", 1).inflate(klass).invoke(0);
                                if (!objs || objs.isNull()) continue;
                                for (let i = 0; i < objs.length; i++) {
                                    try {
                                        const mob = objs.get(i);
                                        if (!mob || mob.isNull()) continue;
                                        let killed = false;
                                        try { mob.method("RPC_KillMob").invoke(); killed = true; } catch(_) {}
                                        if (!killed) try { mob.method("KillMob").invoke(); killed = true; } catch(_) {}
                                        if (!killed) try { mob.method("Die").invoke(); killed = true; } catch(_) {}
                                        if (!killed && runner && !runner.isNull?.()) {
                                            try {
                                                const no = mob.method("GetComponent", 1)
                                                    .inflate(Il2Cpp.domain.assembly("Fusion.Runtime").image.class("Fusion.NetworkObject"))
                                                    .invoke();
                                                if (no && !no.isNull()) { runner.method("Despawn").invoke(no); killed = true; }
                                          } catch(_) {}
                                        }
                                        if (!killed && runner && !runner.isNull?.()) {
                                            try { runner.method("Despawn").invoke(mob); killed = true; } catch(_) {}
                                        }
                                        if (!killed) {
                                            try {
                                                const go = mob.method("get_gameObject").invoke();
                                                if (go && !go.isNull()) {
                                                    Object.method("Destroy", 1).invoke(go);
                                                    killed = true;
                                                }
                                            } catch(_) {}
                                        }
                                        if (!killed) {
                                            try { Object.method("Destroy", 1).invoke(mob); killed = true; } catch(_) {}
                                        }
                                        if (killed) count++;
                                    } catch(_) {}
                                }
                            } catch(_) {}
                        }
                        sendNotification("Killed " + count + " mobs!", false);
                    } catch(e) { sendNotification("Kill Mobs: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Kills all mobs in the scene."
            }),

            new ButtonInfo({
                buttonText: "Rainbow All Monsters",
                isTogglable: true,
                method: () => {
                    try {
                        if (frameCount % 300 === 0 || rainbowMobsCache.length === 0) {
                            rainbowMobsCache = [];
                            for (const mobID of mobIDs) {
                                try {
                                    const klass = AssemblyCSharp.class("AnimalCompany." + mobID.name + "Controller");
                                    const objs = Object.method("FindObjectsByType", 1).inflate(klass).invoke(0);
                                    if (!objs || objs.isNull()) continue;
                                    for (let j = 0; j < objs.length; j++) {
                                        try { const mob = objs.get(j); if (mob && !mob.isNull()) rainbowMobsCache.push(mob); } catch(_) {}
                                    }
                                } catch(_) {}
                            }
                        }
                        if (rainbowMobsCache.length > 0) {
                            const h = (time * 2.0) % 1.0;
                            rainbowMobsCursor = rainbowMobsCursor % rainbowMobsCache.length;
                            const mob = rainbowMobsCache[rainbowMobsCursor];
                            rainbowMobsCursor++;
                            try {
                                if (!mob || mob.isNull()) { rainbowMobsCache.splice(rainbowMobsCursor - 1, 1); rainbowMobsCursor = 0; }
                                else {
                                    let colored = false;
                                    try {
                                        const go = mob.method("get_gameObject").invoke();
                                        if (go && !go.isNull()) {
                                            const gbo = go.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                                            if (gbo && !gbo.isNull()) { gbo.method("SetColorHue").invoke(h); gbo.method("HandleColorHueChanged").invoke(); colored = true; }
                                        }
                                    } catch(_) {}
                                    if (!colored) try {
                                        const gbi = mob.method("GetComponent", 1).inflate(GBIClass).invoke();
                                        if (gbi && !gbi.isNull()) { gbi.method("SetColorHue").invoke(h); colored = true; }
                                    } catch(_) {}
                                    if (!colored) try { mob.method("RPC_SetColorHSV").invoke(99999.0, h, 1.0, 1.0); } catch(_) {}
                                }
                            } catch(_) {}
                        }
                    } catch(_) {}
                },
                toolTip: "Continuously cycles all monsters through rainbow colors (toggle)."
            }),

            new ButtonInfo({
                buttonText: "Explode All Mobs",
                method: () => {
                    try {
                        sendNotification("Explode All Mobs action not implemented yet", false);
                    } catch(_) {}
                },
                isTogglable: false,
                toolTip: "Explodes all mobs in the scene."
            }),
            
            new ButtonInfo({
                buttonText: "Mob TP To Me",
                method: () => {
                    try {
                        const me = NetPlayer.method("get_localPlayer").invoke();
                        if (!me || me.handle.isNull()) return;
                        const pos = getTransform(me).method("get_position").invoke();
                        let count = 0;
                        for (const mobID of mobIDs) {
                            try {
                                const klass = AssemblyCSharp.class("AnimalCompany." + mobID.name + "Controller");
                                const objs = Object.method("FindObjectsByType", 1).inflate(klass).invoke(0);
                                if (!objs || objs.isNull()) continue;
                                for (let i = 0; i < objs.length; i++) {
                                    try {
                                        const mob = objs.get(i);
                                        if (!mob || mob.isNull()) continue;
                                        getTransform(mob).method("set_position").invoke(pos);
                                        count++;
                                    } catch(_) {}
                                }
                            } catch(_) {}
                        }
                        sendNotification("Teleported " + count + " mobs to you!", false);
                    } catch(e) { sendNotification("Mob TP: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Teleports all mobs to your position."
            }),
            new ButtonInfo({
                buttonText: "Mob Scale Big",
                method: () => {
                    try {
                        let count = 0;
                        for (const mobID of mobIDs) {
                            try {
                                const klass = AssemblyCSharp.class("AnimalCompany." + mobID.name + "Controller");
                                const objs = Object.method("FindObjectsByType", 1).inflate(klass).invoke(0);
                                if (!objs || objs.isNull()) continue;
                                for (let i = 0; i < objs.length; i++) {
                                    try {
                                        const mob = objs.get(i);
                                        if (!mob || mob.isNull()) continue;
                                        getTransform(mob).method("set_localScale").invoke([5, 5, 5]);
                                        count++;
                                    } catch(_) {}
                                }
                            } catch(_) {}
                        }
                        sendNotification("Scaled " + count + " mobs big!", false);
                    } catch(e) { sendNotification("Mob Scale: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Makes all mobs giant."
            }),
            new ButtonInfo({
                buttonText: "Mob Scale Tiny",
                method: () => {
                    try {
                        let count = 0;
                        for (const mobID of mobIDs) {
                            try {
                                const klass = AssemblyCSharp.class("AnimalCompany." + mobID.name + "Controller");
                                const objs = Object.method("FindObjectsByType", 1).inflate(klass).invoke(0);
                                if (!objs || objs.isNull()) continue;
                                for (let i = 0; i < objs.length; i++) {
                                    try {
                                        const mob = objs.get(i);
                                        if (!mob || mob.isNull()) continue;
                                        getTransform(mob).method("set_localScale").invoke([0.1, 0.1, 0.1]);
                                        count++;
                                    } catch(_) {}
                                }
                            } catch(_) {}
                        }
                        sendNotification("Shrunk " + count + " mobs!", false);
                    } catch(e) { sendNotification("Mob Scale: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Makes all mobs tiny."
            }),
            new ButtonInfo({
                buttonText: "Mob Freeze",
                isTogglable: true,
                method: () => {
                    if (time > mobGunDelay) {
                        mobGunDelay = time + 0.5;
                        try {
                            for (const mobID of mobIDs) {
                                try {
                                    const klass = AssemblyCSharp.class("AnimalCompany." + mobID.name + "Controller");
                                    const objs = Object.method("FindObjectsByType", 1).inflate(klass).invoke(0);
                                    if (!objs || objs.isNull()) continue;
                                    for (let i = 0; i < objs.length; i++) {
                                        try {
                                            const mob = objs.get(i);
                                            if (!mob || mob.isNull()) continue;
                                            try { mob.method("RPC_Stun").invoke(999.0); } catch(_) {}
                                            try { mob.method("Stun").invoke(999.0); } catch(_) {}
                                            try { mob.method("set_isStunned").invoke(true); } catch(_) {}
                                            
                                            try {
                                                const rb = getComponent(mob.method("get_gameObject").invoke(), Rigidbody);
                                                if (rb && !rb.isNull()) {
                                                    rb.method("set_isKinematic").invoke(true);
                                                }
                                            } catch(_) {}
                                        } catch(_) {}
                                    }
                                } catch(_) {}
                            }
                        } catch(_) {}
                    }
                },
                toolTip: "Continuously freezes all mobs (toggle)."
            }),
            
            new ButtonInfo({
                buttonText: "Mob Gun TP To Me",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > mobGunDelay2) {
                        mobGunDelay2 = time + 0.4;
                        try {
                            const hitCollider = ray.method("get_collider").invoke();
                            if (!hitCollider || hitCollider.isNull()) return;
                            const hitGO = hitCollider.method("get_gameObject").invoke();
                            const me = NetPlayer.method("get_localPlayer").invoke();
                            if (!me) return;
                            const pos = getTransform(me).method("get_position").invoke();
                            for (const mobID of mobIDs) {
                                try {
                                    const klass = AssemblyCSharp.class("AnimalCompany." + mobID.name + "Controller");
                                    const mob = hitGO.method("GetComponentInParent", 0).inflate(klass).invoke();
                                    if (!mob || mob.isNull()) continue;
                                    getTransform(mob).method("set_position").invoke(pos);
                                    sendNotification("Teleported " + mobID + " to you!", false);
                                    return;
                                } catch(_) {}
                            }
                        } catch(e) { console.error("Mob Gun TP:", e); }
                    }
                },
                toolTip: "Point at a mob and pull trigger to teleport it to you (hold grip)."
            }),
            new ButtonInfo({
                buttonText: "Mob Gun Scale Big",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > mobGunDelay2) {
                        mobGunDelay2 = time + 0.4;
                        try {
                            const hitCollider = ray.method("get_collider").invoke();
                            if (!hitCollider || hitCollider.isNull()) return;
                            const hitGO = hitCollider.method("get_gameObject").invoke();
                            for (const mobID of mobIDs) {
                                try {
                                    const klass = AssemblyCSharp.class("AnimalCompany." + mobID.name + "Controller");
                                    const mob = hitGO.method("GetComponentInParent", 0).inflate(klass).invoke();
                                    if (!mob || mob.isNull()) continue;
                                    getTransform(mob).method("set_localScale").invoke([5, 5, 5]);
                                    sendNotification("Scaled " + mobID + " big!", false);
                                    return;
                                } catch(_) {}
                            }
                        } catch(e) { console.error("Mob Scale Gun:", e); }
                    }
                },
                toolTip: "Point at a mob and pull trigger to make it giant (hold grip)."
            }),
            
            
            new ButtonInfo({
                buttonText: "Mob TP Loop",
                isTogglable: true,
                method: () => {
                    if (time > mobGunDelay) {
                        mobGunDelay = time + 2.0;
                        try {
                            const me = NetPlayer.method("get_localPlayer").invoke();
                            if (!me || me.handle.isNull()) return;
                            const pos = getTransform(me).method("get_position").invoke();
                            for (const mobID of mobIDs) {
                                try {
                                    const klass = AssemblyCSharp.class("AnimalCompany." + mobID.name + "Controller");
                                    const objs = Object.method("FindObjectsByType", 1).inflate(klass).invoke(0);
                                    if (!objs || objs.isNull()) continue;
                                    for (let i = 0; i < objs.length; i++) {
                                        try {
                                            const mob = objs.get(i);
                                            if (!mob || mob.isNull()) continue;
                                            getTransform(mob).method("set_position").invoke(pos);
                                        } catch(_) {}
                                    }
                                } catch(_) {}
                            }
                        } catch(_) {}
                    }
                },
                toolTip: "Continuously teleports all mobs to you every 2s (toggle)."
            }),
           
            new ButtonInfo({
                buttonText: "Exit Extra WL",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to main menu."
            }),
            new ButtonInfo({
                buttonText: "WL All Speed Loop",
                isTogglable: true,
                method: () => {
                    if (time > lagGunDelay) {
                        lagGunDelay = time + 3.0;
                        try {
                            const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                            const vals = playerDict.method("get_Values").invoke();
                            const en = vals.method("GetEnumerator").invoke();
                            while (en.method("MoveNext").invoke()) {
                                const p = en.method("get_Current").invoke();
                                if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                                if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                                try { p.method("RPC_ApplyBuff").invoke(1); } catch(_) {}
                            }
                        } catch(_) {}
                    }
                },
                toolTip: "Continuously re-applies SpeedBoost to all WL players every 3s (toggle)."
            }),
            new ButtonInfo({
                buttonText: "WL All AntiGrav Loop",
                isTogglable: true,
                method: () => {
                    if (time > lagGunDelay) {
                        lagGunDelay = time + 3.0;
                        try {
                            const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                            const vals = playerDict.method("get_Values").invoke();
                            const en = vals.method("GetEnumerator").invoke();
                            while (en.method("MoveNext").invoke()) {
                                const p = en.method("get_Current").invoke();
                                if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                                if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                                try { p.method("RPC_ApplyBuff").invoke(7); } catch(_) {}
                            }
                        } catch(_) {}
                    }
                },
                toolTip: "Continuously re-applies AntiGravity to all WL players every 3s (toggle)."
            }),
            new ButtonInfo({
                buttonText: "WL Invincible Loop",
                isTogglable: true,
                method: () => {
                    if (time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                            const vals = playerDict.method("get_Values").invoke();
                            const en = vals.method("GetEnumerator").invoke();
                            while (en.method("MoveNext").invoke()) {
                                const p = en.method("get_Current").invoke();
                                if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                                if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                                try { p.method("set_isInvincible").invoke(true); } catch(_) {}
                            }
                        } catch(_) {}
                    }
                },
                toolTip: "Keeps all WL players invincible (toggle)."
            }),
            new ButtonInfo({
                buttonText: "WL Revive Loop",
                isTogglable: true,
                method: () => {
                    if (time > lagGunDelay) {
                        lagGunDelay = time + 1.0;
                        try {
                            const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                            const vals = playerDict.method("get_Values").invoke();
                            const en = vals.method("GetEnumerator").invoke();
                            while (en.method("MoveNext").invoke()) {
                                const p = en.method("get_Current").invoke();
                                if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                                if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                                try {
                                    const isDead = p.method("get_isDie").invoke();
                                    if (isDead) p.method("RPC_DoPlayerDie").invoke(false);
                                } catch(_) {}
                            }
                        } catch(_) {}
                    }
                },
                toolTip: "Auto-revives WL players when they die (toggle)."
            }),
            new ButtonInfo({
                buttonText: "WL Rainbow Loop",
                isTogglable: true,
                method: () => {
                    if (frameCount % 10 !== 0) return;
                    try {
                        const h = (time * 0.5) % 1.0;
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                            try { p.method("RPC_SetColorHSV").invoke(99999.0, h, 1.0, 1.0); } catch(_) {}
                        }
                    } catch(_) {}
                },
                toolTip: "Continuously rainbow-cycles WL players (toggle)."
            }),
            new ButtonInfo({
                buttonText: "WL Bounce Gun Loop",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player || target.blocked) return;
                            const rX = (Math.random() - 0.5) * 2000;
                            const rZ = (Math.random() - 0.5) * 2000;
                            target.player.method("RPC_AddForce").invoke([rX, 1300, rZ]);
                            sendNotification("Bounced " + target.id + "!", false);
                        } catch(e) { console.error("WL Bounce Gun:", e); }
                    }
                },
                toolTip: "Continuously bounces aimed WL player (hold grip)."
            }),
            new ButtonInfo({
                buttonText: "WL Kill Loop Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (time > lagGunDelay) {
                        lagGunDelay = time + 0.8;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player || target.blocked) return;
                            target.player.method("RPC_DoPlayerDie").invoke(true);
                        } catch(e) { console.error("WL Kill Loop:", e); }
                    }
                },
                toolTip: "Continuously kills aimed WL player (hold grip). Toggle on to keep killing."
            }),
            new ButtonInfo({
                buttonText: "WL VFX Spam Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (time > lagGunDelay) {
                        lagGunDelay = time + 0.2;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player || target.blocked) return;
                            const pos = getTransform(target.player).method("get_position").invoke();
                            const runner = getSfxCurrentRunner();
                            const vfxList = [
                                VFXTypes.ConfettiBurst, VFXTypes.GreenBlink, VFXTypes.Ethereal_Void,
                                VFXTypes.Explosion_Coins, VFXTypes.MeatExplosion_1, VFXTypes.MidAirJump_Fart
                            ];
                            const vfx = vfxList[Math.floor(Math.random() * vfxList.length)];
                            try { ParticleManagerClass.method("RPC_PlayVFX", 4).invoke(runner, vfx, pos, identityQuaternion); } catch(_) {}
                        } catch(e) { console.error("WL VFX Gun:", e); }
                    }
                },
                toolTip: "Spams random VFX on aimed WL player every 0.2s (hold grip)."
            }),
            new ButtonInfo({
                buttonText: "WL Invincible Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            const cur = target.player.method("get_isInvincible").invoke();
                            target.player.method("set_isInvincible").invoke(!cur);
                            sendNotification((cur ? "Removed invincible from " : "Gave invincible to ") + target.id + "!", false);
                        } catch(e) { console.error("WL Invincible Gun:", e); }
                    }
                },
                toolTip: "Toggles invincibility on aimed WL player (hold grip + trigger)."
            }),
            new ButtonInfo({
                buttonText: "WL Money Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            target.player.method("RPC_AddPlayerMoney").invoke(9999);
                            sendNotification("Gave money to " + target.id + "!", false);
                        } catch(e) { console.error("WL Money Gun:", e); }
                    }
                },
                toolTip: "Gives 9999 money to aimed WL player (hold grip + trigger)."
            }),
            new ButtonInfo({
                buttonText: "WL Heal Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            try { target.player.method("set_healthLost").invoke(0); } catch(_) {}
                            try { target.player.method("set_isDie").invoke(false); } catch(_) {}
                            sendNotification("Healed " + target.id + "!", false);
                        } catch(e) { console.error("WL Heal Gun:", e); }
                    }
                },
                toolTip: "Fully heals aimed WL player (hold grip + trigger)."
            }),
            new ButtonInfo({
                buttonText: "WL Wanted Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const target = getWhitelistGunTarget(gunData, true, 10.0);
                            if (!target || !target.player) { sendNotification("No player there", false); return; }
                            if (target.blocked) { sendNotification("Not whitelisted: " + target.id, false); return; }
                            const cur = target.player.method("get_isWanted").invoke();
                            target.player.method("set_isWanted").invoke(!cur);
                            sendNotification((cur ? "Cleared wanted " : "Set wanted ") + target.id + "!", false);
                        } catch(e) { console.error("WL Wanted Gun:", e); }
                    }
                },
                toolTip: "Toggles wanted status on aimed WL player (hold grip + trigger)."
            }),
            new ButtonInfo({
                buttonText: "WL Give All Buff",
                method: () => {
                    try {
                        const buffIDs = [1, 2, 3, 5, 7]; 
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                            for (const buffID of buffIDs) {
                                try { p.method("RPC_ApplyBuff").invoke(buffID); } catch(_) {}
                            }
                            count++;
                        }
                        sendNotification("Gave all buffs to " + count + " WL players!", false);
                    } catch(e) { sendNotification("WL Give All Buff: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Gives all buffs (Speed, Pink, Damage, Scale, AntiGrav) to all WL players."
            }),
            new ButtonInfo({
                buttonText: "WL Add Money All",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                            try { p.method("RPC_AddPlayerMoney").invoke(9999); count++; } catch(_) {}
                        }
                        sendNotification("Gave money to " + count + " WL players!", false);
                    } catch(e) { sendNotification("WL Money All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Gives 9999 money to all WL players."
            }),
            new ButtonInfo({
                buttonText: "WL Set All Teams",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        let teamToggle = 1;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                            try { p.method("RPC_SetTeam").invoke(teamToggle); count++; } catch(_) {}
                        }
                        sendNotification("Set team for " + count + " WL players!", false);
                    } catch(e) { sendNotification("WL Set Teams: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all WL players to red team."
            }),
            new ButtonInfo({
                buttonText: "WL Clear Invincible",
                method: () => {
                    try {
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                            try { p.method("set_isInvincible").invoke(false); count++; } catch(_) {}
                        }
                        sendNotification("Removed invincible from " + count + " WL players!", false);
                    } catch(e) { sendNotification("WL Clear Invincible: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Removes invincibility from all WL players."
            }),
            new ButtonInfo({
                buttonText: "WL Spawn Bag Bomb All",
                method: () => {
                    try {
                        function randSBA(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
                        const bagIDs = ["item_backpack_large_clover","item_backpack_large_basketball","item_backpack_large_base"];
                        const playerDict = NetPlayer.field("playerIDToNetPlayer").value;
                        const vals = playerDict.method("get_Values").invoke();
                        const en = vals.method("GetEnumerator").invoke();
                        let count = 0;
                        while (en.method("MoveNext").invoke()) {
                            const p = en.method("get_Current").invoke();
                            if (!p || p.handle.isNull() || playerIsLocal(p)) continue;
                            if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                            const pos = getTransform(p).method("get_position").invoke();
                            try {
                                const bagResult = PrefabGen.method("SpawnItem", 4).invoke(
                                    Il2Cpp.string("item_prefab/" + bagIDs[randSBA(0, bagIDs.length - 1)]),
                                    pos, identityQuaternion, NULL
                                );
                                if (bagResult && !bagResult.isNull()) {
                                    const bagBackpack = bagResult.method("GetComponent", 1).inflate(BackpackItemClass).invoke();
                                    for (let i = 0; i < 10; i++) {
                                        try {
                                            const child = PrefabGen.method("SpawnItem", 4).invoke(
                                                Il2Cpp.string("item_prefab/" + itemIDs[randSBA(0, itemIDs.length - 1)]),
                                                pos, identityQuaternion, NULL
                                            );
                                            if (!child || child.isNull()) continue;
                                            if (bagBackpack && !bagBackpack.isNull()) {
                                                const childGBI = child.method("GetComponent", 1).inflate(GBIClass).invoke();
                                                if (childGBI && !childGBI.isNull()) {
                                                    try { childGBI.method("AddToBag").invoke(bagBackpack); } catch(_) {}
                                                }
                                            }
                                        } catch(_) {}
                                    }
                                    try { if (bagBackpack && !bagBackpack.isNull()) bagBackpack.method("Explode").invoke(); } catch(_) {}
                                }
                                count++;
                            } catch(_) {}
                        }
                        sendNotification("Bag bombed " + count + " WL players!", false);
                    } catch(e) { sendNotification("WL Bag Bomb All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Spawns an exploding bag near each WL player."
            }),
        ],

        [ 
            new ButtonInfo({
                buttonText: "Exit UX",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to main menu."
            }),
            
            new ButtonInfo({
                buttonText: "UX: ► Page 1",
                method: () => { currentCategory = 15; currentPage = 0; reloadMenu(); sendNotification("UX Page 1", false, 2); },
                isTogglable: false,
                toolTip: "Jump to Unity Explorer page 1 (Selection, Transform basics)."
            }),
            new ButtonInfo({
                buttonText: "UX: ► Page 2",
                method: () => { currentCategory = 15; currentPage = 1; reloadMenu(); sendNotification("UX Page 2", false, 2); },
                isTogglable: false,
                toolTip: "Jump to Unity Explorer page 2 (Info & Logging)."
            }),
            new ButtonInfo({
                buttonText: "UX: ► Page 3",
                method: () => { currentCategory = 15; currentPage = 2; reloadMenu(); sendNotification("UX Page 3", false, 2); },
                isTogglable: false,
                toolTip: "Jump to Unity Explorer page 3 (Mass & Physics)."
            }),
            new ButtonInfo({
                buttonText: "UX: ► Page 4",
                method: () => { currentCategory = 15; currentPage = 3; reloadMenu(); sendNotification("UX Page 4", false, 2); },
                isTogglable: false,
                toolTip: "Jump to Unity Explorer page 4 (Rendering & Color)."
            }),
            new ButtonInfo({
                buttonText: "UX: ► Page 5",
                method: () => { currentCategory = 15; currentPage = 4; reloadMenu(); sendNotification("UX Page 5", false, 2); },
                isTogglable: false,
                toolTip: "Jump to Unity Explorer page 5 (Parenting & Colliders)."
            }),
            new ButtonInfo({
                buttonText: "UX: ► Page 6",
                method: () => { currentCategory = 15; currentPage = 5; reloadMenu(); sendNotification("UX Page 6", false, 2); },
                isTogglable: false,
                toolTip: "Jump to Unity Explorer page 6 (Grabbable / Interaction)."
            }),
            new ButtonInfo({
                buttonText: "UX: ► Page 7",
                method: () => { currentCategory = 15; currentPage = 6; reloadMenu(); sendNotification("UX Page 7", false, 2); },
                isTogglable: false,
                toolTip: "Jump to Unity Explorer page 7 (Item Flags & Data)."
            }),
            new ButtonInfo({
                buttonText: "UX: ► Page 8",
                method: () => { currentCategory = 15; currentPage = 7; reloadMenu(); sendNotification("UX Page 8", false, 2); },
                isTogglable: false,
                toolTip: "Jump to Unity Explorer page 8 (Edible / Spawn / Scale)."
            }),
            new ButtonInfo({
                buttonText: "UX: ► Page 9",
                method: () => { currentCategory = 15; currentPage = 8; reloadMenu(); sendNotification("UX Page 9", false, 2); },
                isTogglable: false,
                toolTip: "Jump to Unity Explorer page 9 (Player Effects Gun)."
            }),
            new ButtonInfo({
                buttonText: "UX: ► Page 10",
                method: () => { currentCategory = 15; currentPage = 9; reloadMenu(); sendNotification("UX Page 10", false, 2); },
                isTogglable: false,
                toolTip: "Jump to Unity Explorer page 10 (Instantiate & Mob Spawn)."
            }),
            new ButtonInfo({
                buttonText: "UX: ► Last Page",
                method: () => {
                    const lastPage = Math.ceil(buttons[17].length / 8) - 1;
                    currentCategory = 15; currentPage = lastPage; reloadMenu();
                    sendNotification("UX Last Page (" + (lastPage + 1) + ")", false, 2);
                },
                isTogglable: false,
                toolTip: "Jump directly to the last page of the Unity Explorer."
            }),
            new ButtonInfo({
                buttonText: "Select Obj Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.4;
                        try {
                            const hitCol = ray.method("get_collider").invoke();
                            if (!hitCol || hitCol.isNull()) { sendNotification("Nothing hit", false); return; }
                            const go = hitCol.method("get_gameObject").invoke();
                            if (!go || go.isNull()) return;
                            uxSelectedObject = go;
                            uxSelectedName = go.method("get_name").invoke()?.content ?? "unnamed";
                            sendNotification("UX Selected: " + uxSelectedName, false, 4);
                        } catch(e) { console.error("[UX] Select:", e); }
                    }
                },
                toolTip: "Hold grip + pull trigger to select any object. Selected object is used by all other UX tools."
            }),
            new ButtonInfo({
                buttonText: "Inspect Object",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const pos  = tf ? uxVec3Str(tf.method("get_position").invoke()) : "?";
                        const rot  = tf ? uxVec3Str(tf.method("get_eulerAngles").invoke()) : "?";
                        const scl  = tf ? uxVec3Str(tf.method("get_localScale").invoke()) : "?";
                        const active = uxSelectedObject.method("get_activeSelf").invoke();
                        const layer  = uxSelectedObject.method("get_layer").invoke();
                        const tag    = uxSelectedObject.method("get_tag").invoke()?.content ?? "?";
                        const comps  = uxGetComponentNames(uxSelectedObject);
                        console.log("[UX] ═══════════════════════════════");
                        console.log("[UX] Name   : " + uxSelectedName);
                        console.log("[UX] Active : " + active);
                        console.log("[UX] Layer  : " + layer + "  Tag: " + tag);
                        console.log("[UX] Pos    : " + pos);
                        console.log("[UX] Rot    : " + rot);
                        console.log("[UX] Scale  : " + scl);
                        console.log("[UX] Components (" + comps.length + "): " + comps.join(", "));
                        console.log("[UX] ═══════════════════════════════");
                        sendNotification(uxSelectedName + " | " + pos + " | " + comps.length + " comps — see log", false, 6);
                    } catch(e) { sendNotification("Inspect: " + e, false); console.error("[UX] Inspect:", e); }
                },
                isTogglable: false,
                toolTip: "Logs full info (position, rotation, scale, components) of selected object to Frida console."
            }),
            new ButtonInfo({
                buttonText: "Teleport to Obj",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const tf = uxGetTransform(uxSelectedObject);
                        if (!tf) return;
                        const pos = tf.method("get_position").invoke();
                        player.method("RPC_Teleport").invoke(pos);
                        sendNotification("Teleported to " + uxSelectedName, false);
                    } catch(e) { sendNotification("TP to obj: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Teleports you to the selected object's position."
            }),
            new ButtonInfo({
                buttonText: "Obj to Me",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const myPos = getTransform(player).method("get_position").invoke();
                        uxGetTransform(uxSelectedObject).method("set_position").invoke(myPos);
                        sendNotification("Moved " + uxSelectedName + " to you", false);
                    } catch(e) { sendNotification("Obj to me: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Moves the selected object to your position."
            }),
            new ButtonInfo({
                buttonText: "Freeze Obj",
                isTogglable: true,
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const UnityEngine = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image;
                        const RBClass = UnityEngine.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponent", 1).inflate(RBClass).invoke();
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody on " + uxSelectedName, false); return; }
                        const cur = rb.method("get_isKinematic").invoke();
                        rb.method("set_isKinematic").invoke(!cur);
                        sendNotification("Freeze " + uxSelectedName + ": " + !cur, false);
                    } catch(e) { sendNotification("Freeze: " + e, false); }
                },
                toolTip: "Toggles isKinematic on the selected object's Rigidbody (freezes/unfreezes physics)."
            }),
            new ButtonInfo({
                buttonText: "Toggle Active",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const cur = uxSelectedObject.method("get_activeSelf").invoke();
                        uxSelectedObject.method("SetActive").invoke(!cur);
                        sendNotification(uxSelectedName + " active: " + !cur, false);
                    } catch(e) { sendNotification("Toggle Active: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Toggles SetActive on the selected object (hides/shows it)."
            }),
            new ButtonInfo({
                buttonText: "Despawn Obj",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        let despawned = false;
                        
                        try {
                            const gbo = uxSelectedObject.method("GetComponentInParent", 0).inflate(GBOClass).invoke();
                            if (gbo && !gbo.isNull()) {
                                const netObj = gbo.method("get_Object").invoke();
                                if (netObj && !netObj.isNull()) {
                                    let runner: any = null;
                                    try { runner = getSfxCurrentRunner(); } catch(_) {}
                                    if (runner && !runner.isNull()) { runner.method("Despawn").invoke(netObj); despawned = true; }
                                }
                            }
                        } catch(_) {}
                        
                        if (!despawned) {
                            try {
                                const NOClass = Il2Cpp.domain.assembly("Fusion.Runtime").image.class("Fusion.NetworkObject");
                                const no = uxSelectedObject.method("GetComponentInParent", 0).inflate(NOClass).invoke();
                                if (no && !no.isNull()) {
                                    let runner: any = null;
                                    try { runner = getSfxCurrentRunner(); } catch(_) {}
                                    if (runner && !runner.isNull()) { runner.method("Despawn").invoke(no); despawned = true; }
                                }
                            } catch(_) {}
                        }
                        if (despawned) {
                            sendNotification("Despawned " + uxSelectedName, false);
                            uxSelectedObject = null; uxSelectedName = "none";
                        } else {
                            
                            Destroy(uxSelectedObject);
                            sendNotification("Destroyed (local) " + uxSelectedName, false);
                            uxSelectedObject = null; uxSelectedName = "none";
                        }
                    } catch(e) { sendNotification("Despawn: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Despawns (network removes) the selected object, or destroys it locally if no network object."
            }),
            new ButtonInfo({
                buttonText: "Scale Obj +25%",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const s = tf.method("get_localScale").invoke();
                        const nx = (s.field("x").value as number) * 1.25;
                        const ny = (s.field("y").value as number) * 1.25;
                        const nz = (s.field("z").value as number) * 1.25;
                        const newScale = Vector3.method("op_Multiply").invoke(s, 1.25);
                        tf.method("set_localScale").invoke(newScale);
                        sendNotification(uxSelectedName + " scaled up", false);
                    } catch(e) { sendNotification("Scale+: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Scales the selected object up by 25%."
            }),
            new ButtonInfo({
                buttonText: "Scale Obj -25%",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const s = tf.method("get_localScale").invoke();
                        const newScale = Vector3.method("op_Multiply").invoke(s, 0.75);
                        tf.method("set_localScale").invoke(newScale);
                        sendNotification(uxSelectedName + " scaled down", false);
                    } catch(e) { sendNotification("Scale-: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Scales the selected object down by 25%."
            }),
            new ButtonInfo({
                buttonText: "Reset Obj Scale",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const one = Vector3.method("get_one").invoke();
                        tf.method("set_localScale").invoke(one);
                        sendNotification(uxSelectedName + " scale reset", false);
                    } catch(e) { sendNotification("Scale reset: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets selected object scale to (1,1,1)."
            }),
            new ButtonInfo({
                buttonText: "Rotate Obj 90Y",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const cur = tf.method("get_eulerAngles").invoke();
                        const newY = ((cur.field("y").value as number) + 90) % 360;
                        const curX = cur.field("x").value as number;
                        const curZ = cur.field("z").value as number;
                        tf.method("set_eulerAngles").invoke([curX, newY, curZ]);
                        sendNotification(uxSelectedName + " rotated 90° Y", false);
                    } catch(e) { sendNotification("Rotate: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Rotates selected object 90 degrees on Y axis."
            }),
            new ButtonInfo({
                buttonText: "Lock Obj Pos",
                isTogglable: true,
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const UnityEngine = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image;
                        const RBClass = UnityEngine.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponent", 1).inflate(RBClass).invoke();
                        if (rb && !rb.isNull()) {
                            rb.method("set_isKinematic").invoke(true);
                            rb.method("set_useGravity").invoke(false);
                        }
                        const tf = uxGetTransform(uxSelectedObject);
                        
                        tf.method("SetParent", 2).invoke(NULL, true);
                        sendNotification(uxSelectedName + " position locked", false);
                    } catch(e) { sendNotification("Lock pos: " + e, false); }
                },
                toolTip: "Locks selected object's position (kinematic, no gravity, detaches from parent)."
            }),
            new ButtonInfo({
                buttonText: "Print Fields",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const CompClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Component");
                        const comps = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(CompClass).invoke(false);
                        const len = comps ? comps.length : 0;
                        console.log("[UX-Fields] Object: " + uxSelectedName + " ── " + len + " components");
                        for (let i = 0; i < Math.min(len, 20); i++) {
                            try {
                                const c = comps.method("get_Item").invoke(i);
                                const typeName = c.method("GetType").invoke().method("get_Name").invoke()?.content ?? "?";
                                console.log("[UX-Fields]  ┌ " + typeName);
                                try {
                                    const il2Type = c.class;
                                    if (il2Type) {
                                        for (const field of il2Type.fields) {
                                            try {
                                                const val = field.withHolder(c).value;
                                                console.log("[UX-Fields]  │  " + field.name + " = " + val);
                                            } catch(_) {
                                                console.log("[UX-Fields]  │  " + field.name + " = <unreadable>");
                                            }
                                        }
                                    }
                                } catch(_) {}
                                console.log("[UX-Fields]  └─────");
                            } catch(_) {}
                        }
                        sendNotification("Fields dumped to log (" + Math.min(len, 20) + " comps)", false, 4);
                    } catch(e) { sendNotification("Print Fields: " + e, false); console.error("[UX] Fields:", e); }
                },
                isTogglable: false,
                toolTip: "Dumps all Il2Cpp fields of every component on selected object to Frida log."
            }),
            new ButtonInfo({
                buttonText: "Print Methods",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const CompClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Component");
                        const comps = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(CompClass).invoke(false);
                        const len = comps ? comps.length : 0;
                        console.log("[UX-Methods] Object: " + uxSelectedName);
                        for (let i = 0; i < Math.min(len, 10); i++) {
                            try {
                                const c = comps.method("get_Item").invoke(i);
                                const typeName = c.method("GetType").invoke().method("get_Name").invoke()?.content ?? "?";
                                console.log("[UX-Methods]  ┌ " + typeName);
                                try {
                                    const il2Type = c.class;
                                    if (il2Type) {
                                        for (const method of il2Type.methods) {
                                            console.log("[UX-Methods]  │  " + method.name);
                                        }
                                    }
                                } catch(_) {}
                                console.log("[UX-Methods]  └─────");
                            } catch(_) {}
                        }
                        sendNotification("Methods dumped to log", false, 4);
                    } catch(e) { sendNotification("Print Methods: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Dumps all method names on every component to Frida log."
            }),
            new ButtonInfo({
                buttonText: "Print Children",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        if (!tf) return;
                        function printChildren(t: any, depth: number) {
                            const count = t.method("get_childCount").invoke() as number;
                            for (let i = 0; i < Math.min(count, 64); i++) {
                                try {
                                    const child = t.method("GetChild").invoke(i);
                                    const name = child.method("get_gameObject").invoke().method("get_name").invoke()?.content ?? "?";
                                    console.log("[UX-Children]" + "  ".repeat(depth) + "├ " + name);
                                    if (depth < 4) printChildren(child, depth + 1);
                                } catch(_) {}
                            }
                        }
                        console.log("[UX-Children] Root: " + uxSelectedName);
                        printChildren(tf, 1);
                        sendNotification("Children dumped to log", false, 4);
                    } catch(e) { sendNotification("Print Children: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Dumps the full child hierarchy of the selected object to Frida log (4 levels deep)."
            }),

            
            
            

            
            new ButtonInfo({
                buttonText: "UX: Select Parent",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        if (!tf) return;
                        const parentTF = tf.method("get_parent").invoke();
                        if (!parentTF || parentTF.isNull()) { sendNotification("No parent", false); return; }
                        uxSelectedObject = parentTF.method("get_gameObject").invoke();
                        uxSelectedName = uxSelectedObject.method("get_name").invoke()?.content ?? "parent";
                        sendNotification("UX → Parent: " + uxSelectedName, false, 3);
                    } catch(e) { sendNotification("Select Parent: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Re-selects the parent GameObject of the current selection."
            }),
            new ButtonInfo({
                buttonText: "UX: Select Child[0]",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        if (!tf) return;
                        const count = tf.method("get_childCount").invoke() as number;
                        if (count === 0) { sendNotification("No children", false); return; }
                        const child = tf.method("GetChild").invoke(0);
                        uxSelectedObject = child.method("get_gameObject").invoke();
                        uxSelectedName = uxSelectedObject.method("get_name").invoke()?.content ?? "child";
                        sendNotification("UX → Child[0]: " + uxSelectedName, false, 3);
                    } catch(e) { sendNotification("Select Child: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Navigates into the first child of the current selection."
            }),
            new ButtonInfo({
                buttonText: "UX: Show Selected",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("UX: nothing selected", false, 4); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const pos = tf ? uxVec3Str(tf.method("get_position").invoke()) : "?";
                        const comps = uxGetComponentNames(uxSelectedObject);
                        sendNotification("SEL: " + uxSelectedName + "\n" + pos + "\n" + comps.slice(0,4).join(", "), false, 6);
                    } catch(e) { sendNotification("Show: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Re-displays the current selection name and position as a notification."
            }),
            new ButtonInfo({
                buttonText: "UX: Get Full Path",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const segments: string[] = [];
                        let tf: any = uxGetTransform(uxSelectedObject);
                        let guard = 0;
                        
                        while (tf && !tf.isNull() && guard < 64) {
                            guard++;
                            try {
                                const go = tf.method("get_gameObject").invoke();
                                const n = (go && !go.isNull()) ? (go.method("get_name").invoke()?.content ?? "?") : "?";
                                segments.unshift(n);
                            } catch(_) { segments.unshift("?"); }
                            try {
                                const p = tf.method("get_parent").invoke();
                                tf = (p && !p.isNull()) ? p : null;
                            } catch(_) { tf = null; }
                        }
                        const path = "/" + segments.join("/");
                        console.log("[UX] Full path (" + segments.length + " levels): " + path);
                        sendNotification(path, false, 9);
                    } catch(e) { sendNotification("Path: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Walks the full transform hierarchy to root and displays the complete scene path."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Move +X (1m)",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const p = tf.method("get_position").invoke();
                        p.field("x").value = (p.field("x").value as number) + 1.0;
                        tf.method("set_position").invoke(p);
                        sendNotification(uxSelectedName + " +X", false, 2);
                    } catch(e) { sendNotification("Move +X: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Nudges selected object +1 unit on the X axis."
            }),
            new ButtonInfo({
                buttonText: "UX: Move -X (1m)",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const p = tf.method("get_position").invoke();
                        p.field("x").value = (p.field("x").value as number) - 1.0;
                        tf.method("set_position").invoke(p);
                        sendNotification(uxSelectedName + " -X", false, 2);
                    } catch(e) { sendNotification("Move -X: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Nudges selected object -1 unit on the X axis."
            }),
            new ButtonInfo({
                buttonText: "UX: Move +Y (1m)",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const p = tf.method("get_position").invoke();
                        p.field("y").value = (p.field("y").value as number) + 1.0;
                        tf.method("set_position").invoke(p);
                        sendNotification(uxSelectedName + " +Y", false, 2);
                    } catch(e) { sendNotification("Move +Y: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Nudges selected object +1 unit up (Y axis)."
            }),
            new ButtonInfo({
                buttonText: "UX: Move -Y (1m)",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const p = tf.method("get_position").invoke();
                        p.field("y").value = (p.field("y").value as number) - 1.0;
                        tf.method("set_position").invoke(p);
                        sendNotification(uxSelectedName + " -Y", false, 2);
                    } catch(e) { sendNotification("Move -Y: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Nudges selected object -1 unit down (Y axis)."
            }),
            new ButtonInfo({
                buttonText: "UX: Move +Z (1m)",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const p = tf.method("get_position").invoke();
                        p.field("z").value = (p.field("z").value as number) + 1.0;
                        tf.method("set_position").invoke(p);
                        sendNotification(uxSelectedName + " +Z", false, 2);
                    } catch(e) { sendNotification("Move +Z: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Nudges selected object +1 unit on the Z axis."
            }),
            new ButtonInfo({
                buttonText: "UX: Move -Z (1m)",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const p = tf.method("get_position").invoke();
                        p.field("z").value = (p.field("z").value as number) - 1.0;
                        tf.method("set_position").invoke(p);
                        sendNotification(uxSelectedName + " -Z", false, 2);
                    } catch(e) { sendNotification("Move -Z: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Nudges selected object -1 unit on the Z axis."
            }),
            new ButtonInfo({
                buttonText: "UX: Snap to Ground",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const pos = tf.method("get_position").invoke();
                        
                        const downDir = Vector3.method("get_down").invoke();
                        const hits = Physics.method("RaycastAll", 3).invoke(pos, downDir, 100.0);
                        if (!hits || hits.isNull()) { sendNotification("No ground found", false); return; }
                        const len = hits.length;
                        let bestY = pos.field("y").value as number;
                        let found = false;
                        for (let i = 0; i < len; i++) {
                            try {
                                const hit = hits.method("get_Item").invoke(i);
                                const hitGO = hit.field("collider").value.method("get_gameObject").invoke();
                                if (hitGO.method("GetInstanceID").invoke() === uxSelectedObject.method("GetInstanceID").invoke()) continue;
                                const hitY = hit.field("point").value.field("y").value as number;
                                if (!found || hitY > bestY) { bestY = hitY; found = true; }
                            } catch(_) {}
                        }
                        if (found) {
                            pos.field("y").value = bestY;
                            tf.method("set_position").invoke(pos);
                            sendNotification(uxSelectedName + " snapped to ground", false);
                        } else {
                            sendNotification("No ground below", false);
                        }
                    } catch(e) { sendNotification("Snap: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Raycasts downward and places selected object on the nearest surface below it."
            }),
            new ButtonInfo({
                buttonText: "UX: Save Pos",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        (globalThis as any)._uxSavedPos = tf.method("get_position").invoke();
                        (globalThis as any)._uxSavedRot = tf.method("get_rotation").invoke();
                        const pos = uxVec3Str((globalThis as any)._uxSavedPos);
                        console.log("[UX] Saved pos: " + pos + " for " + uxSelectedName);
                        sendNotification("Pos saved: " + pos, false, 4);
                    } catch(e) { sendNotification("Save Pos: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Saves the selected object's current position and rotation into a slot."
            }),
            new ButtonInfo({
                buttonText: "UX: Restore Pos",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    if (!(globalThis as any)._uxSavedPos) { sendNotification("No pos saved", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        tf.method("set_position").invoke((globalThis as any)._uxSavedPos);
                        tf.method("set_rotation").invoke((globalThis as any)._uxSavedRot);
                        sendNotification("Pos restored on " + uxSelectedName, false);
                    } catch(e) { sendNotification("Restore Pos: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Moves the selected object back to the last saved position/rotation."
            }),
            new ButtonInfo({
                buttonText: "UX: Align to Player",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const myPos = getTransform(player).method("get_position").invoke();
                        const tf = uxGetTransform(uxSelectedObject);
                        
                        const myFwd = getTransform(player).method("get_forward").invoke();
                        const nx = (myPos.field("x").value as number) + (myFwd.field("x").value as number) * 2.0;
                        const ny = myPos.field("y").value;
                        const nz = (myPos.field("z").value as number) + (myFwd.field("z").value as number) * 2.0;
                        myPos.field("x").value = nx;
                        myPos.field("y").value = ny;
                        myPos.field("z").value = nz;
                        tf.method("set_position").invoke(myPos);
                        sendNotification(uxSelectedName + " aligned to player", false);
                    } catch(e) { sendNotification("Align: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Moves selected object 2m in front of you at your height."
            }),
            new ButtonInfo({
                buttonText: "UX: Mirror X",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const p = tf.method("get_position").invoke();
                        p.field("x").value = -(p.field("x").value as number);
                        tf.method("set_position").invoke(p);
                        sendNotification(uxSelectedName + " mirrored X", false);
                    } catch(e) { sendNotification("Mirror X: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Mirrors the selected object's X position across X=0."
            }),
            new ButtonInfo({
                buttonText: "UX: Mirror Z",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const p = tf.method("get_position").invoke();
                        p.field("z").value = -(p.field("z").value as number);
                        tf.method("set_position").invoke(p);
                        sendNotification(uxSelectedName + " mirrored Z", false);
                    } catch(e) { sendNotification("Mirror Z: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Mirrors the selected object's Z position across Z=0."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Rotate +X 90",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const e = tf.method("get_eulerAngles").invoke();
                        e.field("x").value = ((e.field("x").value as number) + 90) % 360;
                        tf.method("set_eulerAngles").invoke(e);
                        sendNotification(uxSelectedName + " +X 90°", false, 2);
                    } catch(e2) { sendNotification("Rot +X: " + e2, false); }
                },
                isTogglable: false,
                toolTip: "Rotates selected object 90° on X axis."
            }),
            new ButtonInfo({
                buttonText: "UX: Rotate +Z 90",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const e = tf.method("get_eulerAngles").invoke();
                        e.field("z").value = ((e.field("z").value as number) + 90) % 360;
                        tf.method("set_eulerAngles").invoke(e);
                        sendNotification(uxSelectedName + " +Z 90°", false, 2);
                    } catch(e2) { sendNotification("Rot +Z: " + e2, false); }
                },
                isTogglable: false,
                toolTip: "Rotates selected object 90° on Z axis."
            }),
            new ButtonInfo({
                buttonText: "UX: Reset Rotation",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const identity = Quaternion.method("get_identity").invoke();
                        tf.method("set_rotation").invoke(identity);
                        sendNotification(uxSelectedName + " rotation reset", false);
                    } catch(e) { sendNotification("Reset Rot: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets selected object rotation to identity (0,0,0)."
            }),
            new ButtonInfo({
                buttonText: "UX: Face Player",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const tf = uxGetTransform(uxSelectedObject);
                        const objPos = tf.method("get_position").invoke();
                        const playerPos = getTransform(player).method("get_position").invoke();
                        
                        tf.method("LookAt", 1).invoke(playerPos);
                        sendNotification(uxSelectedName + " now faces you", false);
                    } catch(e) { sendNotification("Face Player: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Rotates selected object to face your position."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Launch Up",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const UnityEngine = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image;
                        const RBClass = UnityEngine.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponent", 1).inflate(RBClass).invoke();
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody on " + uxSelectedName, false); return; }
                        rb.method("set_isKinematic").invoke(false);
                        rb.method("set_useGravity").invoke(true);
                        const upForce = Vector3.method("op_Multiply").invoke(Vector3.method("get_up").invoke(), 1200.0);
                        rb.method("AddForce", 1).invoke(upForce);
                        sendNotification(uxSelectedName + " launched!", false);
                    } catch(e) { sendNotification("Launch: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Adds a large upward force to the selected object's Rigidbody."
            }),
            new ButtonInfo({
                buttonText: "UX: Zero Velocity",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const UnityEngine = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image;
                        const RBClass = UnityEngine.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponent", 1).inflate(RBClass).invoke();
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        const zero = Vector3.method("get_zero").invoke();
                        rb.method("set_velocity").invoke(zero);
                        rb.method("set_angularVelocity").invoke(zero);
                        sendNotification(uxSelectedName + " velocity zeroed", false);
                    } catch(e) { sendNotification("Zero Vel: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets velocity and angularVelocity to zero on the selected object's Rigidbody."
            }),
            new ButtonInfo({
                buttonText: "UX: Enable Gravity",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const UnityEngine = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image;
                        const RBClass = UnityEngine.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponent", 1).inflate(RBClass).invoke();
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_useGravity").invoke(true);
                        rb.method("set_isKinematic").invoke(false);
                        sendNotification(uxSelectedName + " gravity ON", false);
                    } catch(e) { sendNotification("Gravity ON: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Enables gravity and disables kinematic on selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Disable Gravity",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const UnityEngine = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image;
                        const RBClass = UnityEngine.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponent", 1).inflate(RBClass).invoke();
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_useGravity").invoke(false);
                        sendNotification(uxSelectedName + " gravity OFF", false);
                    } catch(e) { sendNotification("Gravity OFF: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Disables gravity on selected object's Rigidbody."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Toggle Renderer",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(RendClass).invoke(false);
                        if (!rends || rends.isNull()) { sendNotification("No renderers", false); return; }
                        const len = rends.length;
                        let anyEnabled = false;
                        for (let i = 0; i < len; i++) {
                            try { if (rends.method("get_Item").invoke(i).method("get_enabled").invoke()) { anyEnabled = true; break; } } catch(_) {}
                        }
                        for (let i = 0; i < len; i++) {
                            try { rends.method("get_Item").invoke(i).method("set_enabled").invoke(!anyEnabled); } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " renderers: " + !anyEnabled, false);
                    } catch(e) { sendNotification("Toggle Renderer: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Toggles all Renderer components on the selected object and its children."
            }),
            new ButtonInfo({
                buttonText: "UX: Color Red",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(RendClass).invoke(false);
                        const len = rends ? rends.length : 0;
                        const red = [1,0,0,1];
                        for (let i = 0; i < len; i++) {
                            try { rends.method("get_Item").invoke(i).method("get_material").invoke().method("set_color").invoke(red); } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " → red", false);
                    } catch(e) { sendNotification("Color Red: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all materials on the selected object to red."
            }),
            new ButtonInfo({
                buttonText: "UX: Color Blue",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(RendClass).invoke(false);
                        const len = rends ? rends.length : 0;
                        const blue = [0,0,1,1];
                        for (let i = 0; i < len; i++) {
                            try { rends.method("get_Item").invoke(i).method("get_material").invoke().method("set_color").invoke(blue); } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " → blue", false);
                    } catch(e) { sendNotification("Color Blue: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all materials on the selected object to blue."
            }),
            new ButtonInfo({
                buttonText: "UX: Color Green",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(RendClass).invoke(false);
                        const len = rends ? rends.length : 0;
                        const green = [0,1,0,1];
                        for (let i = 0; i < len; i++) {
                            try { rends.method("get_Item").invoke(i).method("get_material").invoke().method("set_color").invoke(green); } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " → green", false);
                    } catch(e) { sendNotification("Color Green: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all materials on the selected object to green."
            }),
            new ButtonInfo({
                buttonText: "UX: Color White",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(RendClass).invoke(false);
                        const len = rends ? rends.length : 0;
                        const white = [1,1,1,1];
                        for (let i = 0; i < len; i++) {
                            try { rends.method("get_Item").invoke(i).method("get_material").invoke().method("set_color").invoke(white); } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " → white", false);
                    } catch(e) { sendNotification("Color White: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets all material colors on the selected object to white."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Attach to Hand",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const handTF = player.field("handRight").value;
                        if (!handTF || handTF.isNull()) { sendNotification("No right hand transform", false); return; }
                        const tf = uxGetTransform(uxSelectedObject);
                        tf.method("SetParent", 2).invoke(handTF, true);
                        
                        try {
                            const UnityEngine = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image;
                            const RBClass = UnityEngine.class("UnityEngine.Rigidbody");
                            const rb = uxSelectedObject.method("GetComponent", 1).inflate(RBClass).invoke();
                            if (rb && !rb.isNull()) rb.method("set_isKinematic").invoke(true);
                        } catch(_) {}
                        sendNotification(uxSelectedName + " attached to hand", false);
                    } catch(e) { sendNotification("Attach: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Parents selected object to your right hand transform."
            }),
            new ButtonInfo({
                buttonText: "UX: Detach Parent",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        tf.method("SetParent", 2).invoke(NULL, true);
                        sendNotification(uxSelectedName + " detached", false);
                    } catch(e) { sendNotification("Detach: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Detaches selected object from its parent (SetParent null), keeping world position."
            }),
            new ButtonInfo({
                buttonText: "UX: Parent to Obj Gun",
                isTogglable: true,
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("Select an object first", false); return; }
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const hitCol = ray.method("get_collider").invoke();
                            if (!hitCol || hitCol.isNull()) return;
                            const targetGO = hitCol.method("get_gameObject").invoke();
                            const targetTF = uxGetTransform(targetGO);
                            const tf = uxGetTransform(uxSelectedObject);
                            tf.method("SetParent", 2).invoke(targetTF, true);
                            const targetName = targetGO.method("get_name").invoke()?.content ?? "?";
                            sendNotification(uxSelectedName + " parented to " + targetName, false);
                        } catch(e) { sendNotification("Parent to: " + e, false); }
                    }
                },
                toolTip: "Hold grip + aim at an object + trigger to parent the selected object to it."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Toggle Colliders",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const ColClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Collider");
                        const cols = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(ColClass).invoke(false);
                        const len = cols ? cols.length : 0;
                        if (len === 0) { sendNotification("No colliders", false); return; }
                        let anyEnabled = false;
                        for (let i = 0; i < len; i++) {
                            try { if (cols.method("get_Item").invoke(i).method("get_enabled").invoke()) { anyEnabled = true; break; } } catch(_) {}
                        }
                        for (let i = 0; i < len; i++) {
                            try { cols.method("get_Item").invoke(i).method("set_enabled").invoke(!anyEnabled); } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " colliders: " + !anyEnabled, false);
                    } catch(e) { sendNotification("Toggle Colliders: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Toggles all Collider components on the selected object and its children."
            }),
            new ButtonInfo({
                buttonText: "UX: Make Trigger",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const ColClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Collider");
                        const cols = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(ColClass).invoke(false);
                        const len = cols ? cols.length : 0;
                        for (let i = 0; i < len; i++) {
                            try { cols.method("get_Item").invoke(i).method("set_isTrigger").invoke(true); } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " → trigger", false);
                    } catch(e) { sendNotification("Make Trigger: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets isTrigger=true on all colliders (walk through the object)."
            }),
            new ButtonInfo({
                buttonText: "UX: Make Solid",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const ColClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Collider");
                        const cols = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(ColClass).invoke(false);
                        const len = cols ? cols.length : 0;
                        for (let i = 0; i < len; i++) {
                            try { cols.method("get_Item").invoke(i).method("set_isTrigger").invoke(false); } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " → solid", false);
                    } catch(e) { sendNotification("Make Solid: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets isTrigger=false on all colliders (restores collision)."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Log Layer+Tag",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const layer = uxSelectedObject.method("get_layer").invoke() as number;
                        const tag   = uxSelectedObject.method("get_tag").invoke()?.content ?? "?";
                        const id    = uxSelectedObject.method("GetInstanceID").invoke();
                        console.log("[UX] " + uxSelectedName + " | layer=" + layer + " tag=" + tag + " instanceID=" + id);
                        sendNotification("Layer=" + layer + "  Tag=" + tag + "  ID=" + id, false, 6);
                    } catch(e) { sendNotification("Layer+Tag: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Logs the layer number, tag, and instanceID of the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Count All Objects",
                method: () => {
                    try {
                        const GOClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.GameObject");
                        const allGOs = Object.method("FindObjectsByType", 1).inflate(GOClass).invoke(0);
                        const len = allGOs ? allGOs.length : 0;
                        console.log("[UX] Total GameObjects in scene: " + len);
                        sendNotification("GameObjects in scene: " + len, false, 5);
                    } catch(e) { sendNotification("Count: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Counts and logs all active GameObjects currently in the scene."
            }),
            new ButtonInfo({
                buttonText: "UX: Dump All Near",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const myPos = getTransform(player).method("get_position").invoke();
                        const GOClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.GameObject");
                        const allGOs = Object.method("FindObjectsByType", 1).inflate(GOClass).invoke(0);
                        const len = allGOs ? allGOs.length : 0;
                        let count = 0;
                        console.log("[UX] Objects within 10m:");
                        for (let i = 0; i < len; i++) {
                            try {
                                const go = allGOs.method("get_Item").invoke(i);
                                const tf = uxGetTransform(go);
                                if (!tf) continue;
                                const pos = tf.method("get_position").invoke();
                                const dist = Vector3.method("Distance").invoke(myPos, pos) as number;
                                if (dist <= 10.0) {
                                    const name = go.method("get_name").invoke()?.content ?? "?";
                                    console.log("[UX]   [" + dist.toFixed(1) + "m] " + name);
                                    count++;
                                }
                            } catch(_) {}
                        }
                        sendNotification(count + " objects within 10m — see log", false, 4);
                    } catch(e) { sendNotification("Dump Near: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Logs the name and distance of every GameObject within 10m of you to the Frida console."
            }),
            new ButtonInfo({
                buttonText: "UX: Full Deep Dump",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        console.log("[UX-DeepDump] ══════════════════════════════════════════");
                        console.log("[UX-DeepDump] Object: " + uxSelectedName);
                        const tf = uxGetTransform(uxSelectedObject);
                        if (tf) {
                            console.log("[UX-DeepDump] Pos   : " + uxVec3Str(tf.method("get_position").invoke()));
                            console.log("[UX-DeepDump] Rot   : " + uxVec3Str(tf.method("get_eulerAngles").invoke()));
                            console.log("[UX-DeepDump] Scale : " + uxVec3Str(tf.method("get_localScale").invoke()));
                        }
                        console.log("[UX-DeepDump] Layer : " + uxSelectedObject.method("get_layer").invoke());
                        console.log("[UX-DeepDump] Tag   : " + (uxSelectedObject.method("get_tag").invoke()?.content ?? "?"));
                        console.log("[UX-DeepDump] Active: " + uxSelectedObject.method("get_activeSelf").invoke());
                        
                        const CompClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Component");
                        const comps = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(CompClass).invoke(false);
                        const cLen = comps ? comps.length : 0;
                        for (let i = 0; i < Math.min(cLen, 30); i++) {
                            try {
                                const c = comps.method("get_Item").invoke(i);
                                const typeName = c.method("GetType").invoke().method("get_Name").invoke()?.content ?? "?";
                                console.log("[UX-DeepDump]  ┌─ " + typeName);
                                try {
                                    for (const field of c.class.fields) {
                                        try { console.log("[UX-DeepDump]  │  ." + field.name + " = " + field.withHolder(c).value); }
                                        catch(_) { console.log("[UX-DeepDump]  │  ." + field.name + " = <err>"); }
                                    }
                                } catch(_) {}
                                console.log("[UX-DeepDump]  └──────────────────────────");
                            } catch(_) {}
                        }
                        console.log("[UX-DeepDump] ══════════════════════════════════════════");
                        sendNotification("Full dump written to log", false, 4);
                    } catch(e) { sendNotification("DeepDump: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Full deep dump: position, rotation, scale, all component fields to Frida log."
            }),

            
            
            

            
            

            
            new ButtonInfo({
                buttonText: "UX: Get Mass",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody on " + uxSelectedName, false); return; }
                        const mass = rb.method("get_mass").invoke() as number;
                        const drag = rb.method("get_linearDamping").invoke() as number;
                        const angDrag = rb.method("get_angularDamping").invoke() as number;
                        const kinematic = rb.method("get_isKinematic").invoke();
                        const gravity = rb.method("get_useGravity").invoke();
                        console.log("[UX] " + uxSelectedName + " | mass=" + mass.toFixed(3) + " drag=" + drag.toFixed(3) + " angDrag=" + angDrag.toFixed(3) + " kinematic=" + kinematic + " gravity=" + gravity);
                        sendNotification("mass=" + mass.toFixed(2) + " drag=" + drag.toFixed(2) + " kin=" + kinematic, false, 6);
                    } catch(e) { sendNotification("Get Mass: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Reads and displays mass, drag, angularDrag, kinematic and gravity of the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Mass = 0.1",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_mass").invoke(0.1);
                        sendNotification(uxSelectedName + " mass = 0.1 (feather)", false);
                    } catch(e) { sendNotification("Set Mass: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets Rigidbody mass to 0.1 (feather-light, flies on any force)."
            }),
            new ButtonInfo({
                buttonText: "UX: Mass = 1",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_mass").invoke(1.0);
                        sendNotification(uxSelectedName + " mass = 1 (default)", false);
                    } catch(e) { sendNotification("Set Mass: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets Rigidbody mass to 1 (Unity default)."
            }),
            new ButtonInfo({
                buttonText: "UX: Mass = 100",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_mass").invoke(100.0);
                        sendNotification(uxSelectedName + " mass = 100 (boulder)", false);
                    } catch(e) { sendNotification("Set Mass: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets Rigidbody mass to 100 (extremely heavy)."
            }),
            new ButtonInfo({
                buttonText: "UX: Drag = 0",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_linearDamping").invoke(0.0);
                        rb.method("set_angularDamping").invoke(0.0);
                        sendNotification(uxSelectedName + " drag = 0 (no air resistance)", false);
                    } catch(e) { sendNotification("Drag=0: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets linear and angular drag to 0 (object glides forever)."
            }),
            new ButtonInfo({
                buttonText: "UX: Drag = 10",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_linearDamping").invoke(10.0);
                        rb.method("set_angularDamping").invoke(10.0);
                        sendNotification(uxSelectedName + " drag = 10 (floaty)", false);
                    } catch(e) { sendNotification("Drag=10: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets drag to 10 — object floats and slows rapidly."
            }),
            new ButtonInfo({
                buttonText: "UX: Freeze Position",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        
                        rb.method("set_constraints").invoke(14);
                        sendNotification(uxSelectedName + " position frozen", false);
                    } catch(e) { sendNotification("Freeze Pos: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets RigidbodyConstraints.FreezePosition (object stays put but can still rotate)."
            }),
            new ButtonInfo({
                buttonText: "UX: Freeze Rotation",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        
                        rb.method("set_constraints").invoke(112);
                        sendNotification(uxSelectedName + " rotation frozen", false);
                    } catch(e) { sendNotification("Freeze Rot: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets RigidbodyConstraints.FreezeRotation (stops spinning)."
            }),
            new ButtonInfo({
                buttonText: "UX: Freeze All",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        
                        rb.method("set_constraints").invoke(126);
                        sendNotification(uxSelectedName + " ALL physics frozen", false);
                    } catch(e) { sendNotification("Freeze All: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets RigidbodyConstraints.FreezeAll — completely locks the object in place."
            }),
            new ButtonInfo({
                buttonText: "UX: Unfreeze All",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        
                        rb.method("set_constraints").invoke(0);
                        rb.method("set_isKinematic").invoke(false);
                        sendNotification(uxSelectedName + " fully unfrozen", false);
                    } catch(e) { sendNotification("Unfreeze: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Clears all RigidbodyConstraints and disables kinematic."
            }),
            new ButtonInfo({
                buttonText: "UX: Add Torque",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_isKinematic").invoke(false);
                        const torque = Vector3.method("op_Multiply").invoke(Vector3.method("get_up").invoke(), 500.0);
                        rb.method("AddTorque", 2).invoke(torque, 0);
                        sendNotification(uxSelectedName + " spinning!", false);
                    } catch(e) { sendNotification("Torque: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Adds a large upward torque to spin the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Explosion Here",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_isKinematic").invoke(false);
                        const pos = uxGetTransform(uxSelectedObject).method("get_position").invoke();
                        rb.method("AddExplosionForce", 3).invoke(2000.0, pos, 8.0);
                        sendNotification(uxSelectedName + " exploded!", false);
                    } catch(e) { sendNotification("Explosion: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Calls AddExplosionForce at the object's own position — launches it."
            }),
            new ButtonInfo({
                buttonText: "UX: Log Velocity",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        const vel = rb.method("get_linearVelocity").invoke();
                        const angVel = rb.method("get_angularVelocity").invoke();
                        const speed = Math.sqrt(
                            Math.pow(vel.field("x").value as number, 2) +
                            Math.pow(vel.field("y").value as number, 2) +
                            Math.pow(vel.field("z").value as number, 2)
                        );
                        console.log("[UX] " + uxSelectedName + " vel=" + uxVec3Str(vel) + " angVel=" + uxVec3Str(angVel));
                        sendNotification("speed=" + speed.toFixed(2) + " m/s | " + uxVec3Str(vel), false, 5);
                    } catch(e) { sendNotification("Log Vel: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Logs and displays the current linear and angular velocity of the selected object."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Make Grabbable",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                        if (!gbo || gbo.isNull()) { sendNotification("No GrabbableObject on " + uxSelectedName, false); return; }
                        gbo.method("set_forceDisableGrab").invoke(false);
                        try { gbo.field("_allowGrabAnywhere").value = true; } catch(_) {}
                        sendNotification(uxSelectedName + " is now grabbable", false);
                    } catch(e) { sendNotification("Make Grabbable: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Clears forceDisableGrab and enables grab-anywhere on the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Make Ungrabable",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                        if (!gbo || gbo.isNull()) { sendNotification("No GrabbableObject", false); return; }
                        gbo.method("set_forceDisableGrab").invoke(true);
                        sendNotification(uxSelectedName + " is now ungrabable", false);
                    } catch(e) { sendNotification("Make Ungrabable: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets forceDisableGrab=true so no one can pick up the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Grab Anywhere",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                        if (!gbo || gbo.isNull()) { sendNotification("No GrabbableObject", false); return; }
                        gbo.field("_allowGrabAnywhere").value = true;
                        gbo.field("_useDefaultHandGrabOffsets").value = false;
                        sendNotification(uxSelectedName + " can be grabbed anywhere", false);
                    } catch(e) { sendNotification("Grab Anywhere: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets _allowGrabAnywhere=true so the object can be grabbed at any point."
            }),
            new ButtonInfo({
                buttonText: "UX: Force Grab to Me",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                        if (!gbo || gbo.isNull()) {
                            
                            const handPos = rightHandTransform.method("get_position").invoke();
                            uxGetTransform(uxSelectedObject).method("set_position").invoke(handPos);
                            sendNotification(uxSelectedName + " moved to hand (no GBO)", false);
                            return;
                        }
                        const backAnchor = player.method("get_backItemAttachAnchor").invoke();
                        if (backAnchor && !backAnchor.isNull()) {
                            gbo.method("Grab").invoke(backAnchor, true);
                            sendNotification(uxSelectedName + " grabbed to back anchor", false);
                        } else {
                            const handPos = rightHandTransform.method("get_position").invoke();
                            uxGetTransform(uxSelectedObject).method("set_position").invoke(handPos);
                            sendNotification(uxSelectedName + " moved to hand", false);
                        }
                    } catch(e) { sendNotification("Force Grab: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Force-grabs the selected object to your back anchor, or teleports it to your hand as fallback."
            }),
            new ButtonInfo({
                buttonText: "UX: Force Release",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                        if (!gbo || gbo.isNull()) { sendNotification("No GrabbableObject", false); return; }
                        const pos = uxGetTransform(uxSelectedObject).method("get_position").invoke();
                        const rot = uxGetTransform(uxSelectedObject).method("get_rotation").invoke();
                        const zero = Vector3.method("get_zero").invoke();
                        gbo.method("Release").invoke(pos, rot, zero, zero, false, false);
                        sendNotification(uxSelectedName + " released", false);
                    } catch(e) { sendNotification("Force Release: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Force-releases the selected GrabbableObject with zero velocity."
            }),
            new ButtonInfo({
                buttonText: "UX: Scale Mod +",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                        if (!gbo || gbo.isNull()) { sendNotification("No GrabbableObject", false); return; }
                        const cur = gbo.method("get_scaleModifier").invoke() as number;
                        const next = Math.min(cur + 20, 127);
                        gbo.method("set_scaleModifier").invoke(next);
                        gbo.method("HandleScaleChanged").invoke();
                        sendNotification(uxSelectedName + " scaleModifier → " + next, false);
                    } catch(e) { sendNotification("Scale Mod+: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Increases the networked scaleModifier on GrabbableObject by 20 steps."
            }),
            new ButtonInfo({
                buttonText: "UX: Scale Mod -",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                        if (!gbo || gbo.isNull()) { sendNotification("No GrabbableObject", false); return; }
                        const cur = gbo.method("get_scaleModifier").invoke() as number;
                        const next = Math.max(cur - 20, -128);
                        gbo.method("set_scaleModifier").invoke(next);
                        gbo.method("HandleScaleChanged").invoke();
                        sendNotification(uxSelectedName + " scaleModifier → " + next, false);
                    } catch(e) { sendNotification("Scale Mod-: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Decreases the networked scaleModifier on GrabbableObject by 20 steps."
            }),
            new ButtonInfo({
                buttonText: "UX: Set Hue Random",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                        if (!gbo || gbo.isNull()) { sendNotification("No GrabbableObject", false); return; }
                        const hue = Math.random();
                        gbo.method("SetColorHue").invoke(hue);
                        gbo.method("HandleColorHueChanged").invoke();
                        sendNotification(uxSelectedName + " hue → " + (hue * 360).toFixed(0) + "°", false);
                    } catch(e) { sendNotification("Set Hue: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets a random color hue on the GrabbableObject's networked color."
            }),
            new ButtonInfo({
                buttonText: "UX: Hide Obj (GBO)",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                        if (!gbo || gbo.isNull()) { sendNotification("No GrabbableObject", false); return; }
                        gbo.method("SetIsHidden").invoke(true);
                        sendNotification(uxSelectedName + " hidden (networked)", false);
                    } catch(e) { sendNotification("Hide GBO: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Calls SetIsHidden(true) on the GrabbableObject — hidden for all players."
            }),
            new ButtonInfo({
                buttonText: "UX: Unhide Obj (GBO)",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                        if (!gbo || gbo.isNull()) { sendNotification("No GrabbableObject", false); return; }
                        gbo.method("SetIsHidden").invoke(false);
                        sendNotification(uxSelectedName + " unhidden (networked)", false);
                    } catch(e) { sendNotification("Unhide GBO: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Calls SetIsHidden(false) on the GrabbableObject — visible for all players."
            }),
            new ButtonInfo({
                buttonText: "UX: Reveal All Hidden",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        let activatedGOs = 0;
                        let enabledRenderers = 0;
                        let enabledColliders = 0;
                        let gboUnhidden = 0;

                        const tf = uxGetTransform(uxSelectedObject);
                        if (!tf) { sendNotification("No transform on " + uxSelectedName, false); return; }

                        
                        const stack: any[] = [tf];
                        while (stack.length > 0) {
                            const cur = stack.pop();
                            try {
                                const go = cur.method("get_gameObject").invoke();
                                if (go && !go.isNull()) {
                                    try {
                                        if (!go.method("get_activeSelf").invoke()) {
                                            go.method("SetActive").invoke(true);
                                            activatedGOs++;
                                        }
                                    } catch(_) {}
                                }
                                const childCount = cur.method("get_childCount").invoke() as number;
                                for (let i = 0; i < childCount; i++) {
                                    try { stack.push(cur.method("GetChild").invoke(i)); } catch(_) {}
                                }
                            } catch(_) {}
                        }

                        
                        try {
                            const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                            const rends = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(RendClass).invoke(true);
                            const rLen = rends ? rends.length : 0;
                            for (let i = 0; i < rLen; i++) {
                                try {
                                    const r = rends.method("get_Item").invoke(i);
                                    if (!r.method("get_enabled").invoke()) {
                                        r.method("set_enabled").invoke(true);
                                        enabledRenderers++;
                                    }
                                } catch(_) {}
                            }
                        } catch(_) {}

                        
                        try {
                            const ColClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Collider");
                            const cols = uxSelectedObject.method("GetComponentsInChildren", 1).inflate(ColClass).invoke(true);
                            const cLen = cols ? cols.length : 0;
                            for (let i = 0; i < cLen; i++) {
                                try {
                                    const c = cols.method("get_Item").invoke(i);
                                    if (!c.method("get_enabled").invoke()) {
                                        c.method("set_enabled").invoke(true);
                                        enabledColliders++;
                                    }
                                } catch(_) {}
                            }
                        } catch(_) {}

                        
                        try {
                            const gbo = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBOClass).invoke(true);
                            if (gbo && !gbo.isNull()) {
                                gbo.method("SetIsHidden").invoke(false);
                                gboUnhidden = 1;
                            }
                        } catch(_) {}

                        const msg = "Revealed on " + uxSelectedName + ":\n"
                            + activatedGOs + " inactive GOs, "
                            + enabledRenderers + " renderers, "
                            + enabledColliders + " colliders"
                            + (gboUnhidden ? ", GBO unhidden" : "");
                        console.log("[UX] " + msg);
                        sendNotification(msg, false, 7);
                    } catch(e) { sendNotification("Reveal Hidden: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Makes EVERYTHING on the selected object visible: activates all inactive children, re-enables all disabled Renderers and Colliders, and clears the GBO hidden flag."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Sell Value +500",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        const cur = gbi.method("get_additionalSellValue").invoke() as number;
                        gbi.method("SetAdditionalSellValue").invoke(cur + 500);
                        const newVal = gbi.method("get_sellValue").invoke() as number;
                        sendNotification(uxSelectedName + " sell value → " + newVal, false);
                    } catch(e) { sendNotification("Sell Value: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Increases additionalSellValue by 500 (synced via RPC)."
            }),
            new ButtonInfo({
                buttonText: "UX: Sell Value MAX",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        gbi.method("SetAdditionalSellValue").invoke(999999);
                        sendNotification(uxSelectedName + " sell value = MAX (999999)", false);
                    } catch(e) { sendNotification("Sell Max: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets additionalSellValue to 999999 — sells for a fortune."
            }),
            new ButtonInfo({
                buttonText: "UX: Sell Value Reset",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        gbi.method("SetAdditionalSellValue").invoke(0);
                        sendNotification(uxSelectedName + " sell value reset", false);
                    } catch(e) { sendNotification("Sell Reset: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets additionalSellValue to 0."
            }),
            new ButtonInfo({
                buttonText: "UX: Mark Purchased",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        gbi.method("set_wasPurchased").invoke(true);
                        sendNotification(uxSelectedName + " marked as purchased", false);
                    } catch(e) { sendNotification("Purchased: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets wasPurchased=true on the GrabbableItem."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Force Eat Now",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const EdibleClass = AssemblyCSharp.class("AnimalCompany.EdibleItem");
                        const edible = uxSelectedObject.method("GetComponentInChildren", 1).inflate(EdibleClass).invoke(true);
                        if (!edible || edible.isNull()) { sendNotification("Not edible: " + uxSelectedName, false); return; }
                        edible.method("TestOnEaten").invoke();
                        sendNotification(uxSelectedName + " eaten! Nom nom.", false);
                    } catch(e) { sendNotification("Eat: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Calls TestOnEaten() on the EdibleItem component — triggers all buff/eat effects."
            }),
            new ButtonInfo({
                buttonText: "UX: Check Edible",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const EdibleClass = AssemblyCSharp.class("AnimalCompany.EdibleItem");
                        const edible = uxSelectedObject.method("GetComponentInChildren", 1).inflate(EdibleClass).invoke(true);
                        if (!edible || edible.isNull()) {
                            sendNotification(uxSelectedName + " is NOT edible", false, 4);
                            console.log("[UX] " + uxSelectedName + " has no EdibleItem component");
                        } else {
                            const wasEaten = edible.field("_wasEaten").value;
                            sendNotification(uxSelectedName + " IS edible! wasEaten=" + wasEaten, false, 4);
                            console.log("[UX] " + uxSelectedName + " EdibleItem found, wasEaten=" + wasEaten);
                        }
                    } catch(e) { sendNotification("Check Edible: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Checks if the selected object has an EdibleItem component and logs its state."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Print Item Data",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem on " + uxSelectedName, false); return; }
                        const itemID    = gbi.method("get_itemID").invoke()?.content ?? "?";
                        const sellVal   = gbi.method("get_sellValue").invoke() as number;
                        const addSell   = gbi.method("get_additionalSellValue").invoke() as number;
                        const canBag    = gbi.method("get_canAddToBag").invoke();
                        const allowBag  = gbi.method("get_allowAddToBag").invoke();
                        const allowItem = gbi.method("get_allowAttachToItem").invoke();
                        const inBP      = gbi.field("_allowAddToBag").value;
                        console.log("[UX-ItemData] ═══════════════════════════");
                        console.log("[UX-ItemData] itemID         : " + itemID);
                        console.log("[UX-ItemData] sellValue      : " + sellVal + " (+" + addSell + " bonus)");
                        console.log("[UX-ItemData] canAddToBag    : " + canBag);
                        console.log("[UX-ItemData] allowAddToBag  : " + allowBag);
                        console.log("[UX-ItemData] allowAttachItem: " + allowItem);
                        console.log("[UX-ItemData] _allowAddToBag : " + inBP);
                        
                        try {
                            const itemData = gbi.method("get_itemData").invoke();
                            if (itemData && !itemData.isNull()) {
                                const flags = itemData.method("get_flags").invoke();
                                const flagVal = flags ? flags.method("get_value").invoke() : "?";
                                console.log("[UX-ItemData] flags          : " + flagVal);
                                console.log("[UX-ItemData] isLoot         : " + itemData.method("get_isLoot").invoke());
                                console.log("[UX-ItemData] isPurchasable  : " + itemData.method("get_isPurchasable").invoke());
                                console.log("[UX-ItemData] isBag          : " + itemData.method("get_isBag").invoke());
                                console.log("[UX-ItemData] isQuiver       : " + itemData.method("get_isQuiver").invoke());
                                console.log("[UX-ItemData] isWeapon       : " + itemData.method("get_isWeapon").invoke());
                            }
                        } catch(_) {}
                        console.log("[UX-ItemData] ═══════════════════════════");
                        sendNotification(itemID + " | sell=" + sellVal + " | see log", false, 5);
                    } catch(e) { sendNotification("Item Data: " + e, false); console.error("[UX] ItemData:", e); }
                },
                isTogglable: false,
                toolTip: "Logs full itemID, sell value, and all GameplayItemFlags to Frida console."
            }),
            new ButtonInfo({
                buttonText: "UX: Allow in Bag",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        gbi.method("set_allowAddToBag").invoke(true);
                        try { gbi.field("_allowAddToBag").value = true; } catch(_) {}
                        sendNotification(uxSelectedName + " can now go in bags", false);
                    } catch(e) { sendNotification("Allow in Bag: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets allowAddToBag=true so the item can be put into backpacks."
            }),
            new ButtonInfo({
                buttonText: "UX: Deny in Bag",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        gbi.method("set_allowAddToBag").invoke(false);
                        try { gbi.field("_allowAddToBag").value = false; } catch(_) {}
                        sendNotification(uxSelectedName + " blocked from bags", false);
                    } catch(e) { sendNotification("Deny in Bag: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets allowAddToBag=false so the item cannot be bagged."
            }),
            new ButtonInfo({
                buttonText: "UX: Set Loot Flag",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        const itemData = gbi.method("get_itemData").invoke();
                        if (!itemData || itemData.isNull()) { sendNotification("No itemData", false); return; }
                        const flagsSP = itemData.method("get_flags").invoke();
                        const cur = flagsSP.method("get_value").invoke() as number;
                        flagsSP.method("set_value").invoke(cur | 2); 
                        sendNotification(uxSelectedName + " flagged as Loot", false);
                    } catch(e) { sendNotification("Loot Flag: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Adds the Loot flag (0x2) to the item's GameplayItemFlags."
            }),
            new ButtonInfo({
                buttonText: "UX: Set Bag Flag",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        const itemData = gbi.method("get_itemData").invoke();
                        if (!itemData || itemData.isNull()) return;
                        const flagsSP = itemData.method("get_flags").invoke();
                        const cur = flagsSP.method("get_value").invoke() as number;
                        
                        flagsSP.method("set_value").invoke(cur | 32 | 128);
                        sendNotification(uxSelectedName + " flagged as Bag", false);
                    } catch(e) { sendNotification("Bag Flag: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Adds IsBag(0x20) + AllowAddToBag(0x80) flags to the item."
            }),
            new ButtonInfo({
                buttonText: "UX: Set Quiver Flag",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        const itemData = gbi.method("get_itemData").invoke();
                        if (!itemData || itemData.isNull()) return;
                        const flagsSP = itemData.method("get_flags").invoke();
                        const cur = flagsSP.method("get_value").invoke() as number;
                        
                        flagsSP.method("set_value").invoke(cur | 64 | 256);
                        sendNotification(uxSelectedName + " flagged as Quiver", false);
                    } catch(e) { sendNotification("Quiver Flag: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Adds IsQuiver(0x40) + AllowAddToQuiver(0x100) flags to the item."
            }),
            new ButtonInfo({
                buttonText: "UX: Flag Back+Hip",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        const itemData = gbi.method("get_itemData").invoke();
                        if (!itemData || itemData.isNull()) return;
                        const flagsSP = itemData.method("get_flags").invoke();
                        const cur = flagsSP.method("get_value").invoke() as number;
                        
                        flagsSP.method("set_value").invoke(cur | 1024 | 2048);
                        sendNotification(uxSelectedName + " can attach to back/hip", false);
                    } catch(e) { sendNotification("Back+Hip Flag: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Adds AllowAttachToBack(0x400) + AllowAttachToHip(0x800) flags."
            }),
            new ButtonInfo({
                buttonText: "UX: Flags = ALL",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        const itemData = gbi.method("get_itemData").invoke();
                        if (!itemData || itemData.isNull()) return;
                        const flagsSP = itemData.method("get_flags").invoke();
                        
                        flagsSP.method("set_value").invoke(8190);
                        gbi.method("set_allowAddToBag").invoke(true);
                        sendNotification(uxSelectedName + " ALL flags enabled", false);
                    } catch(e) { sendNotification("Flags ALL: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets ALL GameplayItemFlags at once — item becomes loot, bag, quiver, attachable everywhere."
            }),
            new ButtonInfo({
                buttonText: "UX: Flags = CLEAR",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem", false); return; }
                        const itemData = gbi.method("get_itemData").invoke();
                        if (!itemData || itemData.isNull()) return;
                        const flagsSP = itemData.method("get_flags").invoke();
                        flagsSP.method("set_value").invoke(0);
                        sendNotification(uxSelectedName + " flags cleared", false);
                    } catch(e) { sendNotification("Flags Clear: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Clears all GameplayItemFlags to 0 (None)."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Buff Player Hit",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.8;
                        try {
                            const hitCol = ray.method("get_collider").invoke();
                            if (!hitCol || hitCol.isNull()) return;
                            const hitGO = hitCol.method("get_gameObject").invoke();
                            const hitPlayer = hitGO.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                            if (!hitPlayer || hitPlayer.isNull()) { sendNotification("No player hit", false); return; }
                            const name = getPlayerName(hitPlayer);
                            
                            if (!(globalThis as any)._uxBuffIdx) (globalThis as any)._uxBuffIdx = 1;
                            const buffID = (globalThis as any)._uxBuffIdx;
                            (globalThis as any)._uxBuffIdx = (buffID % 7) + 1;
                            hitPlayer.method("RPC_ApplyBuff").invoke(buffID);
                            const buffNames = ["?","Speed","Pink","Damage","Stun","Scale","Stinky","AntiGrav"];
                            sendNotification("Buffed " + name + " → " + (buffNames[buffID] ?? buffID), false);
                        } catch(e) { sendNotification("Buff Gun: " + e, false); }
                    }
                },
                toolTip: "Aim at a player and pull trigger to cycle through all 7 buffs (Speed/Pink/Damage/Stun/Scale/Stinky/AntiGrav)."
            }),
            new ButtonInfo({
                buttonText: "UX: Tag Stinky Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const hitCol = ray.method("get_collider").invoke();
                            if (!hitCol || hitCol.isNull()) return;
                            const hitGO = hitCol.method("get_gameObject").invoke();
                            const hitPlayer = hitGO.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                            if (!hitPlayer || hitPlayer.isNull()) { sendNotification("No player", false); return; }
                            hitPlayer.method("RPC_TagAsStinky").invoke();
                            sendNotification(getPlayerName(hitPlayer) + " tagged stinky!", false);
                        } catch(e) { sendNotification("Stinky Gun: " + e, false); }
                    }
                },
                toolTip: "Aim at a player and pull trigger to tag them as stinky."
            }),
            new ButtonInfo({
                buttonText: "UX: Color HSV Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const hitCol = ray.method("get_collider").invoke();
                            if (!hitCol || hitCol.isNull()) return;
                            const hitGO = hitCol.method("get_gameObject").invoke();
                            const hitPlayer = hitGO.method("GetComponentInParent", 0).inflate(NetPlayer).invoke();
                            if (!hitPlayer || hitPlayer.isNull()) { sendNotification("No player", false); return; }
                            const hue = Math.random();
                            hitPlayer.method("RPC_SetColorHSV").invoke(30.0, hue, 1.0, 1.0);
                            sendNotification(getPlayerName(hitPlayer) + " → HSV hue " + (hue*360).toFixed(0) + "°", false);
                        } catch(e) { sendNotification("HSV Gun: " + e, false); }
                    }
                },
                toolTip: "Aim at a player and pull trigger to set a random HSV color effect on them for 30 seconds."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Instantiate Prefab",
                method: () => {
                    try {
                        const name = prefabIDs[prefabIndex];
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        const spawnPos = (player && !player.handle.isNull())
                            ? getTransform(player).method("get_position").invoke()
                            : Vector3.method("get_zero").invoke();
                        const result = spawnNetworkPrefab(name, spawnPos, identityQuaternion);
                        if (result && !result.isNull()) {
                            sendNotification("Spawned (net): " + name, false, 5);
                        } else {
                            sendNotification("Not found in PrefabTable: " + name, false);
                        }
                    } catch(e) { sendNotification("Instantiate: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Spawns the selected prefab at your position via NetworkRunner PrefabTable."
            }),
            new ButtonInfo({
                buttonText: "UX: Spawn At Aim",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.4;
                        try {
                            const hitPoint = ray.method("get_point").invoke();
                            const name = prefabIDs[prefabIndex];
                            const result = spawnNetworkPrefab(name, hitPoint, identityQuaternion);
                            if (result && !result.isNull()) {
                                sendNotification("Spawned: " + name, false);
                            } else {
                                sendNotification("Not found in PrefabTable: " + name, false);
                            }
                        } catch(e) { sendNotification("Spawn Aim: " + e, false); }
                    }
                },
                toolTip: "Hold grip + aim + trigger to spawn the selected prefab exactly where you aim (via NetworkRunner)."
            }),
            new ButtonInfo({
                buttonText: "UX: Spawn Copy Here",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        const spawnPos = (player && !player.handle.isNull())
                            ? getTransform(player).method("get_position").invoke()
                            : uxGetTransform(uxSelectedObject).method("get_position").invoke();
                        const rot = uxGetTransform(uxSelectedObject).method("get_rotation").invoke();
                        
                        try {
                            const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                            if (gbi && !gbi.isNull()) {
                                const itemID = gbi.method("get_itemID").invoke()?.content ?? "";
                                if (itemID) {
                                    PrefabGen.method("SpawnItem", 4).invoke(Il2Cpp.string(itemID), spawnPos, rot, NULL);
                                    sendNotification("Copied: " + itemID, false, 5);
                                    return;
                                }
                            }
                        } catch(_) {}
                        
                        Object.method("Instantiate", 3).invoke(uxSelectedObject, spawnPos, rot);
                        sendNotification("Cloned: " + uxSelectedName, false, 5);
                    } catch(e) { sendNotification("Spawn Copy: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Spawns a copy of the selected object at your position. Uses itemID for networked spawn, falls back to Instantiate."
            }),
            new ButtonInfo({
                buttonText: "UX: Despawn Selected",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const NOClass = Il2Cpp.domain.assembly("Fusion.Runtime").image.class("Fusion.NetworkObject");
                        const no = uxSelectedObject.method("GetComponentInParent", 0).inflate(NOClass).invoke();
                        if (no && !no.isNull()) {
                            const runner = PrefabGen.method("get_runner").invoke();
                            if (runner && !runner.isNull()) {
                                runner.method("Despawn", 1).invoke(no);
                                sendNotification("Despawned: " + uxSelectedName, false);
                                uxSelectedObject = null; uxSelectedName = "none";
                                return;
                            }
                        }
                        
                        Object.method("Destroy", 1).invoke(uxSelectedObject);
                        sendNotification("Destroyed: " + uxSelectedName, false);
                        uxSelectedObject = null; uxSelectedName = "none";
                    } catch(e) { sendNotification("Despawn: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Despawns the selected object via NetworkRunner, or falls back to Object.Destroy."
            }),
            new ButtonInfo({
                buttonText: "UX: Copy to Prefab List",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        let added = "";
                        try {
                            const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                            if (gbi && !gbi.isNull()) {
                                const itemID = gbi.method("get_itemID").invoke()?.content ?? "";
                                if (itemID && !(prefabIDs as any).includes(itemID)) {
                                    (prefabIDs as any).push(itemID);
                                    added = itemID;
                                } else if (itemID) {
                                    sendNotification("Already in list: " + itemID, false); return;
                                }
                            }
                        } catch(_) {}
                        if (!added) {
                            const n = uxSelectedName;
                            if (!(prefabIDs as any).includes(n)) { (prefabIDs as any).push(n); added = n; }
                            else { sendNotification("Already in list: " + n, false); return; }
                        }
                        prefabIndex = (prefabIDs as any).length - 1;
                        sendNotification("Added + selected: " + added, false, 5);
                    } catch(e) { sendNotification("Copy Prefab: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Adds the selected object's itemID (or name) to your prefab spawn list and selects it."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Make Edible",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const EdibleClass = AssemblyCSharp.class("AnimalCompany.EdibleItem");
                        
                        const existing = uxSelectedObject.method("GetComponentInChildren", 1).inflate(EdibleClass).invoke(true);
                        if (existing && !existing.isNull()) {
                            sendNotification(uxSelectedName + " already has EdibleItem!", false, 4);
                            return;
                        }
                        
                        const newEdible = uxSelectedObject.method("AddComponent", 1).inflate(EdibleClass).invoke();
                        if (newEdible && !newEdible.isNull()) {
                            sendNotification(uxSelectedName + " → EdibleItem added!", false, 5);
                        } else {
                            sendNotification("AddComponent returned null", false);
                        }
                    } catch(e) { sendNotification("Make Edible: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Adds an EdibleItem component to the selected object so it can be eaten."
            }),
            new ButtonInfo({
                buttonText: "UX: Trigger Eat",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const EdibleClass = AssemblyCSharp.class("AnimalCompany.EdibleItem");
                        const edible = uxSelectedObject.method("GetComponentInChildren", 1).inflate(EdibleClass).invoke(true);
                        if (!edible || edible.isNull()) { sendNotification("No EdibleItem — use Make Edible first", false); return; }
                        
                        edible.field("_wasEaten").value = true;
                        
                        let ate = false;
                        try {
                            const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                            if (gbi && !gbi.isNull()) {
                                gbi.method("DespawnItem").invoke();
                                ate = true;
                            }
                        } catch(_) {}
                        if (!ate) {
                            
                            try { Object.method("Destroy", 1).invoke(uxSelectedObject); ate = true; } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " → eaten and despawned!", false, 4);
                        uxSelectedObject = null; uxSelectedName = "none";
                    } catch(e) { sendNotification("Trigger Eat: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Triggers the eat sequence: sets _wasEaten=true then despawns the item via DespawnItem or Object.Destroy."
            }),
            new ButtonInfo({
                buttonText: "UX: Check Edible",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const EdibleClass = AssemblyCSharp.class("AnimalCompany.EdibleItem");
                        const edible = uxSelectedObject.method("GetComponentInChildren", 1).inflate(EdibleClass).invoke(true);
                        if (!edible || edible.isNull()) {
                            sendNotification(uxSelectedName + " is NOT edible", false, 4);
                            console.log("[UX] " + uxSelectedName + " — no EdibleItem component");
                        } else {
                            const wasEaten = edible.field("_wasEaten").value;
                            const isClose  = edible.field("_isCloseToMouth").value;
                            sendNotification(uxSelectedName + " IS edible | wasEaten=" + wasEaten + " nearMouth=" + isClose, false, 5);
                            console.log("[UX] EdibleItem found on " + uxSelectedName + " | wasEaten=" + wasEaten + " isCloseToMouth=" + isClose);
                        }
                    } catch(e) { sendNotification("Check Edible: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Checks if the selected object has an EdibleItem and logs wasEaten + isCloseToMouth."
            }),
            new ButtonInfo({
                buttonText: "UX: Reset Eaten",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const EdibleClass = AssemblyCSharp.class("AnimalCompany.EdibleItem");
                        const edible = uxSelectedObject.method("GetComponentInChildren", 1).inflate(EdibleClass).invoke(true);
                        if (!edible || edible.isNull()) { sendNotification("No EdibleItem on " + uxSelectedName, false); return; }
                        edible.field("_wasEaten").value = false;
                        edible.field("_timerEating").value = 0.0;
                        sendNotification(uxSelectedName + " → eat state reset (can be eaten again)", false, 4);
                    } catch(e) { sendNotification("Reset Eaten: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets _wasEaten=false and _timerEating=0 so the item can be eaten again."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Scale x2",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const cur = tf.method("get_localScale").invoke();
                        const x = cur.field("x").value as number;
                        const y = cur.field("y").value as number;
                        const z = cur.field("z").value as number;
                        const newScale = [x*2, y*2, z*2];
                        tf.method("set_localScale").invoke(newScale);
                        sendNotification(uxSelectedName + " scale x2 → (" + (x*2).toFixed(2) + ")", false);
                    } catch(e) { sendNotification("Scale x2: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Doubles the localScale of the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Scale x0.5",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const cur = tf.method("get_localScale").invoke();
                        const x = cur.field("x").value as number;
                        const y = cur.field("y").value as number;
                        const z = cur.field("z").value as number;
                        const newScale = [x*0.5, y*0.5, z*0.5];
                        tf.method("set_localScale").invoke(newScale);
                        sendNotification(uxSelectedName + " scale x0.5 → (" + (x*0.5).toFixed(2) + ")", false);
                    } catch(e) { sendNotification("Scale x0.5: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Halves the localScale of the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Scale Reset",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const one = Vector3.method("get_one").invoke();
                        tf.method("set_localScale").invoke(one);
                        sendNotification(uxSelectedName + " scale → (1,1,1)", false);
                    } catch(e) { sendNotification("Scale Reset: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets localScale of the selected object to (1,1,1)."
            }),
            new ButtonInfo({
                buttonText: "UX: Scale x10",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const cur = tf.method("get_localScale").invoke();
                        const x = cur.field("x").value as number;
                        const y = cur.field("y").value as number;
                        const z = cur.field("z").value as number;
                        const newScale = [x*10, y*10, z*10];
                        tf.method("set_localScale").invoke(newScale);
                        sendNotification(uxSelectedName + " scale x10 → (" + (x*10).toFixed(2) + ")", false);
                    } catch(e) { sendNotification("Scale x10: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Scales the selected object up by 10x."
            }),
            new ButtonInfo({
                buttonText: "UX: Move Up 1m",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const pos = tf.method("get_position").invoke();
                        const newPos = [pos.field("x").value as number, (pos.field("y").value as number) + 1.0, pos.field("z").value as number];
                        tf.method("set_position").invoke(newPos);
                        sendNotification(uxSelectedName + " moved up 1m", false);
                    } catch(e) { sendNotification("Move Up: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Moves the selected object up by 1 metre in world space."
            }),
            new ButtonInfo({
                buttonText: "UX: Move Down 1m",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const pos = tf.method("get_position").invoke();
                        const newPos = [pos.field("x").value as number, (pos.field("y").value as number) - 1.0, pos.field("z").value as number];
                        tf.method("set_position").invoke(newPos);
                        sendNotification(uxSelectedName + " moved down 1m", false);
                    } catch(e) { sendNotification("Move Down: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Moves the selected object down by 1 metre in world space."
            }),
            new ButtonInfo({
                buttonText: "UX: Rotate Y 90°",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const euler = tf.method("get_eulerAngles").invoke();
                        const ex = euler.field("x").value as number;
                        const ey = ((euler.field("y").value as number) + 90) % 360;
                        const ez = euler.field("z").value as number;
                        
                        
                        const V3Class = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Vector3");
                        const newEuler = V3Class.method(".ctor", 3).invoke(ex, ey, ez);
                        tf.method("set_eulerAngles").invoke(newEuler);
                        sendNotification(uxSelectedName + " rotated Y +90°", false);
                    } catch(e) {
                        
                        try {
                            const tf2 = uxGetTransform(uxSelectedObject);
                            const euler2 = tf2.method("get_eulerAngles").invoke();
                            euler2.field("y").value = ((euler2.field("y").value as number) + 90) % 360;
                            tf2.method("set_eulerAngles").invoke(euler2);
                            sendNotification(uxSelectedName + " rotated Y +90°", false);
                        } catch(e2) { sendNotification("Rotate Y: " + e2, false); }
                    }
                },
                isTogglable: false,
                toolTip: "Rotates the selected object 90° around the Y axis."
            }),
            new ButtonInfo({
                buttonText: "UX: Snap to Ground",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const pos = tf.method("get_position").invoke();
                        const px = pos.field("x").value as number;
                        const py = pos.field("y").value as number;
                        const pz = pos.field("z").value as number;
                        
                        const originUp = Vector3.method("op_Addition").invoke(pos,
                            Vector3.method("op_Multiply").invoke(Vector3.method("get_up").invoke(), 2.0));
                        const downDir  = Vector3.method("op_Multiply").invoke(Vector3.method("get_up").invoke(), -1.0);
                        
                        const PhysicsClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Physics");
                        
                        
                        const RHClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.RaycastHit");
                        const hitBuf = Il2Cpp.alloc(128); 
                        const didHit = PhysicsClass.method("Raycast", 4).invoke(originUp, downDir, hitBuf, 200.0);
                        if (didHit) {
                            
                            const hitPoint = Il2Cpp.reference(hitBuf).method("get_point").invoke();
                            const hitY = hitPoint.field("y").value as number;
                            const newPos = Vector3.method("op_Addition").invoke(
                                Vector3.method("get_zero").invoke(),
                                Vector3.method("op_Addition").invoke(
                                    Vector3.method("op_Multiply", 2).invoke(Vector3.method("get_right").invoke(), px),
                                    Vector3.method("op_Addition").invoke(
                                        Vector3.method("op_Multiply", 2).invoke(Vector3.method("get_up").invoke(), hitY),
                                        Vector3.method("op_Multiply", 2).invoke(Vector3.method("get_forward").invoke(), pz)
                                    )
                                )
                            );
                            tf.method("set_position").invoke(newPos);
                            sendNotification(uxSelectedName + " snapped to y=" + hitY.toFixed(2), false, 4);
                        } else {
                            
                            const groundPos = Vector3.method("op_Addition").invoke(
                                Vector3.method("get_zero").invoke(),
                                Vector3.method("op_Addition").invoke(
                                    Vector3.method("op_Multiply", 2).invoke(Vector3.method("get_right").invoke(), px),
                                    Vector3.method("op_Multiply", 2).invoke(Vector3.method("get_forward").invoke(), pz)
                                )
                            );
                            tf.method("set_position").invoke(groundPos);
                            sendNotification(uxSelectedName + " snapped to y=0 (no raycast hit)", false, 4);
                        }
                    } catch(e) { sendNotification("Snap Ground: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Raycasts down from the selected object and snaps it to the ground surface."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Get Item ID",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const gbi = uxSelectedObject.method("GetComponentInChildren", 1).inflate(GBIClass).invoke(true);
                        if (!gbi || gbi.isNull()) { sendNotification("No GrabbableItem on " + uxSelectedName, false); return; }
                        const itemID  = gbi.method("get_itemID").invoke()?.content ?? "?";
                        const sellVal = gbi.method("get_sellValue").invoke() as number;
                        console.log("[UX] ItemID: " + itemID + " | sellValue: " + sellVal);
                        sendNotification("ItemID: " + itemID + " | sell=" + sellVal, false, 7);
                    } catch(e) { sendNotification("Get ItemID: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Reads and displays the itemID and sell value from the selected GrabbableItem."
            }),
            new ButtonInfo({
                buttonText: "UX: Log All Components",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const names = uxGetComponentNames(uxSelectedObject);
                        console.log("[UX] Components on " + uxSelectedName + " (" + names.length + "):");
                        names.forEach((n, i) => console.log("[UX]   [" + i + "] " + n));
                        sendNotification(uxSelectedName + ": " + names.length + " comps — see log", false, 5);
                    } catch(e) { sendNotification("Log Comps: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Logs every component type name on the selected object to the Frida console."
            }),
            new ButtonInfo({
                buttonText: "UX: Log Full Hierarchy",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        function logChildren(go: any, depth: number) {
                            const name = go.method("get_name").invoke()?.content ?? "?";
                            const prefix = "  ".repeat(depth) + (depth === 0 ? "ROOT: " : "└─ ");
                            console.log("[UX-Hier] " + prefix + name);
                            const tf = uxGetTransform(go);
                            if (!tf) return;
                            const childCount = tf.method("get_childCount").invoke() as number;
                            for (let i = 0; i < Math.min(childCount, 20); i++) {
                                try {
                                    const childTF = tf.method("GetChild").invoke(i);
                                    const childGO = childTF.method("get_gameObject").invoke();
                                    logChildren(childGO, depth + 1);
                                } catch(_) {}
                            }
                        }
                        logChildren(uxSelectedObject, 0);
                        sendNotification("Hierarchy logged — check Frida console", false, 4);
                    } catch(e) { sendNotification("Hierarchy: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Recursively logs the full child hierarchy of the selected GameObject (max 20 per level)."
            }),
            new ButtonInfo({
                buttonText: "UX: Select Parent",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const parentTF = tf.method("get_parent").invoke();
                        if (!parentTF || parentTF.isNull()) { sendNotification(uxSelectedName + " has no parent", false); return; }
                        const parentGO = parentTF.method("get_gameObject").invoke();
                        uxSelectedObject = parentGO;
                        uxSelectedName = parentGO.method("get_name").invoke()?.content ?? "unnamed";
                        sendNotification("Now selected: " + uxSelectedName, false, 4);
                    } catch(e) { sendNotification("Select Parent: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Navigates up to the parent GameObject and selects it as the new UX target."
            }),
            new ButtonInfo({
                buttonText: "UX: Select Child[0]",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const tf = uxGetTransform(uxSelectedObject);
                        const childCount = tf.method("get_childCount").invoke() as number;
                        if (childCount === 0) { sendNotification(uxSelectedName + " has no children", false); return; }
                        const childTF = tf.method("GetChild").invoke(0);
                        const childGO = childTF.method("get_gameObject").invoke();
                        uxSelectedObject = childGO;
                        uxSelectedName = childGO.method("get_name").invoke()?.content ?? "child";
                        sendNotification("Now selected: " + uxSelectedName + " (child 0 of " + childCount + ")", false, 4);
                    } catch(e) { sendNotification("Select Child: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Selects the first child of the currently selected GameObject."
            }),
            new ButtonInfo({
                buttonText: "UX: Select by Gun",
                isTogglable: true,
                method: () => {
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.5;
                        try {
                            const hitCol = ray.method("get_collider").invoke();
                            if (!hitCol || hitCol.isNull()) return;
                            const go = hitCol.method("get_gameObject").invoke();
                            uxSelectedObject = go;
                            uxSelectedName = go.method("get_name").invoke()?.content ?? "unnamed";
                            sendNotification("UX Selected: " + uxSelectedName, false, 4);
                        } catch(e) { sendNotification("Select Gun: " + e, false); }
                    }
                },
                toolTip: "Hold grip + aim + trigger to point-select any object in the world as your UX target."
            }),
            new ButtonInfo({
                buttonText: "UX: Spawn Mob Here",
                method: () => {
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        const spawnPos = (player && !player.handle.isNull())
                            ? getTransform(player).method("get_position").invoke()
                            : Vector3.method("get_zero").invoke();
                        
                        
                        const mobList = [10, 1, 5, 6, 19, 15, 3, 22]; 
                        const mobNames = ["Chicken","Angler","Banshee","Bomb","Spider","Phantom","Armstrong","Segway"];
                        if (!(globalThis as any)._uxMobIdx) (globalThis as any)._uxMobIdx = 0;
                        if (rightGrab) {
                            (globalThis as any)._uxMobIdx = ((globalThis as any)._uxMobIdx + 1) % mobList.length;
                            sendNotification("Mob: " + mobNames[(globalThis as any)._uxMobIdx], false, 3);
                            return;
                        }
                        const mobID = mobList[(globalThis as any)._uxMobIdx];
                        const mobName = mobNames[(globalThis as any)._uxMobIdx];
                        spawnMobAtPos({ name: mobName, id: mobID }, spawnPos, identityQuaternion);
                        sendNotification("Spawned " + mobName + " at your position!", false, 4);
                    } catch(e) { sendNotification("Spawn Mob: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Spawns a mob at your position. Hold RIGHT GRIP to cycle mob type (Chicken/Angler/Banshee/Bomb/Spider/Phantom/Armstrong/Segway), then press without grip to spawn."
            }),
            new ButtonInfo({
                buttonText: "UX: Kinematic ON",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_isKinematic").invoke(true);
                        sendNotification(uxSelectedName + " → kinematic ON (no physics)", false);
                    } catch(e) { sendNotification("Kinematic ON: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Enables isKinematic on the selected object's Rigidbody (physics won't move it)."
            }),
            new ButtonInfo({
                buttonText: "UX: Kinematic OFF",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_isKinematic").invoke(false);
                        sendNotification(uxSelectedName + " → kinematic OFF (physics active)", false);
                    } catch(e) { sendNotification("Kinematic OFF: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Disables isKinematic — object is now fully simulated by physics."
            }),
            new ButtonInfo({
                buttonText: "UX: Zero Velocity",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        const zero = Vector3.method("get_zero").invoke();
                        rb.method("set_linearVelocity").invoke(zero);
                        rb.method("set_angularVelocity").invoke(zero);
                        sendNotification(uxSelectedName + " velocity zeroed", false);
                    } catch(e) { sendNotification("Zero Vel: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets both linear and angular velocity to zero on the selected Rigidbody."
            }),
            new ButtonInfo({
                buttonText: "UX: Launch Up",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    try {
                        const RBClass = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image.class("UnityEngine.Rigidbody");
                        const rb = uxSelectedObject.method("GetComponentInChildren", 1).inflate(RBClass).invoke(true);
                        if (!rb || rb.isNull()) { sendNotification("No Rigidbody", false); return; }
                        rb.method("set_isKinematic").invoke(false);
                        rb.method("set_useGravity").invoke(true);
                        const upForce = [0, 1200, 0];
                        rb.method("AddForce", 2).invoke(upForce, 1); 
                        sendNotification(uxSelectedName + " launched up!", false);
                    } catch(e) { sendNotification("Launch Up: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Applies a large upward impulse force to the selected object's Rigidbody."
            }),

            
            new ButtonInfo({
                buttonText: "UX: List Scenes",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        const sceneCount = SceneMgr.method("get_sceneCountInBuildSettings").invoke() as number;
                        const loadedCount = SceneMgr.method("get_sceneCount").invoke() as number;
                        console.log("[UX-Scene] Build settings: " + sceneCount + " scenes, currently loaded: " + loadedCount);
                        for (let i = 0; i < loadedCount; i++) {
                            try {
                                const scene = SceneMgr.method("GetSceneAt").invoke(i);
                                const name = scene.method("get_name").invoke()?.content ?? "?";
                                const path = scene.method("get_path").invoke()?.content ?? "?";
                                const idx  = scene.method("get_buildIndex").invoke();
                                console.log("[UX-Scene]   [" + i + "] name=" + name + " buildIndex=" + idx + " path=" + path);
                            } catch(_) {}
                        }
                        sendNotification("Scenes: " + sceneCount + " in build, " + loadedCount + " loaded — see log", false, 5);
                    } catch(e) { sendNotification("List Scenes: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Logs all loaded scenes and build-settings scene count to Frida console."
            }),
            new ButtonInfo({
                buttonText: "UX: Load Scene 0",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        SceneMgr.method("LoadScene", 1).invoke(0); 
                        sendNotification("Loading scene index 0...", false);
                    } catch(e) { sendNotification("Load Scene 0: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Loads build-index scene 0 (usually the main menu/lobby)."
            }),
            new ButtonInfo({
                buttonText: "UX: Load Scene 1",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        SceneMgr.method("LoadScene", 1).invoke(1);
                        sendNotification("Loading scene index 1...", false);
                    } catch(e) { sendNotification("Load Scene 1: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Loads build-index scene 1."
            }),
            new ButtonInfo({
                buttonText: "UX: Load Scene 2",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        SceneMgr.method("LoadScene", 1).invoke(2);
                        sendNotification("Loading scene index 2...", false);
                    } catch(e) { sendNotification("Load Scene 2: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Loads build-index scene 2."
            }),
            new ButtonInfo({
                buttonText: "UX: Load Scene 3",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        SceneMgr.method("LoadScene", 1).invoke(3);
                        sendNotification("Loading scene index 3...", false);
                    } catch(e) { sendNotification("Load Scene 3: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Loads build-index scene 3."
            }),
            new ButtonInfo({
                buttonText: "UX: Load Scene 4",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        SceneMgr.method("LoadScene", 1).invoke(4);
                        sendNotification("Loading scene index 4...", false);
                    } catch(e) { sendNotification("Load Scene 4: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Loads build-index scene 4."
            }),
            new ButtonInfo({
                buttonText: "UX: Load Scene 5",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        SceneMgr.method("LoadScene", 1).invoke(5);
                        sendNotification("Loading scene index 5...", false);
                    } catch(e) { sendNotification("Load Scene 5: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Loads build-index scene 5."
            }),
            new ButtonInfo({
                buttonText: "UX: Reload Current",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        const scene = SceneMgr.method("GetActiveScene").invoke();
                        const idx = scene.method("get_buildIndex").invoke() as number;
                        const name = scene.method("get_name").invoke()?.content ?? "?";
                        SceneMgr.method("LoadScene", 1).invoke(idx);
                        sendNotification("Reloading: " + name + " [" + idx + "]", false);
                    } catch(e) { sendNotification("Reload: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Reloads the currently active scene."
            }),
            new ButtonInfo({
                buttonText: "UX: Load Scene +1",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        const scene = SceneMgr.method("GetActiveScene").invoke();
                        const cur = scene.method("get_buildIndex").invoke() as number;
                        const total = SceneMgr.method("get_sceneCountInBuildSettings").invoke() as number;
                        const next = (cur + 1) % Math.max(total, 1);
                        SceneMgr.method("LoadScene", 1).invoke(next);
                        sendNotification("Loading scene " + next + " of " + total, false);
                    } catch(e) { sendNotification("Load +1: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Loads the next scene in build order (wraps around)."
            }),
            new ButtonInfo({
                buttonText: "UX: Load Scene -1",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        const scene = SceneMgr.method("GetActiveScene").invoke();
                        const cur = scene.method("get_buildIndex").invoke() as number;
                        const total = SceneMgr.method("get_sceneCountInBuildSettings").invoke() as number;
                        const prev = ((cur - 1) + Math.max(total, 1)) % Math.max(total, 1);
                        SceneMgr.method("LoadScene", 1).invoke(prev);
                        sendNotification("Loading scene " + prev + " of " + total, false);
                    } catch(e) { sendNotification("Load -1: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Loads the previous scene in build order (wraps around)."
            }),
            new ButtonInfo({
                buttonText: "UX: Log Active Scene",
                method: () => {
                    try {
                        const SceneMgr = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.SceneManagement.SceneManager");
                        const scene = SceneMgr.method("GetActiveScene").invoke();
                        const name = scene.method("get_name").invoke()?.content ?? "?";
                        const path = scene.method("get_path").invoke()?.content ?? "?";
                        const idx  = scene.method("get_buildIndex").invoke() as number;
                        const goCount = scene.method("get_rootCount").invoke() as number;
                        console.log("[UX-Scene] Active: name=" + name + " index=" + idx + " rootObjects=" + goCount);
                        console.log("[UX-Scene] Path: " + path);
                        sendNotification("Scene: " + name + " [" + idx + "] roots=" + goCount, false, 6);
                    } catch(e) { sendNotification("Log Scene: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Logs the active scene name, build index, and root object count."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Instantiate Obj",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        const spawnPos = player && !player.handle.isNull()
                            ? getTransform(player).method("get_position").invoke()
                            : identityQuaternion;
                        
                        const clone = Object.method("Instantiate", 3).invoke(uxSelectedObject, spawnPos, identityQuaternion);
                        if (!clone || clone.isNull()) { sendNotification("Instantiate returned null", false); return; }
                        const cloneName = clone.method("get_name").invoke()?.content ?? "clone";
                        sendNotification("Instantiated: " + cloneName, false);
                        console.log("[UX] Instantiated: " + cloneName);
                    } catch(e) { sendNotification("Instantiate: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Instantiates a local clone of the selected object at your position."
            }),
            new ButtonInfo({
                buttonText: "UX: Instantiate Gun",
                isTogglable: true,
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    if (!rightGrab) return;
                    const gunData = renderGun();
                    const ray = gunData.ray;
                    if (!ray || ray.handle.isNull()) return;
                    if (rightTrigger && time > lagGunDelay) {
                        lagGunDelay = time + 0.4;
                        try {
                            const hitPoint = ray.method("get_point").invoke();
                            const clone = Object.method("Instantiate", 3).invoke(uxSelectedObject, hitPoint, identityQuaternion);
                            if (!clone || clone.isNull()) { sendNotification("Instantiate returned null", false); return; }
                            sendNotification("Spawned clone at aim point", false);
                        } catch(e) { sendNotification("Instantiate Gun: " + e, false); }
                    }
                },
                toolTip: "Hold grip + pull trigger to instantiate the selected object wherever you aim."
            }),
            new ButtonInfo({
                buttonText: "UX: Clone x5",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        const base = player && !player.handle.isNull()
                            ? getTransform(player).method("get_position").invoke()
                            : zeroVector;
                        let count = 0;
                        for (let i = 0; i < 5; i++) {
                            try {
                                const offset = [
                                    (base.field("x").value as number) + (Math.random() - 0.5) * 4,
                                    (base.field("y").value as number),
                                    (base.field("z").value as number) + (Math.random() - 0.5) * 4,
                                ];
                                const clone = Object.method("Instantiate", 3).invoke(uxSelectedObject, offset, identityQuaternion);
                                if (clone && !clone.isNull()) count++;
                            } catch(_) {}
                        }
                        sendNotification("Cloned x" + count + " around you", false);
                    } catch(e) { sendNotification("Clone x5: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Instantiates 5 copies of the selected object scattered around you."
            }),
            new ButtonInfo({
                buttonText: "UX: Destroy Obj",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const name = uxSelectedName;
                        
                        let despawned = false;
                        try {
                            const gbo = uxSelectedObject.method("GetComponent", 1).inflate(GBOClass).invoke();
                            if (gbo && !gbo.isNull()) {
                                const netObj = gbo.method("get_Object").invoke();
                                if (netObj && !netObj.isNull()) {
                                    const runner = getSfxCurrentRunner();
                                    if (runner && !runner.isNull?.()) runner.method("Despawn").invoke(netObj);
                                    despawned = true;
                                }
                            }
                        } catch(_) {}
                        if (!despawned) { Object.method("Destroy", 1).invoke(uxSelectedObject); }
                        uxSelectedObject = null;
                        uxSelectedName = "none";
                        sendNotification("Destroyed: " + name, false);
                    } catch(e) { sendNotification("Destroy: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Destroys the selected object (networked despawn if possible, else local Destroy)."
            }),

            
            new ButtonInfo({
                buttonText: "UX: List AudioSources",
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        console.log("[UX-SFX] AudioSources in scene: " + sources.length);
                        for (let i = 0; i < Math.min(sources.length, 30); i++) {
                            try {
                                const src = sources.get(i);
                                if (!src || src.isNull()) continue;
                                const goName = src.method("get_gameObject").invoke().method("get_name").invoke()?.content ?? "?";
                                let clipName = "none";
                                try {
                                    const clip = src.method("get_clip").invoke();
                                    if (clip && !clip.isNull()) clipName = clip.method("get_name").invoke()?.content ?? "?";
                                } catch(_) {}
                                const playing = src.method("get_isPlaying").invoke();
                                const vol = (src.method("get_volume").invoke() as number).toFixed(2);
                                console.log("[UX-SFX]  [" + i + "] GO=" + goName + " clip=" + clipName + " playing=" + playing + " vol=" + vol);
                            } catch(_) {}
                        }
                        sendNotification("AudioSources: " + sources.length + " — see log", false, 5);
                    } catch(e) { sendNotification("List Audio: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Logs all AudioSource components in the scene to Frida console."
            }),
            new ButtonInfo({
                buttonText: "UX: Mute All SFX",
                isTogglable: true,
                enableMethod: () => {
                    try {
                        const AudioListener = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioListener");
                        try { AudioListener.method("set_volume").invoke(0.0); } catch(_) {}
                        
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_volume").invoke(0.0); } catch(_) {}
                        }
                        sendNotification("All SFX muted", false);
                    } catch(e) { sendNotification("Mute SFX: " + e, false); }
                },
                disableMethod: () => {
                    try {
                        const AudioListener = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioListener");
                        try { AudioListener.method("set_volume").invoke(1.0); } catch(_) {}
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_volume").invoke(1.0); } catch(_) {}
                        }
                        sendNotification("All SFX unmuted", false);
                    } catch(e) { sendNotification("Unmute SFX: " + e, false); }
                },
                toolTip: "Mutes / unmutes all AudioSources in the scene."
            }),
            new ButtonInfo({
                buttonText: "UX: Stop All SFX",
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        let count = 0;
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("Stop").invoke(); count++; } catch(_) {}
                        }
                        sendNotification("Stopped " + count + " AudioSources", false);
                    } catch(e) { sendNotification("Stop SFX: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Calls Stop() on every AudioSource in the scene."
            }),
            new ButtonInfo({
                buttonText: "UX: Play All SFX",
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        let count = 0;
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("Play").invoke(); count++; } catch(_) {}
                        }
                        sendNotification("Playing " + count + " AudioSources", false);
                    } catch(e) { sendNotification("Play SFX: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Calls Play() on every AudioSource in the scene."
            }),
            new ButtonInfo({
                buttonText: "UX: SFX Pitch 0.5x",
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        let count = 0;
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_pitch").invoke(0.5); count++; } catch(_) {}
                        }
                        sendNotification("Pitch → 0.5x on " + count + " sources (slow-mo SFX)", false);
                    } catch(e) { sendNotification("Pitch 0.5x: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all AudioSource pitches to 0.5 (slow-motion sound effect)."
            }),
            new ButtonInfo({
                buttonText: "UX: SFX Pitch 2x",
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        let count = 0;
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_pitch").invoke(2.0); count++; } catch(_) {}
                        }
                        sendNotification("Pitch → 2x on " + count + " sources (chipmunk SFX)", false);
                    } catch(e) { sendNotification("Pitch 2x: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all AudioSource pitches to 2.0 (chipmunk/fast sound)."
            }),
            new ButtonInfo({
                buttonText: "UX: SFX Pitch Reset",
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        let count = 0;
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_pitch").invoke(1.0); count++; } catch(_) {}
                        }
                        sendNotification("Pitch reset on " + count + " sources", false);
                    } catch(e) { sendNotification("Pitch Reset: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Resets all AudioSource pitches to 1.0 (normal)."
            }),
            new ButtonInfo({
                buttonText: "UX: Vol All 0.1",
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_volume").invoke(0.1); } catch(_) {}
                        }
                        sendNotification("Volume → 0.1 on all sources (whisper)", false);
                    } catch(e) { sendNotification("Vol 0.1: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all AudioSource volumes to 0.1 (nearly silent)."
            }),
            new ButtonInfo({
                buttonText: "UX: Vol All Max",
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_volume").invoke(1.0); } catch(_) {}
                        }
                        sendNotification("Volume → 1.0 on all sources", false);
                    } catch(e) { sendNotification("Vol Max: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all AudioSource volumes to 1.0 (maximum)."
            }),
            new ButtonInfo({
                buttonText: "UX: Swap Clip Random",
                method: () => {
                    
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        if (!sources || sources.length === 0) { sendNotification("No AudioSources found", false); return; }
                        
                        let donorClip: any = null;
                        let donorName = "?";
                        for (let i = 0; i < sources.length; i++) {
                            try {
                                const s = sources.get(i);
                                if (!s || s.isNull()) continue;
                                const clip = s.method("get_clip").invoke();
                                if (clip && !clip.isNull()) {
                                    donorClip = clip;
                                    donorName = clip.method("get_name").invoke()?.content ?? "?";
                                    break;
                                }
                            } catch(_) {}
                        }
                        if (!donorClip) { sendNotification("No AudioClip found to copy", false); return; }
                        let swapped = 0;
                        for (let i = 0; i < sources.length; i++) {
                            try {
                                const s = sources.get(i);
                                if (!s || s.isNull()) continue;
                                s.method("set_clip").invoke(donorClip);
                                s.method("Play").invoke();
                                swapped++;
                            } catch(_) {}
                        }
                        sendNotification("Swapped all to clip: " + donorName + " (" + swapped + " sources)", false);
                    } catch(e) { sendNotification("Swap Clip: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Copies the first found AudioClip onto all AudioSources and plays them."
            }),
            new ButtonInfo({
                buttonText: "UX: Log Obj Clips",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(AuSrc).invoke();
                        if (!sources || sources.isNull() || sources.length === 0) { sendNotification("No AudioSources on " + uxSelectedName, false); return; }
                        console.log("[UX-SFX] AudioSources on " + uxSelectedName + " (" + sources.length + "):");
                        for (let i = 0; i < sources.length; i++) {
                            try {
                                const s = sources.get(i);
                                if (!s || s.isNull()) continue;
                                let clipName = "none";
                                try { const c = s.method("get_clip").invoke(); if (c && !c.isNull()) clipName = c.method("get_name").invoke()?.content ?? "?"; } catch(_) {}
                                const vol = (s.method("get_volume").invoke() as number).toFixed(2);
                                const pitch = (s.method("get_pitch").invoke() as number).toFixed(2);
                                const loop = s.method("get_loop").invoke();
                                console.log("[UX-SFX]   [" + i + "] clip=" + clipName + " vol=" + vol + " pitch=" + pitch + " loop=" + loop);
                            } catch(_) {}
                        }
                        sendNotification(sources.length + " AudioSources logged — see Frida log", false, 4);
                    } catch(e) { sendNotification("Log Clips: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Logs all AudioSource clips/volume/pitch on the selected object to Frida console."
            }),
            new ButtonInfo({
                buttonText: "UX: Play Obj SFX",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(AuSrc).invoke();
                        let count = 0;
                        if (sources && !sources.isNull()) {
                            for (let i = 0; i < sources.length; i++) {
                                try { sources.get(i).method("Play").invoke(); count++; } catch(_) {}
                            }
                        }
                        sendNotification("Played " + count + " AudioSources on " + uxSelectedName, false);
                    } catch(e) { sendNotification("Play Obj SFX: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Plays all AudioSources on the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Mute Obj SFX",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(AuSrc).invoke();
                        let count = 0;
                        if (sources && !sources.isNull()) {
                            for (let i = 0; i < sources.length; i++) {
                                try {
                                    const s = sources.get(i);
                                    s.method("Stop").invoke();
                                    s.method("set_volume").invoke(0.0);
                                    count++;
                                } catch(_) {}
                            }
                        }
                        sendNotification("Muted " + count + " AudioSources on " + uxSelectedName, false);
                    } catch(e) { sendNotification("Mute Obj SFX: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Stops and mutes all AudioSources on the selected object."
            }),

            
            new ButtonInfo({
                buttonText: "UX: Log Textures",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        if (!rends || rends.isNull() || rends.length === 0) { sendNotification("No renderers on " + uxSelectedName, false); return; }
                        console.log("[UX-Tex] Renderers on " + uxSelectedName + " (" + rends.length + "):");
                        for (let i = 0; i < rends.length; i++) {
                            try {
                                const r = rends.get(i);
                                if (!r || r.isNull()) continue;
                                const mat = r.method("get_material").invoke();
                                if (!mat || mat.isNull()) continue;
                                const matName = mat.method("get_name").invoke()?.content ?? "?";
                                let texName = "none";
                                try {
                                    const tex = mat.method("get_mainTexture").invoke();
                                    if (tex && !tex.isNull()) texName = tex.method("get_name").invoke()?.content ?? "?";
                                } catch(_) {}
                                const shader = mat.method("get_shader").invoke();
                                const shaderName = shader ? shader.method("get_name").invoke()?.content ?? "?" : "?";
                                console.log("[UX-Tex]   [" + i + "] mat=" + matName + " tex=" + texName + " shader=" + shaderName);
                            } catch(_) {}
                        }
                        sendNotification(rends.length + " renderers logged — see Frida log", false, 4);
                    } catch(e) { sendNotification("Log Textures: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Logs all renderer materials, textures, and shaders on the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Tex Invisible",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        if (!rends || rends.isNull()) { sendNotification("No renderers", false); return; }
                        for (let i = 0; i < rends.length; i++) {
                            try { rends.get(i).method("set_enabled").invoke(false); } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " → invisible (renderers off)", false);
                    } catch(e) { sendNotification("Tex Invisible: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Disables all renderers on the selected object — makes it invisible."
            }),
            new ButtonInfo({
                buttonText: "UX: Tex Visible",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        if (!rends || rends.isNull()) { sendNotification("No renderers", false); return; }
                        for (let i = 0; i < rends.length; i++) {
                            try { rends.get(i).method("set_enabled").invoke(true); } catch(_) {}
                        }
                        sendNotification(uxSelectedName + " → visible (renderers on)", false);
                    } catch(e) { sendNotification("Tex Visible: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Enables all renderers on the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Tex Set Unlit",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const unlitShader = Shader.method("Find").invoke(Il2Cpp.string("Universal Render Pipeline/Unlit"));
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        let count = 0;
                        if (rends && !rends.isNull()) {
                            for (let i = 0; i < rends.length; i++) {
                                try {
                                    const mat = rends.get(i).method("get_material").invoke();
                                    if (mat && !mat.isNull()) { mat.method("set_shader").invoke(unlitShader); count++; }
                                } catch(_) {}
                            }
                        }
                        sendNotification(uxSelectedName + " → Unlit shader (" + count + " mats)", false);
                    } catch(e) { sendNotification("Set Unlit: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Switches all materials on the selected object to the URP Unlit shader."
            }),
            new ButtonInfo({
                buttonText: "UX: Tex Swap Black",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        let count = 0;
                        if (rends && !rends.isNull()) {
                            for (let i = 0; i < rends.length; i++) {
                                try {
                                    const mat = rends.get(i).method("get_material").invoke();
                                    if (mat && !mat.isNull()) { mat.method("set_color").invoke([0,0,0,1]); count++; }
                                } catch(_) {}
                            }
                        }
                        sendNotification(uxSelectedName + " → black (" + count + " mats)", false);
                    } catch(e) { sendNotification("Tex Swap Black: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all material colors to black on the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Tex Swap White",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        let count = 0;
                        if (rends && !rends.isNull()) {
                            for (let i = 0; i < rends.length; i++) {
                                try {
                                    const mat = rends.get(i).method("get_material").invoke();
                                    if (mat && !mat.isNull()) { mat.method("set_color").invoke([1,1,1,1]); count++; }
                                } catch(_) {}
                            }
                        }
                        sendNotification(uxSelectedName + " → white (" + count + " mats)", false);
                    } catch(e) { sendNotification("Tex Swap White: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all material colors to white on the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Tex Swap Yellow",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        let count = 0;
                        if (rends && !rends.isNull()) {
                            for (let i = 0; i < rends.length; i++) {
                                try {
                                    const mat = rends.get(i).method("get_material").invoke();
                                    if (mat && !mat.isNull()) { mat.method("set_color").invoke([1,0.92,0.016,1]); count++; }
                                } catch(_) {}
                            }
                        }
                        sendNotification(uxSelectedName + " → yellow (" + count + " mats)", false);
                    } catch(e) { sendNotification("Tex Swap Yellow: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Sets all material colors to yellow on the selected object."
            }),
            new ButtonInfo({
                buttonText: "UX: Tex Rainbow Loop",
                isTogglable: true,
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) return;
                    if (frameCount % 8 !== 0) return;
                    try {
                        const h = (time * 0.5) % 1.0;
                        
                        const i2 = Math.floor(h * 6);
                        const f = h * 6 - i2;
                        const q = 1 - f;
                        let r = 1, g = 1, b = 1;
                        switch (i2 % 6) {
                            case 0: r=1; g=f; b=0; break;
                            case 1: r=q; g=1; b=0; break;
                            case 2: r=0; g=1; b=f; break;
                            case 3: r=0; g=q; b=1; break;
                            case 4: r=f; g=0; b=1; break;
                            case 5: r=1; g=0; b=q; break;
                        }
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        if (rends && !rends.isNull()) {
                            for (let i = 0; i < rends.length; i++) {
                                try {
                                    const mat = rends.get(i).method("get_material").invoke();
                                    if (mat && !mat.isNull()) mat.method("set_color").invoke([r,g,b,1]);
                                } catch(_) {}
                            }
                        }
                    } catch(_) {}
                },
                toolTip: "Continuously cycles the selected object's material color through the rainbow (toggle)."
            }),
            new ButtonInfo({
                buttonText: "UX: Tex Set Emissive",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        let count = 0;
                        if (rends && !rends.isNull()) {
                            for (let i = 0; i < rends.length; i++) {
                                try {
                                    const mat = rends.get(i).method("get_material").invoke();
                                    if (!mat || mat.isNull()) continue;
                                    
                                    try { mat.method("EnableKeyword").invoke(Il2Cpp.string("_EMISSION")); } catch(_) {}
                                    try { mat.method("SetColor").invoke(Il2Cpp.string("_EmissionColor"), [2,2,2,1]); } catch(_) {}
                                    count++;
                                } catch(_) {}
                            }
                        }
                        sendNotification(uxSelectedName + " → emissive white (" + count + " mats)", false);
                    } catch(e) { sendNotification("Set Emissive: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Enables emission on all materials of the selected object (glowing white)."
            }),
            new ButtonInfo({
                buttonText: "UX: Tex Clear Tex",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        let count = 0;
                        if (rends && !rends.isNull()) {
                            for (let i = 0; i < rends.length; i++) {
                                try {
                                    const mat = rends.get(i).method("get_material").invoke();
                                    if (!mat || mat.isNull()) continue;
                                    
                                    const nullRef = Il2Cpp.reference(Il2Cpp.domain.assembly("mscorlib").image.class("System.Object").alloc());
                                    try { mat.method("set_mainTexture").invoke(nullRef); } catch(_) {}
                                    count++;
                                } catch(_) {}
                            }
                        }
                        sendNotification(uxSelectedName + " textures cleared (" + count + " mats)", false);
                    } catch(e) { sendNotification("Clear Tex: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Clears the mainTexture on all materials — shows flat color only."
            }),
            new ButtonInfo({
                buttonText: "UX: Tex From Near",
                method: () => {
                    if (!uxSelectedObject || uxSelectedObject.isNull()) { sendNotification("No object selected", false); return; }
                    try {
                        
                        const player = NetPlayer.method("get_localPlayer").invoke();
                        if (!player || player.handle.isNull()) return;
                        const myPos = getTransform(player).method("get_position").invoke();
                        const RendClass = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                        const allRends = Object.method("FindObjectsByType", 1).inflate(RendClass).invoke(0);
                        let donorTex: any = null;
                        let donorTexName = "?";
                        for (let i = 0; i < allRends.length; i++) {
                            try {
                                const r = allRends.get(i);
                                if (!r || r.isNull()) continue;
                                const go = r.method("get_gameObject").invoke();
                                if (go && !go.isNull() && go.handle.equals(uxSelectedObject.handle)) continue;
                                const dist = Vector3.method("Distance").invoke(myPos, uxGetTransform(go).method("get_position").invoke()) as number;
                                if (dist > 8.0) continue;
                                const mat = r.method("get_material").invoke();
                                if (!mat || mat.isNull()) continue;
                                const tex = mat.method("get_mainTexture").invoke();
                                if (tex && !tex.isNull()) {
                                    donorTex = tex;
                                    donorTexName = tex.method("get_name").invoke()?.content ?? "?";
                                    break;
                                }
                            } catch(_) {}
                        }
                        if (!donorTex) { sendNotification("No texture found within 8m", false); return; }
                        
                        const rends = uxSelectedObject.method("GetComponentsInChildren", 0).inflate(RendClass).invoke();
                        let count = 0;
                        if (rends && !rends.isNull()) {
                            for (let i = 0; i < rends.length; i++) {
                                try {
                                    const mat = rends.get(i).method("get_material").invoke();
                                    if (mat && !mat.isNull()) { mat.method("set_mainTexture").invoke(donorTex); count++; }
                                } catch(_) {}
                            }
                        }
                        sendNotification("Applied tex '" + donorTexName + "' to " + count + " mats on " + uxSelectedName, false);
                    } catch(e) { sendNotification("Tex From Near: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Steals the texture from the nearest object within 8m and applies it to the selected object."
            }),
        ],

        [], // index 15 – placeholder (Monster RPCs slot)
        [], // index 16 – placeholder (Extra WL slot)
        [], // index 17 – placeholder (Unity Explorer slot)
        [], // index 18 – placeholder (reserved)

        // ── CATEGORY 19 ── Orbit Mods ───────────────────────────────────────
        [
            new ButtonInfo({
                buttonText: "Exit Orbit Mods",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to main menu."
            }),
            new ButtonInfo({
              buttonText: "Orbit Players",
              method: () => {
                try {
                    const targets = getAllNetPlayersList(false);
                    if (targets.length === 0) return;
                    const centerPos = getTransform(headCollider).method("get_position").invoke();
                    const cx = centerPos.field("x").value as number;
                    const cy = centerPos.field("y").value as number;
                    const cz = centerPos.field("z").value as number;
                    const radius = 3.5;
                    const spin = time * 1.85;
                    for (let i = 0; i < targets.length; i++) {
                        const p = targets[i];
                        if (!p || p.handle.isNull()) continue;
                        const angle = spin + ((i / Math.max(targets.length, 1)) * Math.PI * 2);
                        const orbitPos = [
                            cx + Math.cos(angle) * radius,
                            cy + 0.15 + Math.sin((angle * 2.0) + (time * 0.4)) * 0.25,
                            cz + Math.sin(angle) * radius
                        ];
                        try { p.method("RPC_Teleport").invoke(orbitPos); } catch(_) {}
                    }
                } catch(e) { console.error("Orbit Players error:", e); }
              },
              isTogglable: true,
              toolTip: "Continuously teleports all other players into an orbit around you."
            }),
            new ButtonInfo({
              buttonText: "Orbit Players Fast",
              method: () => {
                try {
                    const targets = getAllNetPlayersList(false);
                    if (targets.length === 0) return;
                    const centerPos = getTransform(headCollider).method("get_position").invoke();
                    const cx = centerPos.field("x").value as number;
                    const cy = centerPos.field("y").value as number;
                    const cz = centerPos.field("z").value as number;
                    const radius = 3.5;
                    const spin = time * (1.85 * 3.0);
                    for (let i = 0; i < targets.length; i++) {
                        const p = targets[i];
                        if (!p || p.handle.isNull()) continue;
                        const angle = spin + ((i / Math.max(targets.length, 1)) * Math.PI * 2);
                        const orbitPos = [
                            cx + Math.cos(angle) * radius,
                            cy + 0.15 + Math.sin((angle * 2.0) + (time * 1.2)) * 0.25,
                            cz + Math.sin(angle) * radius
                        ];
                        try { p.method("RPC_Teleport").invoke(orbitPos); } catch(_) {}
                    }
                } catch(e) { console.error("Orbit Players Fast error:", e); }
              },
              isTogglable: true,
              toolTip: "Continuously teleports all other players into a much faster orbit around you."
            }),
            new ButtonInfo({
                buttonText: "Mob Orbit",
                enableMethod: () => { mobOrbitEntries = []; },
                disableMethod: () => { mobOrbitEntries = []; },
                isTogglable: true,
                method: () => {
                    try {
                        const center = getTransform(headCollider).method("get_position").invoke();
                        const mob = mobIDs[mobIndex];
                        while (mobOrbitEntries.length < 6) {
                            const angle = (Math.PI * 2 * mobOrbitEntries.length) / 6;
                            const pos = [
                                (center.field("x").value as number) + Math.cos(angle) * 3.0,
                                (center.field("y").value as number) + 0.6,
                                (center.field("z").value as number) + Math.sin(angle) * 3.0
                            ];
                            const spawned = spawnMobAtPos(mob, pos, identityQuaternion) as any;
                            mobOrbitEntries.push({ mobEntry: mob, object: spawned ?? null, angle });
                        }
                        for (const orb of mobOrbitEntries) {
                            try {
                                if (!orb.object || orb.object.isNull?.()) continue;
                                orb.angle += deltaTime * 1.8;
                                const pos = [
                                    (center.field("x").value as number) + Math.cos(orb.angle) * 3.2,
                                    (center.field("y").value as number) + 0.7 + Math.sin((orb.angle * 2.0) + time) * 0.35,
                                    (center.field("z").value as number) + Math.sin(orb.angle) * 3.2
                                ];
                                stabilizeMobInstance(orb.object, pos);
                                getTransform(orb.object).method("set_position").invoke(pos);
                            } catch(_) {}
                        }
                    } catch(e) { console.error("Mob Orbit:", e); }
                },
                toolTip: "Spawns the current mob selection into an orbit around you and keeps them active."
            }),
            new ButtonInfo({
                buttonText: "Prefab Orbit",
                enableMethod: () => { prefabOrbitEntries = []; },
                disableMethod: () => {
                    for (const orb of prefabOrbitEntries) {
                        try {
                            const obj = orb?.object;
                            if (!obj || obj.isNull?.()) continue;
                            let go = obj;
                            try {
                                const maybeGo = obj.method("get_gameObject").invoke();
                                if (maybeGo && !maybeGo.isNull?.()) go = maybeGo;
                            } catch(_) {}
                            Destroy(go);
                        } catch(_) {}
                    }
                    prefabOrbitEntries = [];
                },
                isTogglable: true,
                method: () => {
                    try {
                        const center = getTransform(headCollider).method("get_position").invoke();
                        const prefabName = prefabIDs[prefabIndex];
                        while (prefabOrbitEntries.length < 6) {
                            const angle = (Math.PI * 2 * prefabOrbitEntries.length) / 6;
                            const spawnPos = [
                                (center.field("x").value as number) + Math.cos(angle) * 3.1,
                                (center.field("y").value as number) + 0.8,
                                (center.field("z").value as number) + Math.sin(angle) * 3.1
                            ];
                            const spawned = spawnNetworkPrefab(prefabName, spawnPos, identityQuaternion);
                            if (!spawned || spawned.isNull?.()) break;
                            prefabOrbitEntries.push({ object: spawned, angle });
                        }
                        for (const orb of prefabOrbitEntries) {
                            try {
                                if (!orb.object || orb.object.isNull?.()) continue;
                                orb.angle += deltaTime * 1.6;
                                const pos = [
                                    (center.field("x").value as number) + Math.cos(orb.angle) * 3.3,
                                    (center.field("y").value as number) + 0.8 + Math.sin((orb.angle * 2.0) + time) * 0.25,
                                    (center.field("z").value as number) + Math.sin(orb.angle) * 3.3
                                ];
                                getTransform(orb.object).method("set_position").invoke(pos);
                            } catch(_) {}
                        }
                    } catch(e) { console.error("Prefab Orbit:", e); }
                },
                toolTip: "Orbits the currently selected Prefab ID around you and deletes them when turned off."
            }),
            new ButtonInfo({
                buttonText: "ChristmasBox Orbit self",
                method: () => {
                    const center = AssemblyCSharp.class("AnimalCompany.PlayerController").method("get_instance").invoke().method("get_head").invoke();
                    function spawnorbitobject() {
                        orbiters = [];
                        for (let i = 0; i < 8; i++) {
                            let angle = Math.PI * 2 / 8 * i;
                            const offset = Vector3.alloc();
                            offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(angle) * 6.5, 0, Math.sin(angle) * 6.5);
                            let centerPos2 = center.method("get_position").invoke();
                            let spawnPos = Vector3.method("op_Addition").invoke(centerPos2, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                            let no = spawnNetworkPrefab("ChristmasBox", spawnPos, Quaternion.method("get_identity").invoke());
                            if (!no) continue;
                            orbitprefabs.push(no);
                            let go = no.method("get_gameObject").invoke();
                            if (!go) continue;
                            let tf = go.method("get_transform").invoke();
                            orbiters.push({ transform: tf, angle });
                        }
                    }
                    if (orbitprefabs.length < 4) spawnorbitobject();
                    let delta = Time.method("get_deltaTime").invoke();
                    let centerPos = center.method("get_position").invoke();
                    for (let orb of orbiters) {
                        orb.angle += 1.5 * delta;
                        const offset = Vector3.alloc();
                        offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(orb.angle) * 6.5, 0, Math.sin(orb.angle) * 6.5);
                        let newPos = Vector3.method("op_Addition").invoke(centerPos, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                        orb.transform.method("set_position").invoke(newPos);
                    }
                },
                disableMethod: () => {
                    for (let i = 0; i < orbitprefabs.length; i++) {
                        const prefab = orbitprefabs[i];
                        if (!prefab || prefab.isNull?.()) continue;
                        try {
                            const runner = prefab.method("get_Runner").invoke();
                            if (runner && !runner.isNull()) runner.method("Despawn").invoke(prefab);
                        } catch(_) {}
                    }
                    orbitprefabs = [];
                    orbiters = [];
                },
                isTogglable: true,
                toolTip: "Creates 8 Christmas boxes that orbit you."
            }),
            new ButtonInfo({
        buttonText: "Christmas Present Tower",
        method: () => {
          const center = AssemblyCSharp.class("AnimalCompany.PlayerController").method("get_instance").invoke().method("get_head").invoke();
          function spawnChristmasTower() {
            orbiters = [];
            const heights = [-6.0, -4.0, -2.0, 0.0, 2.0, 4.0, 6.0];
            for (let h = 0; h < heights.length; h++) {
              for (let i = 0; i < 12; i++) {
                const angle = (Math.PI * 2 / 12) * i;
                const offset = Vector3.alloc();
                offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(angle) * 4.8, heights[h], Math.sin(angle) * 4.8);
                const centerPos2 = center.method("get_position").invoke();
                const spawnPos = Vector3.method("op_Addition").invoke(centerPos2, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                const no = spawnNetworkPrefab("ChristmasBox", spawnPos, Quaternion.method("get_identity").invoke());
                if (!no) continue;
                orbitprefabs.push(no);
                const go = no.method("get_gameObject").invoke();
                if (!go) continue;
                const tf = go.method("get_transform").invoke();
                orbiters.push({ transform: tf, angle, height: heights[h] });
              }
            }
          }
          if (orbitprefabs.length < 10) spawnChristmasTower();
          const delta = Time.method("get_deltaTime").invoke();
          const centerPos = center.method("get_position").invoke();
          for (const orb of orbiters) {
            orb.angle += 0.85 * delta;
            const offset = Vector3.alloc();
            offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(orb.angle) * 4.8, orb.height, Math.sin(orb.angle) * 4.8);
            const newPos = Vector3.method("op_Addition").invoke(centerPos, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
            orb.transform.method("set_position").invoke(newPos);
          }
        },
        disableMethod: () => {
          for (let i = 0; i < orbitprefabs.length; i++) {
            const prefab = orbitprefabs[i];
            if (!prefab || prefab.isNull?.()) continue;
            try {
              const runner = prefab.method("get_Runner").invoke();
              if (runner && !runner.isNull()) runner.method("Despawn").invoke(prefab);
            } catch(_) {}
          }
          orbitprefabs = [];
          orbiters = [];
        },
        isTogglable: true,
        toolTip: "Creates a 7-story tower of Christmas presents around you."
      }),

            new ButtonInfo({
                buttonText: "Sellingmachine Orbit self",
                method: () => {
                    const center = AssemblyCSharp.class("AnimalCompany.PlayerController").method("get_instance").invoke().method("get_head").invoke();
                    function spawnorbitobject() {
                        orbiters = [];
                        for (let i = 0; i < 8; i++) {
                            let angle = Math.PI * 2 / 8 * i;
                            const offset = Vector3.alloc();
                            offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(angle) * 6.5, 0, Math.sin(angle) * 6.5);
                            let centerPos2 = center.method("get_position").invoke();
                            let spawnPos = Vector3.method("op_Addition").invoke(centerPos2, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                            let no = spawnNetworkPrefab("ItemSellingMachineController", spawnPos, Quaternion.method("get_identity").invoke());
                            if (!no) continue;
                            orbitprefabs.push(no);
                            let go = no.method("get_gameObject").invoke();
                            if (!go) continue;
                            let tf = go.method("get_transform").invoke();
                            orbiters.push({ transform: tf, angle });
                        }
                    }
                    if (orbitprefabs.length < 4) spawnorbitobject();
                    let delta = Time.method("get_deltaTime").invoke();
                    let centerPos = center.method("get_position").invoke();
                    for (let orb of orbiters) {
                        orb.angle += 1.5 * delta;
                        const offset = Vector3.alloc();
                        offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(orb.angle) * 6.5, 0, Math.sin(orb.angle) * 6.5);
                        let newPos = Vector3.method("op_Addition").invoke(centerPos, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                        orb.transform.method("set_position").invoke(newPos);
                    }
                },
                disableMethod: () => {
                    for (let i = 0; i < orbitprefabs.length; i++) {
                        const prefab = orbitprefabs[i];
                        if (!prefab || prefab.isNull?.()) continue;
                        try {
                            const runner = prefab.method("get_Runner").invoke();
                            if (runner && !runner.isNull()) runner.method("Despawn").invoke(prefab);
                        } catch(_) {}
                    }
                    orbitprefabs = [];
                    orbiters = [];
                },
                isTogglable: true,
                toolTip: "Creates 8 selling machines that orbit you."
            }),
            new ButtonInfo({
                buttonText: "Sellingmachine Tower Orbit",
                method: () => {
                    const center = AssemblyCSharp.class("AnimalCompany.PlayerController").method("get_instance").invoke().method("get_head").invoke();
                    function spawnSellingTowerOrbit() {
                        sellingTowerOrbiters = [];
                        const heights = [-4.0, 0.0, 4.0];
                        for (let h = 0; h < heights.length; h++) {
                            for (let i = 0; i < 24; i++) {
                                const angle = (Math.PI * 2 / 24) * i;
                                const offset = Vector3.alloc();
                                offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(angle) * 5.6, heights[h], Math.sin(angle) * 5.6);
                                const centerPos2 = center.method("get_position").invoke();
                                const spawnPos = Vector3.method("op_Addition").invoke(centerPos2, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                                const no = spawnNetworkPrefab("ItemSellingMachineController", spawnPos, Quaternion.method("get_identity").invoke());
                                if (!no) continue;
                                sellingTowerOrbitPrefabs.push(no);
                                const go = no.method("get_gameObject").invoke();
                                if (!go) continue;
                                const tf = go.method("get_transform").invoke();
                                sellingTowerOrbiters.push({ transform: tf, angle, height: heights[h] });
                            }
                        }
                    }
                    if (sellingTowerOrbitPrefabs.length < 10) spawnSellingTowerOrbit();
                    const delta = Time.method("get_deltaTime").invoke();
                    const centerPos = center.method("get_position").invoke();
                    for (const orb of sellingTowerOrbiters) {
                        orb.angle += 0.95 * delta;
                        const offset = Vector3.alloc();
                        offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(orb.angle) * 5.6, orb.height, Math.sin(orb.angle) * 5.6);
                        const newPos = Vector3.method("op_Addition").invoke(centerPos, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                        orb.transform.method("set_position").invoke(newPos);
                    }
                },
                disableMethod: () => {
                    sellingTowerOrbiters = [];
                    sellingTowerOrbitPrefabs = [];
                    sendNotification("Selling machine tower frozen in place", false);
                },
                isTogglable: true,
                toolTip: "Creates a dense 3-story selling machine orbit and leaves it in place when disabled."
            }),
            new ButtonInfo({
                buttonText: "Moon Buggy Orbit self",
                method: () => {
                    const center = AssemblyCSharp.class("AnimalCompany.PlayerController").method("get_instance").invoke().method("get_head").invoke();
                    function spawnBuggyOrbitObject() {
                        buggyOrbiters = [];
                        for (let i = 0; i < 8; i++) {
                            let angle = Math.PI * 2 / 8 * i;
                            const offset = Vector3.alloc();
                            offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(angle) * 7.0, 0.4, Math.sin(angle) * 7.0);
                            let centerPos2 = center.method("get_position").invoke();
                            let spawnPos = Vector3.method("op_Addition").invoke(centerPos2, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                            let no = spawnNetworkPrefab("Vehicle_Buggy", spawnPos, Quaternion.method("get_identity").invoke());
                            if (!no) continue;
                            buggyOrbitPrefabs.push(no);
                            let go = no.method("get_gameObject").invoke();
                            if (!go) continue;
                            let tf = go.method("get_transform").invoke();
                            buggyOrbiters.push({ transform: tf, angle });
                        }
                    }
                    if (buggyOrbitPrefabs.length < 4) spawnBuggyOrbitObject();
                    let delta = Time.method("get_deltaTime").invoke();
                    let centerPos = center.method("get_position").invoke();
                    for (let orb of buggyOrbiters) {
                        orb.angle += 1.15 * delta;
                        const offset = Vector3.alloc();
                        offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(orb.angle) * 7.0, 0.4, Math.sin(orb.angle) * 7.0);
                        let newPos = Vector3.method("op_Addition").invoke(centerPos, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                        orb.transform.method("set_position").invoke(newPos);
                    }
                },
                disableMethod: () => {
                    for (let i = 0; i < buggyOrbitPrefabs.length; i++) {
                        const prefab = buggyOrbitPrefabs[i];
                        if (!prefab || prefab.isNull?.()) continue;
                        try {
                            const runner = prefab.method("get_Runner").invoke();
                            if (runner && !runner.isNull()) runner.method("Despawn").invoke(prefab);
                        } catch(_) {}
                    }
                    buggyOrbitPrefabs = [];
                    buggyOrbiters = [];
                },
                isTogglable: true,
                toolTip: "Creates 8 buggies that orbit around you."
            }),
            new ButtonInfo({
                buttonText: "Tree Forest Orbit",
                method: () => {
                    const center = AssemblyCSharp.class("AnimalCompany.PlayerController").method("get_instance").invoke().method("get_head").invoke();
                    function spawnSharkOrbitObject() {
                        sharkOrbiters = [];
                        for (let i = 0; i < 10; i++) {
                            const angle = Math.PI * 2 / 10 * i;
                            const offset = Vector3.alloc();
                            offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(angle) * 6.0, 0.0, Math.sin(angle) * 6.0);
                            const centerPos2 = center.method("get_position").invoke();
                            const spawnPos = Vector3.method("op_Addition").invoke(centerPos2, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                            const no = spawnNetworkPrefab("ChoppableTreeManager", spawnPos, Quaternion.method("get_identity").invoke());
                            if (!no) continue;
                            sharkOrbitPrefabs.push(no);
                            const go = no.method("get_gameObject").invoke();
                            if (!go) continue;
                            const tf = go.method("get_transform").invoke();
                            sharkOrbiters.push({ transform: tf, angle });
                        }
                    }
                    if (sharkOrbitPrefabs.length < 4) spawnSharkOrbitObject();
                    const delta = Time.method("get_deltaTime").invoke();
                    const centerPos = center.method("get_position").invoke();
                    for (const orb of sharkOrbiters) {
                        orb.angle += 1.2 * delta;
                        const offset = Vector3.alloc();
                        offset.method(".ctor").overload("System.Single", "System.Single", "System.Single").invoke(Math.cos(orb.angle) * 6.0, 0.0, Math.sin(orb.angle) * 6.0);
                        const newPos = Vector3.method("op_Addition").invoke(centerPos, [offset.field("x").value, offset.field("y").value, offset.field("z").value]);
                        orb.transform.method("set_position").invoke(newPos);
                    }
                },
                disableMethod: () => {
                    for (const prefab of sharkOrbitPrefabs) {
                        if (!prefab || prefab.isNull?.()) continue;
                        try {
                            const runner = prefab.method("get_Runner").invoke();
                            if (runner && !runner.isNull()) runner.method("Despawn").invoke(prefab);
                        } catch(_) {}
                        try { destroyNetworkedObjectDeep(prefab); } catch(_) {}
                        try {
                            const go = prefab.method("get_gameObject").invoke();
                            if (go && !go.isNull?.()) Destroy(go);
                        } catch(_) {}
                    }
                    sharkOrbitPrefabs = [];
                    sharkOrbiters = [];
                },
                isTogglable: true,
                toolTip: "Creates a normal orbit of forest trees around you."
            }),
            new ButtonInfo({
                buttonText: "WL Selling Orbit Gun",
                disableMethod: () => {
                    for (const prefab of wlSellingOrbitPrefabs) {
                        if (!prefab || prefab.isNull?.()) continue;
                        try {
                            const runner = prefab.method("get_Runner").invoke();
                            if (runner && !runner.isNull()) { runner.method("Despawn").invoke(prefab); continue; }
                        } catch(_) {}
                        try {
                            const go = prefab.method("get_gameObject").invoke();
                            if (go && !go.isNull()) Destroy(go);
                        } catch(_) {}
                    }
                    wlSellingOrbitPrefabs = [];
                    wlSellingOrbitEntries = [];
                },
                isTogglable: true,
                method: () => {
                    try {
                        if (rightGrab) {
                            const gunData = renderGun();
                            if (rightTrigger && time > lagGunDelay) {
                                lagGunDelay = time + 0.18;
                                const target = getWhitelistGunTarget(gunData, true, 10.0);
                                if (target && target.player) {
                                    const already = wlSellingOrbitEntries.some(e => e.player && !e.player.isNull?.() && e.player.handle.equals(target.player.handle));
                                    if (!already) {
                                        for (let i = 0; i < 8; i++) {
                                            const spawned = spawnNetworkPrefab("ItemSellingMachineController", zeroVector, identityQuaternion);
                                            if (!spawned || spawned.isNull?.()) continue;
                                            wlSellingOrbitPrefabs.push(spawned);
                                            const go = spawned.method("get_gameObject").invoke();
                                            if (!go || go.isNull()) continue;
                                            const tf = go.method("get_transform").invoke();
                                            wlSellingOrbitEntries.push({ player: target.player, transform: tf, angle: (Math.PI * 2 / 8) * i });
                                        }
                                        sendNotification("Selling orbit added to " + target.id, false);
                                    }
                                }
                            }
                        }
                        for (const orb of wlSellingOrbitEntries) {
                            try {
                                const p = orb.player;
                                if (!p || p.isNull?.()) continue;
                                const pos = getTransform(p).method("get_position").invoke();
                                orb.angle += deltaTime * 1.8;
                                const x = (pos.field("x").value as number) + Math.cos(orb.angle) * 2.6;
                                const y = (pos.field("y").value as number) + 0.35 + Math.sin((orb.angle * 2.0) + time) * 0.18;
                                const z = (pos.field("z").value as number) + Math.sin(orb.angle) * 2.6;
                                orb.transform.method("set_position").invoke([x, y, z]);
                            } catch(_) {}
                        }
                    } catch(e) { console.error("WL Selling Orbit Gun:", e); }
                },
                toolTip: "Touches a WL player with the gun and makes selling machines orbit them."
            }),
            new ButtonInfo({
                buttonText: "WL Orbit All Target Gun",
                enableMethod: () => { wlOrbitAllTarget = null; wlOrbitAllPhase = 0; },
                disableMethod: () => { wlOrbitAllTarget = null; },
                isTogglable: true,
                method: () => {
                    try {
                        if (rightGrab) {
                            const gunData = renderGun();
                            if (rightTrigger && time > wlTargetActionDelay) {
                                wlTargetActionDelay = time + 0.25;
                                const target = getWhitelistGunTarget(gunData, true, 10.0);
                                if (target?.player) {
                                    wlOrbitAllTarget = target.player;
                                    sendNotification("Orbit target: " + target.id, false);
                                }
                            }
                        }
                        if (!wlOrbitAllTarget || wlOrbitAllTarget.isNull?.()) return;
                        const center = getTransform(wlOrbitAllTarget).method("get_position").invoke();
                        const others = getAllNetPlayersList(false);
                        wlOrbitAllPhase += deltaTime * 3.5;
                        let idx = 0;
                        for (const p of others) {
                            try {
                                if (!p || p.isNull?.()) continue;
                                if (normalizeSceneObjectHandle(p) === normalizeSceneObjectHandle(wlOrbitAllTarget)) continue;
                                const angle = wlOrbitAllPhase + ((Math.PI * 2 * idx) / Math.max(1, others.length));
                                p.method("RPC_Teleport").invoke([
                                    (center.field("x").value as number) + (Math.cos(angle) * 2.9),
                                    (center.field("y").value as number) + 1.15 + (Math.sin((time * 2.0) + idx) * 0.45),
                                    (center.field("z").value as number) + (Math.sin(angle) * 2.9)
                                ]);
                                idx++;
                            } catch(_) {}
                        }
                    } catch(e) { console.error("WL Orbit All Target Gun:", e); }
                },
                toolTip: "Aim a WL player once, then all players orbit them until toggled off."
            }),
        ],

        // ── CATEGORY 21: SOUNDBOARD ──────────────────────────────────────────
        [
            new ButtonInfo({
                buttonText: "Exit Soundboard",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to main menu."
            }),
            new ButtonInfo({
                buttonText: "Load G2Sounds",
                method: () => { soundboardAutoLoadDir("/sdcard/G2Sounds"); },
                isTogglable: false,
                toolTip: "Scannt /sdcard/G2Sounds/ und lädt alle .wav/.ogg/.mp3 automatisch."
            }),
            new ButtonInfo({
                buttonText: "Scan Clips",
                method: () => {
                    soundboardScanClips();
                    sendNotification("Scanned " + soundboardClips.length + " clips — see log", false, 4);
                    console.log("[Soundboard] clips found: " + soundboardClips.length);
                    for (let i = 0; i < soundboardClips.length; i++) {
                        console.log("[Soundboard]  [" + i + "] " + soundboardClips[i].name);
                    }
                },
                isTogglable: false,
                toolTip: "Scans all AudioSources in the scene and caches their clips. Check Frida log for clip list."
            }),
            new ButtonInfo({
                buttonText: "Prev Clip",
                method: () => {
                    if (soundboardClips.length === 0) { sendNotification("No clips — press Scan first", false); return; }
                    soundFileIndex = (soundFileIndex - 1 + soundboardClips.length) % soundboardClips.length;
                    sendNotification("[" + soundFileIndex + "] " + soundboardClips[soundFileIndex].name, false, 3);
                },
                isTogglable: false,
                toolTip: "Select previous clip."
            }),
            new ButtonInfo({
                buttonText: "Next Clip",
                method: () => {
                    if (soundboardClips.length === 0) { sendNotification("No clips — press Scan first", false); return; }
                    soundFileIndex = (soundFileIndex + 1) % soundboardClips.length;
                    sendNotification("[" + soundFileIndex + "] " + soundboardClips[soundFileIndex].name, false, 3);
                },
                isTogglable: false,
                toolTip: "Select next clip."
            }),
            new ButtonInfo({
                buttonText: "Play Clip",
                method: () => {
                    if (soundboardClips.length === 0) { sendNotification("No clips — Scan first", false); return; }
                    try {
                        const entry = soundboardClips[soundFileIndex];
                        if (!entry || !entry.clip || entry.clip.isNull?.()) { sendNotification("Clip invalid — rescan", false); return; }
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const headPos = getTransform(headCollider).method("get_position").invoke();
                        AuSrc.method("PlayClipAtPoint", 2).invoke(entry.clip, headPos);
                        sendNotification("Playing: " + entry.name, false, 3);
                    } catch(e) { sendNotification("PlayClip err: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Play the currently selected clip at your head position."
            }),
            new ButtonInfo({
                buttonText: "Play All Srcs",
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        let count = 0;
                        for (let i = 0; i < sources.length; i++) {
                            try { const s = sources.get(i); if (s && !s.isNull?.()) { s.method("Play").invoke(); count++; } } catch(_) {}
                        }
                        sendNotification("Triggered " + count + " AudioSources", false, 3);
                    } catch(e) { sendNotification("PlayAll err: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Calls Play() on every AudioSource in the scene simultaneously."
            }),
            new ButtonInfo({
                buttonText: "Stop All Srcs",
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        let count = 0;
                        for (let i = 0; i < sources.length; i++) {
                            try { const s = sources.get(i); if (s && !s.isNull?.()) { s.method("Stop").invoke(); count++; } } catch(_) {}
                        }
                        sendNotification("Stopped " + count + " AudioSources", false, 3);
                    } catch(e) { sendNotification("StopAll err: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Stops all currently playing AudioSources."
            }),
            new ButtonInfo({
                buttonText: "Vol +",
                method: () => {
                    soundboardVolume = Math.min(soundboardVolume + 0.1, 5.0);
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_volume").invoke(soundboardVolume); } catch(_) {}
                        }
                    } catch(_) {}
                    sendNotification("Volume: " + soundboardVolume.toFixed(1), false, 2);
                },
                isTogglable: false,
                toolTip: "Increase volume of all AudioSources by 0.1 (up to 5.0)."
            }),
            new ButtonInfo({
                buttonText: "Vol -",
                method: () => {
                    soundboardVolume = Math.max(soundboardVolume - 0.1, 0.0);
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_volume").invoke(soundboardVolume); } catch(_) {}
                        }
                    } catch(_) {}
                    sendNotification("Volume: " + soundboardVolume.toFixed(1), false, 2);
                },
                isTogglable: false,
                toolTip: "Decrease volume of all AudioSources by 0.1."
            }),
            new ButtonInfo({
                buttonText: "Pitch +",
                method: () => {
                    soundboardPitch = Math.min(soundboardPitch + 0.25, 4.0);
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_pitch").invoke(soundboardPitch); } catch(_) {}
                        }
                    } catch(_) {}
                    sendNotification("Pitch: " + soundboardPitch.toFixed(2), false, 2);
                },
                isTogglable: false,
                toolTip: "Raise pitch of all AudioSources by 0.25 (chipmunk effect)."
            }),
            new ButtonInfo({
                buttonText: "Pitch -",
                method: () => {
                    soundboardPitch = Math.max(soundboardPitch - 0.25, 0.1);
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_pitch").invoke(soundboardPitch); } catch(_) {}
                        }
                    } catch(_) {}
                    sendNotification("Pitch: " + soundboardPitch.toFixed(2), false, 2);
                },
                isTogglable: false,
                toolTip: "Lower pitch of all AudioSources by 0.25 (deep/slow effect)."
            }),
            new ButtonInfo({
                buttonText: "Reset Pitch/Vol",
                method: () => {
                    soundboardVolume = 1.0;
                    soundboardPitch  = 1.0;
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        for (let i = 0; i < sources.length; i++) {
                            try { const s = sources.get(i); s.method("set_volume").invoke(1.0); s.method("set_pitch").invoke(1.0); } catch(_) {}
                        }
                    } catch(_) {}
                    sendNotification("Volume & Pitch reset to 1.0", false, 2);
                },
                isTogglable: false,
                toolTip: "Resets volume and pitch on all AudioSources back to 1.0."
            }),
            new ButtonInfo({
                buttonText: "Loop Toggle",
                isTogglable: true,
                method: () => {
                    try {
                        const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
                        const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
                        const btn = getIndex("Loop Toggle");
                        const looping = btn?.enabled ?? false;
                        for (let i = 0; i < sources.length; i++) {
                            try { sources.get(i).method("set_loop").invoke(looping); } catch(_) {}
                        }
                        sendNotification("Loop: " + (looping ? "ON" : "OFF"), false, 2);
                    } catch(e) { sendNotification("Loop err: " + e, false); }
                },
                toolTip: "Toggle looping on all AudioSources."
            }),
        ],

        // ── CATEGORY 22: MOM BOSS ─────────────────────────────────────────
        [
            new ButtonInfo({
                buttonText: "Exit Mom Boss",
                method: () => { currentCategory = 0; currentPage = 0; },
                isTogglable: false,
                toolTip: "Returns to main menu."
            }),
            new ButtonInfo({
                buttonText: "Spawn Mom Boss",
                method: () => { momBossSpawnAtHand(); },
                isTogglable: false,
                toolTip: "Spawns Mom Boss prefab/item at your right hand."
            }),
            new ButtonInfo({
                buttonText: "Spawn Mom At Me",
                method: () => {
                    try {
                        const pos = getTransform(GTPlayer).method("get_position").invoke();
                        momBossSpawnAt(pos, identityQuaternion);
                    } catch(e) { sendNotification("Mom spawn failed: " + e, false); }
                },
                isTogglable: false,
                toolTip: "Spawns Mom Boss at your position."
            }),
            new ButtonInfo({
                buttonText: "Mom Boss to Me",
                method: () => {
                    try {
                        const pos = getTransform(GTPlayer).method("get_position").invoke();
                        const MomCls = AssemblyCSharp.class("AnimalCompany.MomBossController");
                        let inst: any = null;
                        try { inst = MomCls.field("_instance").value; } catch(_) {}
                        try {
                            if (!inst || inst.isNull?.())
                                inst = Object.method("FindObjectOfType", 0).inflate(MomCls).invoke();
                        } catch(_) {}
                        if (!inst || inst.isNull?.()) {
                            sendNotification("MomBoss not found — spawn her first", false, 3);
                            return;
                        }
                        const tf = getTransform(inst);
                        let teleported = false;
                        for (const name of ["Teleport","TeleportTo","SetPosition","NetworkTeleport","WarpTo","RPC_Teleport"]) {
                            try { inst.method(name).invoke(pos); teleported = true; break; } catch(_) {}
                            try { inst.method(name).invoke(pos, identityQuaternion); teleported = true; break; } catch(_) {}
                        }
                        if (!teleported) tf.method("set_position").invoke(pos);
                        try {
                            const go = inst.method("get_gameObject").invoke();
                            if (go && !go.isNull?.()) {
                                try { go.method("SetActive").invoke(true); } catch(_) {}
                                const RendererCls = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image.class("UnityEngine.Renderer");
                                const renders = go.method("GetComponentsInChildren", 1).inflate(RendererCls).invoke(true);
                                for (let ri = 0; renders && ri < renders.length; ri++) {
                                    try { renders.get(ri).method("set_enabled").invoke(true); } catch(_) {}
                                }
                            }
                        } catch(_) {}
                        sendNotification("Mom Boss teleported to you!", false, 3);
                    } catch(e) { sendNotification("Mom Boss to Me failed: " + e, false); console.error("[MomBossToMe]", e); }
                },
                isTogglable: false,
                toolTip: "Teleports the Mom Boss to your position."
            }),
            new ButtonInfo({
                buttonText: "Mom Reset Game",
                method: () => { momBossCall("ResetGame") || momBossCall("RPC_ResetGame"); },
                isTogglable: false,
                toolTip: "Calls MomBoss ResetGame / RPC_ResetGame."
            }),
            new ButtonInfo({
                buttonText: "Mom Easy Mode",
                method: () => { momBossSetField("_isEasyMode", true); },
                isTogglable: false,
                toolTip: "Sets Mom Boss _isEasyMode = true."
            }),
            new ButtonInfo({
                buttonText: "Mom Always Win",
                method: () => { momBossSetField("_isAlwaysWinMode", true); },
                isTogglable: false,
                toolTip: "Sets Mom Boss _isAlwaysWinMode = true."
            }),
            new ButtonInfo({
                buttonText: "Mom Toy Block",
                method: () => { momBossCall("SetToyBlockGameState") || momBossCall("TestP2ToyBlock"); },
                isTogglable: false,
                toolTip: "Forces Mom Boss into Toy Block game state."
            }),
            new ButtonInfo({
                buttonText: "Mom Simon Says",
                method: () => { momBossCall("SetSimonSaysGameState") || momBossCall("TestP2SimonSays"); },
                isTogglable: false,
                toolTip: "Forces Mom Boss into Simon Says game state."
            }),
            new ButtonInfo({
                buttonText: "Mom Floor Slap",
                method: () => { momBossCall("SetFloorSlappingGameState") || momBossCall("TestP3FloorSlap"); },
                isTogglable: false,
                toolTip: "Forces Mom Boss into Floor Slapping game state."
            }),
            new ButtonInfo({
                buttonText: "Mom Blade Ball",
                method: () => { momBossCall("SetBladeBallGameState") || momBossCall("TestP4BladeBall"); },
                isTogglable: false,
                toolTip: "Forces Mom Boss into Blade Ball game state."
            }),
            new ButtonInfo({
                buttonText: "Mom Summon Zombies",
                method: () => { momBossCall("SummonZombies") || momBossCall("SetSummonZombiesP3GameState"); },
                isTogglable: false,
                toolTip: "Calls Mom Boss SummonZombies."
            }),
            new ButtonInfo({
                buttonText: "Mom Kill Zombies",
                method: () => { momBossCall("KillAllZombies"); },
                isTogglable: false,
                toolTip: "Calls Mom Boss KillAllZombies."
            }),
            new ButtonInfo({
                buttonText: "Mom Supply Burst",
                method: () => { momSupplyBurst(); },
                isTogglable: false,
                toolTip: "MomBossItemSpawner.SpawnSupplyItems — or spawns fallback supply items."
            }),
            new ButtonInfo({
                buttonText: "Mom Success",
                method: () => { momBossCall("SetGameSuccessGameState") || momBossCall("TestP2Success"); },
                isTogglable: false,
                toolTip: "Forces Mom Boss success state."
            }),
            new ButtonInfo({
                buttonText: "Mom Death",
                method: () => { momBossCall("SetDeathGameState") || momBossCall("SetFatalHitGameState"); },
                isTogglable: false,
                toolTip: "Forces Mom Boss death/fatal hit state."
            }),
            new ButtonInfo({
                buttonText: "Horde On",
                method: () => { hordeControl(true); },
                isTogglable: false,
                toolTip: "Activates HordeMobController and HordeMobSpawner."
            }),
            new ButtonInfo({
                buttonText: "Horde Off",
                method: () => { hordeControl(false); },
                isTogglable: false,
                toolTip: "Deactivates HordeMobController and HordeMobSpawner."
            }),
        ],
    ];


    
    // ── MOM BOSS: helpers ────────────────────────────────────────────────
    function getMomBoss(): any {
        try {
            const MomCls = AssemblyCSharp.class("AnimalCompany.MomBossController");
            let inst: any = null;
            try { inst = MomCls.field("_instance").value; } catch(_) {}
            if (!inst || inst.isNull?.())
                try { inst = Object.method("FindObjectOfType", 0).inflate(MomCls).invoke(); } catch(_) {}
            return (inst && !inst.isNull?.()) ? inst : null;
        } catch(_) { return null; }
    }

    function momBossCall(method: string, ...args: any[]): boolean {
        try {
            const m = getMomBoss();
            if (!m) { sendNotification("Mom Boss not found", false, 2); return false; }
            m.method(method).invoke(...args);
            sendNotification("MomBoss: " + method, false, 2);
            return true;
        } catch(e) {
            sendNotification("MomBoss " + method + " failed", false, 2);
            console.error("[MomBoss]", method, e);
            return false;
        }
    }

    function momBossSetField(field: string, value: any): boolean {
        try {
            const m = getMomBoss();
            if (!m) return false;
            m.field(field).value = value;
            sendNotification("Mom " + field + " = " + value, false, 2);
            return true;
        } catch(e) { console.error("[Mom field]", field, e); return false; }
    }

    function momBossSpawnAt(pos: any, rot: any): boolean {
        try {
            const names = ["MomBossController", "mom_pillow", "item_momboss_box", "MomToyBlockObject"];
            for (const n of names) {
                const spawned = n.startsWith("item_")
                    ? spawnItemAtPos(n, pos, rot)
                    : spawnNetworkPrefab(n, pos, rot);
                if (spawned) { sendNotification("Mom spawn: " + n, false, 2); return true; }
            }
        } catch(e) { console.error("[SpawnMomBossAt]", e); }
        sendNotification("Mom spawn failed", false, 2);
        return false;
    }

    function momBossSpawnAtHand(): boolean {
        try {
            const pos = rightHandTransform.method("get_position").invoke();
            const rot = rightHandTransform.method("get_rotation").invoke();
            return momBossSpawnAt(pos, rot);
        } catch(e) { console.error("[SpawnMomBoss]", e); }
        sendNotification("Mom spawn failed", false, 2);
        return false;
    }

    function momSupplyBurst(): void {
        let c = 0;
        try {
            const m = getMomBoss();
            if (m) {
                let sp: any = null;
                try { sp = m.method("get_itemSpawner").invoke(); } catch(_) {}
                if (sp && !sp.isNull?.()) {
                    try { sp.method("SpawnSupplyItems").invoke(); c++; } catch(_) {}
                    try { sp.method("SpawnItems").invoke(["item_arena_pistol","item_shotgun_ammo","item_company_ration_heal"], 5, 5.0); c++; } catch(_) {}
                }
            }
        } catch(e) { console.error("[MomSupply]", e); }
        if (!c) {
            const pos = rightHandTransform.method("get_position").invoke();
            for (const id of ["item_arena_pistol","item_shotgun_ammo","item_company_ration_heal","item_rpg_ammo"]) {
                for (let i = 0; i < 4; i++) {
                    try {
                        const p = pos as number[];
                        spawnItemAtPos(id, [
                            (p[0] || 0) + (Math.random() - 0.5) * 1.5,
                            (p[1] || 0) + Math.random(),
                            (p[2] || 0) + (Math.random() - 0.5) * 1.5
                        ], identityQuaternion);
                    } catch(_) {}
                }
            }
        }
        sendNotification("Mom supplies: " + (c || "fallback"), false, 2);
    }

    function hordeControl(active: boolean): void {
        let c = 0;
        const fields: Record<string, any> = active
            ? { _n_isActive: true, _n_mobCountToSpawn: 64, _ignoreLootDrop: false }
            : { _n_isActive: false, _n_mobCountToSpawn: 0 };
        const spawnerFields: Record<string, any> = { _enableTest: active, _testAutoWave: active, _autoKillFromThisPlayer: !active };

        for (const clsName of ["AnimalCompany.HordeMobController"]) {
            try {
                const cls = AssemblyCSharp.class(clsName);
                const all = Object.method("FindObjectsByType", 1).inflate(cls).invoke(0);
                for (let i = 0; all && i < all.length; i++) {
                    try {
                        const obj = all.get(i);
                        for (const [k, v] of Object.entries(fields)) { try { obj.field(k).value = v; } catch(_) {} }
                        c++;
                    } catch(_) {}
                }
            } catch(_) {}
        }
        for (const clsName of ["AnimalCompany.HordeMobSpawner"]) {
            try {
                const cls = AssemblyCSharp.class(clsName);
                const all = Object.method("FindObjectsByType", 1).inflate(cls).invoke(0);
                for (let i = 0; all && i < all.length; i++) {
                    try {
                        const obj = all.get(i);
                        for (const [k, v] of Object.entries(spawnerFields)) { try { obj.field(k).value = v; } catch(_) {} }
                        c++;
                    } catch(_) {}
                }
            } catch(_) {}
        }
        sendNotification("Horde " + (active ? "on" : "off") + ": " + c, false, 2);
    }

    // ── SOUNDBOARD: clip scanner ──────────────────────────────────────────
    function soundboardScanClips() {
        soundboardClips = [];
        soundboardScanDone = false;
        try {
            const AuSrc = Il2Cpp.domain.assembly("UnityEngine.AudioModule").image.class("UnityEngine.AudioSource");
            const sources = Object.method("FindObjectsByType", 1).inflate(AuSrc).invoke(0);
            const seen = new Set<string>();
            for (let i = 0; i < sources.length; i++) {
                try {
                    const s = sources.get(i);
                    if (!s || s.isNull?.()) continue;
                    const clip = s.method("get_clip").invoke();
                    if (!clip || clip.isNull?.()) continue;
                    const name: string = clip.method("get_name").invoke()?.content ?? ("clip_" + i);
                    if (seen.has(name)) continue;
                    seen.add(name);
                    soundboardClips.push({ name, clip });
                } catch(_) {}
            }
            soundboardScanDone = true;
            soundFileIndex = 0;
        } catch(e) { console.error("[Soundboard] scan error:", e); }
    }

    async function soundboardLoadFile(filePath: string): Promise<void> {
        try {
            const UWRMM = Il2Cpp.domain.assembly("UnityEngine.UnityWebRequestAudioModule").image
                .class("UnityEngine.Networking.UnityWebRequestMultimedia");
            const ext = filePath.split(".").pop()?.toLowerCase() ?? "";
            const audioType = ext === "ogg" ? 0x14 : ext === "mp3" ? 0x07 : 0x0D;
            const url = Il2Cpp.string("file://" + filePath);
            const req = UWRMM.method("GetAudioClip", 2).invoke(url, audioType);
            req.method("SendWebRequest").invoke();
            let waited = 0;
            while (!req.method("get_isDone").invoke() && waited < 5000) {
                await new Promise(r => setTimeout(r, 100));
                waited += 100;
            }
            if (!req.method("get_isDone").invoke()) { sendNotification("Timeout: " + filePath.split("/").pop(), false, 4); return; }
            const error: string = req.method("get_error").invoke()?.content ?? "";
            if (error && error.length > 0) { sendNotification("Load err: " + error, false, 4); return; }
            const DownloadHandlerAC = Il2Cpp.domain.assembly("UnityEngine.UnityWebRequestAudioModule").image
                .class("UnityEngine.Networking.DownloadHandlerAudioClip");
            const clip = DownloadHandlerAC.method("GetContent", 1).invoke(req);
            if (!clip || clip.isNull?.()) { sendNotification("Clip null: " + filePath.split("/").pop(), false, 4); return; }
            const clipName = filePath.split("/").pop() ?? filePath;
            soundboardClips = soundboardClips.filter(c => c.name !== clipName);
            soundboardClips.push({ name: clipName, clip });
            soundFileIndex = soundboardClips.length - 1;
            sendNotification("Loaded: " + clipName, false, 3);
            console.log("[Soundboard] loaded: " + clipName + " → index " + soundFileIndex);
        } catch(e) {
            sendNotification("LoadFile err: " + e, false, 4);
            console.error("[Soundboard] loadFile error:", e);
        }
    }

    function soundboardListDir(dirPath: string): string[] {
        const results: string[] = [];
        try {
            const Mod = Module as any;

            const libcNames = ["libc.so", "libc.so.6"];
            let opendirPtr: any = null, readdirPtr: any = null, closedirPtr: any = null;

            for (const lib of libcNames) {
                try {
                    opendirPtr  = Mod.findExportByName(lib, "opendir");
                    readdirPtr  = Mod.findExportByName(lib, "readdir");
                    closedirPtr = Mod.findExportByName(lib, "closedir");
                    if (opendirPtr && readdirPtr && closedirPtr) break;
                } catch(_) {}
            }

            if (!opendirPtr)  opendirPtr  = Mod.findExportByName(null, "opendir");
            if (!readdirPtr)  readdirPtr  = Mod.findExportByName(null, "readdir");
            if (!closedirPtr) closedirPtr = Mod.findExportByName(null, "closedir");

            if (!opendirPtr || !readdirPtr || !closedirPtr) {
                console.error("[Soundboard] listDir: libc exports not found");
                return results;
            }

            const opendir  = new NativeFunction(opendirPtr,  "pointer", ["pointer"]);
            const readdir  = new NativeFunction(readdirPtr,  "pointer", ["pointer"]);
            const closedir = new NativeFunction(closedirPtr, "int",     ["pointer"]);

            const pathBuf = Memory.allocUtf8String(dirPath);
            const dir = opendir(pathBuf) as NativePointer;

            if ((dir as NativePointer).isNull()) {
                console.error("[Soundboard] listDir: opendir failed — path missing or no permission: " + dirPath);
                return results;
            }

            // dirent on Android/ARM64: ino(8) off(8) reclen(2) type(1) name(256)
            const DT_REG     = 8;
            const DT_UNKNOWN = 0;

            while (true) {
                const entry = readdir(dir) as NativePointer;
                if ((entry as NativePointer).isNull()) break;
                const d_type = (entry as NativePointer).add(18).readU8();
                const d_name = (entry as NativePointer).add(19).readUtf8String() ?? "";
                if (!d_name || d_name === "." || d_name === "..") continue;
                if (d_type === DT_REG || d_type === DT_UNKNOWN) {
                    results.push(dirPath.replace(/\/+$/, "") + "/" + d_name);
                }
            }

            closedir(dir);
            console.log("[Soundboard] listDir: " + results.length + " files found in " + dirPath);
        } catch(e) {
            console.error("[Soundboard] listDir error:", e);
        }
        return results;
    }

    async function soundboardAutoLoadDir(dirPath: string): Promise<void> {
        try {
            const files = soundboardListDir(dirPath);
            if (files.length === 0) {
                sendNotification("Folder empty or not found: " + dirPath, false, 4);
                return;
            }

            const validExts = [".wav", ".ogg", ".mp3"];
            let loaded = 0;
            let skipped = 0;

            for (const filePath of files) {
                try {
                    const ext = "." + (filePath.split(".").pop()?.toLowerCase() ?? "");
                    if (!validExts.includes(ext)) { skipped++; continue; }
                    await soundboardLoadFile(filePath);
                    loaded++;
                } catch(_) { skipped++; }
            }

            sendNotification("G2Sounds: " + loaded + " loaded, " + skipped + " skipped", false, 5);
            console.log("[Soundboard] autoload done — " + loaded + " clips total");
        } catch(e) {
            sendNotification("AutoLoad err: " + e, false, 4);
            console.error("[Soundboard] autoLoadDir error:", e);
        }
    }

    let buttonMap: Map<string, ButtonInfo> = new Map();
    function rebuildButtonMap() {
        buttonMap = new Map();
        buttons.flat().forEach(button => { buttonMap.set(button.buttonText, button); });
    }
    rebuildButtonMap();

    function getIndex(buttonText: string): ButtonInfo {
        let button = buttonMap.get(buttonText);
        if (!button) {
            rebuildButtonMap();
            button = buttonMap.get(buttonText);
        }
        return button;
    }

    
    const ButtonActivation = GorillaReportButton.method("OnTriggerEnter");
    ButtonActivation.implementation = function (collider) {
        const rawName = this.method("get_name").invoke().toString();
        if (rawName.length > 1 && rawName[1] == "@") {
            if (collider.handle.equals(referenceCollider.handle)) {
                const goName = rawName.substring(2, rawName.length - 1);
                const _time = Time.method("get_time").invoke();
                if (_time > buttonClickDelay) {
                    buttonClickDelay = _time + 0.2;
                    const button = getIndex(goName);
                    if (button) {
                        if (button.isTogglable) {
                            button.enabled = !button.enabled;
                            reloadMenu();
                            if (button.enabled) {
                                if (button.toolTip) sendNotification("[ENABLE] " + button.toolTip, false);
                                try { button.enableMethod?.(); } catch(e) { button.enabled = false; console.error(`[Toggle Enable] ${button.buttonText}:`, e); }
                            } else {
                                if (button.toolTip) sendNotification("[DISABLE] " + button.toolTip, false);
                                try { button.disableMethod?.(); } catch(e) { console.error(`[Toggle Disable] ${button.buttonText}:`, e); }
                            }
                        } else {
                            try { button.method?.(); } catch(e) { console.error(`[Button] ${button.buttonText}:`, e); }
                            reloadMenu();
                            if (button.toolTip) sendNotification(button.toolTip, false);
                        }
                    }
                }
            }
            return;
        }
        return this.method("OnTriggerEnter").invoke(collider);
    };

    let cachedCommonUsageNames: string[] | null = null;

    
    function updateInput() {
        const leftNode = typeof XRNode !== "undefined" && XRNode.LeftHand != null ? XRNode.LeftHand : 4;
        const rightNode = typeof XRNode !== "undefined" && XRNode.RightHand != null ? XRNode.RightHand : 5;
        const leftDevice  = InputDevices.method("GetDeviceAtXRNode", 1).invoke(leftNode);
        const rightDevice = InputDevices.method("GetDeviceAtXRNode", 1).invoke(rightNode);
        const outBool = Il2Cpp.alloc(1);
        const outVec2 = Il2Cpp.alloc(8);
        function readAxis2D(device: any): [number, number] {
            try {
                if (!device) return [0, 0];
                try {
                    if (typeof device.isNull === 'function' && device.isNull()) return [0, 0];
                } catch(_) {}

                const readUsage = (usage: any): [number, number] => {
                    try {
                        outVec2.writeFloat(0);
                        outVec2.add(4).writeFloat(0);
                        const ok = device.method("TryGetFeatureValue", 2).invoke(usage, outVec2);
                        if (!ok) return [0, 0];
                        const x = outVec2.readFloat();
                        const y = outVec2.add(4).readFloat();
                        return [axisDeadzone(x), axisDeadzone(y)];
                    } catch(_) {
                        return [0, 0];
                    }
                };

                if (!cachedCommonUsageNames) {
                    try {
                        cachedCommonUsageNames = CommonUsages.class.fields
                            .filter((f: any) => f.isStatic)
                            .map((f: any) => f.name || "");
                    } catch(_) {
                        cachedCommonUsageNames = [];
                    }
                }

                const axisNames = [
                    "primary2DAxis", "secondary2DAxis", "thumbstick", "joystick",
                    "touchpad", "primaryTouchpad", "secondaryTouchpad", "stick"
                ];
                const dynamicAxisNames = (cachedCommonUsageNames || [])
                    .filter((name: string) => /2daxis|axis|stick|joystick|thumbpad|touchpad|thumb/i.test(name));
                const candidatesToTry = Array.from(new Set([...axisNames, ...dynamicAxisNames]));

                const candidates: [number, number][] = [];
                for (const name of candidatesToTry) {
                    try {
                        const usage = CommonUsages.field(name).value;
                        candidates.push(readUsage(usage));
                    } catch(_) {
                    }
                }
                let best: [number, number] = [0, 0];
                let bestMag = 0;
                for (const candidate of candidates) {
                    const mag = Math.abs(candidate[0]) + Math.abs(candidate[1]);
                    if (mag > bestMag) {
                        best = candidate;
                        bestMag = mag;
                    }
                }
                return best;
            } catch(_) {
            }
            return [0, 0];
        }
        leftDevice.method("TryGetFeatureValue", 2).invoke(CommonUsages.field("primaryButton").value,    outBool); leftPrimary   = outBool.readU8() !== 0;
        leftDevice.method("TryGetFeatureValue", 2).invoke(CommonUsages.field("secondaryButton").value,  outBool); leftSecondary = outBool.readU8() !== 0;
        leftDevice.method("TryGetFeatureValue", 2).invoke(CommonUsages.field("gripButton").value,       outBool); leftGrab      = outBool.readU8() !== 0;
        leftDevice.method("TryGetFeatureValue", 2).invoke(CommonUsages.field("triggerButton").value,    outBool); leftTrigger   = outBool.readU8() !== 0;
        leftDevice.method("TryGetFeatureValue", 2).invoke(CommonUsages.field("primary2DAxisClick").value, outBool); leftStick   = outBool.readU8() !== 0;
        rightDevice.method("TryGetFeatureValue", 2).invoke(CommonUsages.field("primaryButton").value,   outBool); rightPrimary  = outBool.readU8() !== 0;
        rightDevice.method("TryGetFeatureValue", 2).invoke(CommonUsages.field("secondaryButton").value, outBool); rightSecondary = outBool.readU8() !== 0;
        rightDevice.method("TryGetFeatureValue", 2).invoke(CommonUsages.field("triggerButton").value,   outBool); rightTrigger  = outBool.readU8() !== 0;
        rightDevice.method("TryGetFeatureValue", 2).invoke(CommonUsages.field("gripButton").value,      outBool); rightGrab     = outBool.readU8() !== 0;
        rightDevice.method("TryGetFeatureValue", 2).invoke(CommonUsages.field("primary2DAxisClick").value, outBool); rightStick = outBool.readU8() !== 0;
        [leftStickX, leftStickY] = readAxis2D(leftDevice);
        [rightStickX, rightStickY] = readAxis2D(rightDevice);
    }

    
    let LateUpdate: any = null;
    const updateHookCandidates = [
        { klass: PCClass, label: "PlayerController", names: ["LateUpdate", "Update"] },
        { klass: GTPlayerClass, label: "GorillaLocomotion", names: ["LateUpdate", "Update"] },
        { klass: NetPlayer, label: "NetPlayer", names: ["LateUpdate", "Update"] },
        { klass: PCClass, label: "PlayerController", names: ["FixedUpdate", "OnUpdate", "Tick", "PlayerUpdate", "LocomotionUpdate"] },
        { klass: GTPlayerClass, label: "GorillaLocomotion", names: ["FixedUpdate", "OnUpdate", "Tick", "PlayerUpdate", "LocomotionUpdate"] },
        { klass: NetPlayer, label: "NetPlayer", names: ["FixedUpdate", "OnUpdate", "Tick", "PlayerUpdate", "LocomotionUpdate"] }
    ];
    for (const candidate of updateHookCandidates) {
        for (const name of candidate.names) {
            try {
                LateUpdate = candidate.klass.method(name);
                console.log("[hook] Found update method: " + candidate.label + "." + name);
                break;
            } catch(_) {}
        }
        if (LateUpdate) break;
    }
    if (!LateUpdate) {
        console.error("[hook] No update method found anywhere, menu will not tick");
    }
    if (LateUpdate) LateUpdate.implementation = function () {
        try {
        checkLobbyChange();
        if (!refreshRuntimeRefs()) {
            runtimeRefMissCount++;
            if (runtimeRefMissCount === 1 || runtimeRefMissCount % 120 === 0) {
                console.warn("[LateUpdate] Runtime refs unavailable; keeping cached state and skipping this frame");
            }
            return LateUpdate.invoke();
        }
        runtimeRefMissCount = 0;
        deltaTime = Time.method("get_deltaTime").invoke();
        time      = Time.method("get_time").invoke();

        
        menuAnimTime += deltaTime;
        if (themeMode === 0) {
            
            const pulse = (Math.sin(menuAnimTime * 2.5) * 0.5 + 0.5) * 0.12;
            bgColor     = [0.02, 0.05 + pulse * 0.3, 0.25 + pulse, 0.85];
            buttonColor = [0.10 + pulse * 0.4, 0.18 + pulse * 0.6, 0.55 + pulse, 0.85];
            textColor   = [0.80, 0.88 + pulse * 0.4, 1.0, 1.0];
        } else if (themeMode === 1) {
            
            const h = (menuAnimTime * 0.25) % 1.0;
            const rr = Math.abs(Math.sin(h * Math.PI * 2)) ;
            const rg = Math.abs(Math.sin((h + 0.333) * Math.PI * 2));
            const rb2 = Math.abs(Math.sin((h + 0.666) * Math.PI * 2));
            const pulse = (Math.sin(menuAnimTime * 3.0) * 0.5 + 0.5) * 0.06;
            bgColor            = [rr * 0.18 + pulse * 0.03, rg * 0.18 + pulse * 0.03, rb2 * 0.18 + pulse * 0.03, 0.92];
            buttonColor        = [rr * 0.55 + pulse, rg * 0.55 + pulse, rb2 * 0.55 + pulse, 0.88];
            buttonPressedColor = [rr, rg, rb2, 1.0];
            textColor          = [0.95, 0.95, 0.95, 1.0];
        } else if (themeMode === 2) {
            
            const pulse2 = (Math.sin(menuAnimTime * 3.0) * 0.5 + 0.5) * 0.2;
            bgColor     = [0.0, 0.05 + pulse2 * 0.2, 0.0, 0.85];
            buttonColor = [0.0, 0.25 + pulse2, 0.0, 0.85];
            textColor   = [0.2, 1.0, 0.2, 1.0];
        } else if (themeMode === 3) {
            
            const pulse3 = (Math.sin(menuAnimTime * 2.0) * 0.5 + 0.5) * 0.15;
            bgColor     = [0.15 + pulse3, 0.0, 0.0, 0.85];
            buttonColor = [0.4 + pulse3, 0.0, 0.0, 0.85];
            textColor   = [1.0, 0.3, 0.3, 1.0];
        } else if (themeMode === 4) {
            
            const pulse4 = (Math.sin(menuAnimTime * 2.0) * 0.5 + 0.5) * 0.1;
            bgColor            = [0.22 + pulse4 * 0.35, 0.08 + pulse4 * 0.18, 0.0, 0.9];
            buttonColor        = [0.90 + pulse4 * 0.5, 0.35 + pulse4 * 0.35, 0.0, 0.92];
            buttonPressedColor = [1.0, 0.60 + pulse4 * 0.25, 0.08, 1.0];
            textColor          = [1.0, 0.90, 0.72, 1.0];
        } else if (themeMode === 5) {
            const pulse5 = (Math.sin(menuAnimTime * 3.4) * 0.5 + 0.5) * 0.18;
            bgColor            = [0.02, 0.12 + pulse5 * 0.18, 0.0, 0.9];
            buttonColor        = [0.28 + pulse5 * 0.35, 0.92, 0.02 + pulse5 * 0.14, 0.94];
            buttonPressedColor = [0.74, 1.0, 0.18, 1.0];
            textColor          = [0.95, 1.0, 0.78, 1.0];
        } else if (themeMode === 6) {
            const pulse6 = (Math.sin(menuAnimTime * 2.8) * 0.5 + 0.5) * 0.18;
            bgColor            = [0.24 + pulse6 * 0.16, 0.04, 0.12 + pulse6 * 0.08, 0.9];
            buttonColor        = [1.0, 0.28 + pulse6 * 0.18, 0.52 + pulse6 * 0.18, 0.92];
            buttonPressedColor = [1.0, 0.62, 0.26, 1.0];
            textColor          = [1.0, 0.92, 0.86, 1.0];
        } else if (themeMode === 7) {
            const pulse7 = (Math.sin(menuAnimTime * 3.1) * 0.5 + 0.5) * 0.16;
            bgColor            = [0.0, 0.10 + pulse7 * 0.08, 0.16 + pulse7 * 0.18, 0.9];
            buttonColor        = [0.12 + pulse7 * 0.12, 0.74 + pulse7 * 0.2, 1.0, 0.92];
            buttonPressedColor = [0.72, 0.94, 1.0, 1.0];
            textColor          = [0.90, 0.99, 1.0, 1.0];
        } else if (themeMode === 8) {
            const pulse8 = (Math.sin(menuAnimTime * 2.1) * 0.5 + 0.5) * 0.12;
            bgColor            = [0.02 + pulse8 * 0.04, 0.02 + pulse8 * 0.04, 0.02 + pulse8 * 0.02, 0.95];
            buttonColor        = [0.66 + pulse8 * 0.28, 0.48 + pulse8 * 0.22, 0.12, 0.94];
            buttonPressedColor = [1.0, 0.86, 0.28, 1.0];
            textColor          = [1.0, 0.94, 0.74, 1.0];
        } else if (themeMode === 9) {
            const pulse9 = (Math.sin(menuAnimTime * 3.6) * 0.5 + 0.5) * 0.18;
            bgColor            = [0.10 + pulse9 * 0.08, 0.0, 0.16 + pulse9 * 0.1, 0.9];
            buttonColor        = [0.74 + pulse9 * 0.18, 0.22 + pulse9 * 0.12, 1.0, 0.94];
            buttonPressedColor = [0.94, 0.56, 1.0, 1.0];
            textColor          = [0.98, 0.92, 1.0, 1.0];
        } else if (themeMode === 10) {
            // 10101 — pure binary black/green
            const p10 = (Math.sin(menuAnimTime * 4.0) * 0.5 + 0.5) * 0.06;
            bgColor            = [0.0,  0.0,  0.0,  0.98];
            buttonColor        = [0.0,  0.04 + p10, 0.0,  0.97];
            buttonPressedColor = [0.0,  0.88, 0.18, 1.0];
            textColor          = [0.0,  1.0,  0.18, 1.0];
        }

        // — process matrix setup queue: 3 objects per frame, no spike
        try {
            if (matrixSetupQueue.length > 0) {
                const batch = Math.min(3, matrixSetupQueue.length);
                for (let q = 0; q < batch; q++) {
                    try {
                        const item = matrixSetupQueue.shift();
                        if (!item) continue;
                        const ref = renderMenuTextRet(item.textRoot, item.surface, item.char, item.color, item.pos, item.size);
                        if (ref) {
                            if (item.isBg) matrixRainObjs.push(ref);
                            else matrixBtnObjs.push(ref);
                        }
                    } catch(_) {}
                }
            }
        } catch(_) {}

        // — matrix rain animation (background + buttons)
        try {
            if (time >= matrixRainNextUpdate) {
                matrixRainNextUpdate = time + 0.08;
                const rainChars = ["0","1","0","1","1","0"," "," ","0","1"];
                // background chars
                if (matrixRainObjs.length > 0) {
                    const updateCount = Math.max(1, Math.floor(matrixRainObjs.length * 0.2));
                    for (let r = 0; r < updateCount; r++) {
                        try {
                            const idx = Math.floor(Math.random() * matrixRainObjs.length);
                            const obj = matrixRainObjs[idx];
                            if (!obj || obj.isNull?.()) continue;
                            const char = rainChars[Math.floor(Math.random() * rainChars.length)];
                            const bright = char === " " ? 0.0 : (0.35 + Math.random() * 0.65);
                            setTextColorSafe(obj, [0.0, bright, 0.0, bright > 0 ? 0.75 : 0.0]);
                            try {
                                const tmp = getComponent(obj, TextMeshPro3D);
                                if (tmp && !tmp.isNull?.()) { try { tmp.method("SetText", 1).invoke(Il2Cpp.string(char)); } catch(_) { tmp.method("set_text").invoke(Il2Cpp.string(char)); } }
                                else { const tm = getComponent(obj, TextMesh); if (tm && !tm.isNull?.()) tm.method("set_text").invoke(Il2Cpp.string(char)); }
                            } catch(_) {}
                        } catch(_) {}
                    }
                }
                // button chars — update all of them each tick, faster flicker
                if (matrixBtnObjs.length > 0) {
                    const btnUpdate = Math.max(1, Math.floor(matrixBtnObjs.length * 0.5));
                    for (let r = 0; r < btnUpdate; r++) {
                        try {
                            const idx = Math.floor(Math.random() * matrixBtnObjs.length);
                            const obj = matrixBtnObjs[idx];
                            if (!obj || obj.isNull?.()) continue;
                            const char = Math.random() > 0.3 ? (Math.random() > 0.5 ? "1" : "0") : " ";
                            const bright = char === " " ? 0.0 : (0.4 + Math.random() * 0.6);
                            setTextColorSafe(obj, [0.0, bright, 0.05, char === " " ? 0.0 : 1.0]);
                            try {
                                const tmp = getComponent(obj, TextMeshPro3D);
                                if (tmp && !tmp.isNull?.()) { try { tmp.method("SetText", 1).invoke(Il2Cpp.string(char)); } catch(_) { tmp.method("set_text").invoke(Il2Cpp.string(char)); } }
                                else { const tm = getComponent(obj, TextMesh); if (tm && !tm.isNull?.()) tm.method("set_text").invoke(Il2Cpp.string(char)); }
                            } catch(_) {}
                        } catch(_) {}
                    }
                }
            }
        } catch(_) {}

        updateLiveMenuThemeVisuals();

        

        for (let i = lockedItems.length - 1; i >= 0; i--) {
            try {
                const li = lockedItems[i];
                if (!li || li.isNull()) { lockedItems.splice(i, 1); continue; }
                getTransform(li).method("set_position").invoke(li._lockedPos);
            } catch(_) { lockedItems.splice(i, 1); }
        }
        for (let i = spawnedGoopObjects.length - 1; i >= 0; i--) {
            try {
                const entry = spawnedGoopObjects[i];
                if (!entry || !entry.object || entry.object.isNull?.() || time >= entry.expireAt) {
                    try {
                        if (entry?.object && !entry.object.isNull?.()) {
                            let go = entry.object;
                            try {
                                const maybeGo = entry.object.method("get_gameObject").invoke();
                                if (maybeGo && !maybeGo.isNull?.()) go = maybeGo;
                            } catch(_) {}
                            Destroy(go);
                        }
                    } catch(_) {}
                    spawnedGoopObjects.splice(i, 1);
                }
            } catch(_) {
                spawnedGoopObjects.splice(i, 1);
            }
        }
        for (let i = spazMachineEntries.length - 1; i >= 0; i--) {
            try {
                const entry = spazMachineEntries[i];
                if (!entry || !entry.object || entry.object.isNull?.()) {
                    spazMachineEntries.splice(i, 1);
                    continue;
                }
                if (time >= entry.expireAt) {
                    try {
                        const pos = getTransform(entry.object).method("get_position").invoke();
                        playSelectedVfxAt(pos);
                    } catch(_) {}
                    try {
                        const runner = entry.object.method("get_Runner").invoke();
                        if (runner && !runner.isNull?.()) runner.method("Despawn").invoke(entry.object);
                    } catch(_) {}
                    try {
                        let go = entry.object;
                        try {
                            const maybeGo = entry.object.method("get_gameObject").invoke();
                            if (maybeGo && !maybeGo.isNull?.()) go = maybeGo;
                        } catch(_) {}
                        Destroy(go);
                    } catch(_) {}
                    spazMachineEntries.splice(i, 1);
                }
            } catch(_) {
                spazMachineEntries.splice(i, 1);
            }
        }
        for (let i = itemTornadoEntries.length - 1; i >= 0; i--) {
            try {
                const entry = itemTornadoEntries[i];
                if (!entry || !entry.object || entry.object.isNull?.()) itemTornadoEntries.splice(i, 1);
            } catch(_) {
                itemTornadoEntries.splice(i, 1);
            }
        }
        cleanupDeadTrackedObjects(spawnedNetworkPrefabs);
        cleanupDeadTrackedObjects(spawnedPersistentMobs);
        if (mobForceStayEnabled) {
            for (const mob of spawnedPersistentMobs) {
                try {
                    stabilizeMobInstance(mob);
                } catch(_) {}
            }
            for (const entry of persistentMobEntries) {
                try {
                    if (!entry) continue;
                    const obj = entry.object;
                    let alive = false;
                    try {
                        if (obj && !obj.isNull?.()) {
                            const go = obj.method("get_gameObject").invoke();
                            alive = !!go && !go.isNull?.();
                            if (alive) {
                                try { go.method("SetActive").invoke(true); } catch(_) {}
                                continue;
                            }
                        }
                    } catch(_) {}
                    if (!alive && time > ((entry.lastRespawnTime ?? 0) + 1.0)) {
                        entry.lastRespawnTime = time;
                        let respawned = null;
                        try {
                            if (!mobSpawnAsyncBroken) {
                                respawned = PrefabGen.method("SpawnMobAsyncInternal", 6).invoke(
                                    entry.mobEntry.id, entry.pos, entry.rot, NULL, NULL, Il2Cpp.string("menu")
                                );
                            }
                        } catch(_) {
                            mobSpawnAsyncBroken = true;
                        }
                        if ((!respawned || respawned.isNull?.()) && entry.mobEntry?.name) {
                            try {
                                const fallbackNames = [
                                    entry.mobEntry.name,
                                    "Mob" + entry.mobEntry.name,
                                    entry.mobEntry.name + "Mob",
                                    entry.mobEntry.name + "Controller"
                                ];
                                for (const prefabName of fallbackNames) {
                                    respawned = spawnNetworkPrefab(prefabName, entry.pos, entry.rot);
                                    if (respawned && !respawned.isNull?.()) break;
                                }
                            } catch(_) {}
                        }
                        if (respawned && !respawned.isNull?.()) {
                            stabilizeMobInstance(respawned, entry.pos);
                            entry.object = respawned;
                            spawnedPersistentMobs.push(respawned);
                        }
                    }
                } catch(_) {}
            }
        }

        updateInput();
        frameCount++;
        if (forceDevModeEnabled) tryForceDeveloperMode();
        if (forceAllStashSlotsEnabled) forceGrantAllStashSlots();
        if (containerFreedomAuraEnabled) applyContainerFreedomSweep();

        if ((righthand && rightSecondary) || (!righthand && leftSecondary)) {
            if (currentNotification != "" && time > notifactionResetTime) reloadMenu();
            if (menu == null) renderMenu();
            else recenterMenu();
        } else {
            if (menu != null) { Destroy(menu); menu = null; }
        }

        if (menu == null) {
            if (reference != null) { Destroy(reference); reference = null; }
        } else {
            if (reference == null) renderReference();
        }

        try {
            if (GunPointer != null) {
                if (!GunPointer.method("get_activeSelf").invoke()) { Destroy(GunPointer); GunPointer = null; }
                else GunPointer.method("SetActive").invoke(false);
            }
            let lineObj = GunLine.method("get_gameObject").invoke();
            if (lineObj != null) {
                if (!lineObj.method("get_activeSelf").invoke()) { Destroy(lineObj); GunLine = null; }
                else lineObj.method("SetActive").invoke(false);
            }
        } catch { }

        buttons.flat().filter(b => b.enabled).forEach(b => {
            if (b.method) {
                try {
                    b.method();
                    (b as any).__failCount = 0;
                    (b as any).__nextErrorLogTime = 0;
                }
                catch (e) {
                    logButtonRuntimeError(b, e);
                }
            }
        });

        prevLeftGrab = leftGrab;
        prevRightGrab = rightGrab;

        return LateUpdate.invoke();
        } catch(e) {
            try { return LateUpdate.invoke(); } catch(_) {}
        }
    };
    
    function installLogcat() {
        try {
            const PCClass2 = AssemblyCSharp.class("AnimalCompany.PlayerController");
            const playerDieMethod = PCClass2.method("PlayerDie");
            playerDieMethod.implementation = function(killSound, hitName, fromKillTrigger) {
                try { console.log("[LOGCAT] PlayerDie hitName=" + (hitName?.content ?? "?")); } catch(_) {}
                return invokeInstance(playerDieMethod, this, killSound, hitName, fromKillTrigger);
            };
        } catch(e) { console.error("[LOGCAT] PlayerDie:", e); }
        console.log("[LOGCAT] installed");
    }
    installLogcat();

    
    
    function quiverHook() {
        let _inAddToBagAck = false;

        
        try { GBIClass.method("get_canAddToBag").implementation          = function() { return true; }; } catch(e) {}
        try { GBIClass.method("get_allowAddToBag").implementation        = function() { return true; }; } catch(e) {}
        try { GBIClass.method("get_allowAttachToItem").implementation    = function() { return true; }; } catch(e) {}
        try { GBIClass.method("get_allowAddToQuiver").implementation     = function() { return true; }; } catch(e) {}
        try { GBIClass.method("CanBeAddedToContainer").implementation    = function(_: any) { return true; }; } catch(_) {}
        try { GBIClass.method("get_isContainable").implementation        = function() { return true; }; } catch(_) {}
        try { GBIClass.method("get_canBePickedUp").implementation        = function() { return true; }; } catch(_) {}

        
        
        try {
            const GISClass = AssemblyCSharp.class("AnimalCompany.GameplayItemState");

            function _isBagLike(self: any): boolean {
                try {
                    const idObj = self.method("get_id").invoke();
                    if (!idObj || idObj.isNull()) return false;
                    const id: string = idObj.content ?? "";
                    return (
                        id.indexOf("stash")            !== -1 ||
                        id.indexOf("quiver")           !== -1 ||
                        id.indexOf("crossbow")         !== -1 ||
                        id.indexOf("heart_gun")        !== -1 ||
                        id.indexOf("grenade_launcher") !== -1 ||
                        id.indexOf("salmoncannon")     !== -1 ||
                        id.indexOf("salmon_cannon")    !== -1
                    );
                } catch(_) { return false; }
            }

            try {
                const _isBagOrig = GISClass.method("get_isBag");
                GISClass.method("get_isBag").implementation = function() {
                    if (_isBagLike(this)) return true;
                    return invokeInstance(_isBagOrig, this);
                };
            } catch(_) {}

            try {
                const _baseCapOrig = GISClass.method("get_baseCapacity");
                GISClass.method("get_baseCapacity").implementation = function() {
                    if (_isBagLike(this)) {
                        try {
                            const sp = invokeInstance(_baseCapOrig, this);
                            if (sp && !sp.isNull()) {
                                try { sp.field("_value").value = 9999; } catch(_) {}
                                try { sp.field("value").value  = 9999; } catch(_) {}
                            }
                            return sp;
                        } catch(_) {}
                    }
                    return invokeInstance(_baseCapOrig, this);
                };
            } catch(_) {}

            try {
                const _totCapOrig = GISClass.method("get_totalCurrCapacity");
                GISClass.method("get_totalCurrCapacity").implementation = function() {
                    if (_isBagLike(this)) return 9999;
                    return invokeInstance(_totCapOrig, this);
                };
            } catch(_) {}

            try { GISClass.method("get_allowAddToQuiver").implementation  = function() { return true; }; } catch(_) {}
            try { GISClass.method("get_allowAddToBag").implementation     = function() { return true; }; } catch(_) {}
            try { GISClass.method("get_allowAttachToItem").implementation = function() { return true; }; } catch(_) {}
            try { GISClass.method("get_allowAttachToBack").implementation = function() { return true; }; } catch(_) {}
            try { GISClass.method("get_allowAttachToHip").implementation  = function() { return true; }; } catch(_) {}
            try { GISClass.method("get_isBackpack").implementation        = function() { return true; }; } catch(_) {}
            try { GISClass.method("get_containerCapacity").implementation    = function() { return 9999; }; } catch(_) {}
            try { GISClass.method("get_maxContainerCapacity").implementation = function() { return 9999; }; } catch(_) {}
        } catch(_) {}

        
        try { BackpackItemClass.method("CheckToAddItem").implementation = function(_: any) { return true; }; } catch(e) { console.error("[quiverHook] BackpackItem.CheckToAddItem:", e); }
        try { BackpackItemClass.method("get_capacity").implementation      = function() { return 9999; }; } catch(e) {}
        try { BackpackItemClass.method("set_capacity").implementation      = function(_v: any) {};        } catch(e) {}
        try { BackpackItemClass.method("get_isFull").implementation        = function() { return false; }; } catch(e) {}
        try { BackpackItemClass.method("get_baseCapacity").implementation  = function() { return 9999; }; } catch(_) {}
        
        try {
            const backpackHandleAddItemTrigger = tryMethodName(BackpackItemClass, ["HandleAddItemTrigger"]);
            if (backpackHandleAddItemTrigger) backpackHandleAddItemTrigger.implementation = function(collider: any) {
                try { this.method("set_isOpen").invoke(true); } catch(_) {}
                return invokeInstance(backpackHandleAddItemTrigger, this, collider);
            };
        } catch(_) {}
        try {
            const backpackCheckToEmptyItem = tryMethodName(BackpackItemClass, ["CheckToEmptyItem"]);
            if (backpackCheckToEmptyItem) backpackCheckToEmptyItem.implementation = function() {
                return invokeInstance(backpackCheckToEmptyItem, this);
            };
        } catch(_) {}
        try {
            const backpackAddToBagAck = tryMethodName(BackpackItemClass, ["AddToBagAck"]);
            if (backpackAddToBagAck) backpackAddToBagAck.implementation = function(obj: any) {
                if (_inAddToBagAck) return true;
                _inAddToBagAck = true;
                try {
                    try { this.field("_capacity").value = 9999; } catch(_) {}
                    try { this.field("capacity").value  = 9999; } catch(_) {}
                    try { this.method("set_capacity").invoke(255); } catch(_) {}
                    try { this.method("set_isOpen").invoke(true); } catch(_) {}
                    return invokeInstance(backpackAddToBagAck, this, obj);
                } catch(_) { return true; } finally { _inAddToBagAck = false; }
            };
        } catch(_) {}

        
        try {
            QuiverClass.method("CheckToAddItem").implementation = function(item: any) {
                try {
                    
                    const asQuiver = item.method("GetComponent", 1).inflate(QuiverClass).invoke();
                    if (asQuiver && !asQuiver.isNull()) return false;
                } catch(_) {}
                return true;
            };
        } catch(e) { console.error("[quiverHook] Quiver.CheckToAddItem:", e); }
        try { QuiverClass.method("CanAddItem").implementation     = function(item: any) {
            try {
                const asQuiver = item.method("GetComponent", 1).inflate(QuiverClass).invoke();
                if (asQuiver && !asQuiver.isNull()) return false;
            } catch(_) {}
            return true;
        }; } catch(_) {}
        try { QuiverClass.method("get_capacity").implementation            = function() { return 9999; }; } catch(e) {}
        try { QuiverClass.method("get_isFull").implementation              = function() { return false; }; } catch(_) {}
        try { QuiverClass.method("get_baseCapacity").implementation        = function() { return 9999; }; } catch(_) {}
        try {
            const quiverAddToBagAck = tryMethodName(QuiverClass, ["AddToBagAck"]);
            if (quiverAddToBagAck) quiverAddToBagAck.implementation = function(obj: any) {
                if (_inAddToBagAck) return true;
                _inAddToBagAck = true;
                try {
                    try { this.field("_capacity").value = 9999; } catch(_) {}
                    try { this.field("capacity").value  = 9999; } catch(_) {}
                    try { this.method("set_capacity").invoke(255); } catch(_) {}
                    return invokeInstance(quiverAddToBagAck, this, obj);
                } catch(_) { return true; } finally { _inAddToBagAck = false; }
            };
        } catch(_) {}
        try { QuiverClass.method("HandleTryToDrop").implementation = function(_: any) { return true; }; } catch(e) { console.error("[quiverHook] Quiver.HandleTryToDrop:", e); }

        
        if (CrossbowClass) {
            try { CrossbowClass.method("CheckToAddItem").implementation = function(_: any) { return true; }; } catch(_) {}
            try { CrossbowClass.method("CanAddItem").implementation     = function(_: any) { return true; }; } catch(_) {}
            try { CrossbowClass.method("get_allowAddToBag").implementation = function() { return true; }; } catch(_) {}
            try { CrossbowClass.method("get_allowAddToQuiver").implementation = function() { return true; }; } catch(_) {}
            try { CrossbowClass.method("get_allowAttachToItem").implementation = function() { return true; }; } catch(_) {}
            try { CrossbowClass.method("get_allowAttachToBack").implementation = function() { return true; }; } catch(_) {}
            try { CrossbowClass.method("get_allowAttachToHip").implementation = function() { return true; }; } catch(_) {}
            try { CrossbowClass.method("get_isBackpack").implementation = function() { return true; }; } catch(_) {}
            try { CrossbowClass.method("get_capacity").implementation      = function() { return 9999; }; } catch(_) {}
            try { CrossbowClass.method("get_baseCapacity").implementation  = function() { return 9999; }; } catch(_) {}
            try { CrossbowClass.method("get_isFull").implementation        = function() { return false; }; } catch(_) {}
            try {
                const crossbowAddToBagAck = tryMethodName(CrossbowClass, ["AddToBagAck"]);
                if (crossbowAddToBagAck) crossbowAddToBagAck.implementation = function(obj: any) {
                    if (_inAddToBagAck) return true;
                    _inAddToBagAck = true;
                    try {
                        try { this.field("_capacity").value = 9999; } catch(_) {}
                        try { this.method("set_capacity").invoke(255); } catch(_) {}
                        return invokeInstance(crossbowAddToBagAck, this, obj);
                    } catch(_) { return true; } finally { _inAddToBagAck = false; }
                };
            } catch(_) {}
        }

        
        if (HeartGunClass) {
            try { HeartGunClass.method("CheckToAddItem").implementation = function(_: any) { return true; }; } catch(_) {}
            try { HeartGunClass.method("CanAddItem").implementation     = function(_: any) { return true; }; } catch(_) {}
            try { HeartGunClass.method("get_capacity").implementation      = function() { return 9999; }; } catch(_) {}
            try { HeartGunClass.method("get_baseCapacity").implementation  = function() { return 9999; }; } catch(_) {}
            try { HeartGunClass.method("get_isFull").implementation        = function() { return false; }; } catch(_) {}
            try { HeartGunClass.method("get_isBackpack").implementation    = function() { return true; }; } catch(_) {}
            try {
                const heartGunAddToBagAck = tryMethodName(HeartGunClass, ["AddToBagAck"]);
                if (heartGunAddToBagAck) heartGunAddToBagAck.implementation = function(obj: any) {
                    if (_inAddToBagAck) return true;
                    _inAddToBagAck = true;
                    try {
                        try { this.field("_capacity").value = 9999; } catch(_) {}
                        try { this.method("set_capacity").invoke(255); } catch(_) {}
                        return invokeInstance(heartGunAddToBagAck, this, obj);
                    } catch(_) { return true; } finally { _inAddToBagAck = false; }
                };
            } catch(_) {}
        }

        
        if (GrenadeLauncherClass) {
            try { GrenadeLauncherClass.method("CheckToAddItem").implementation = function(_: any) { return true; }; } catch(_) {}
            try { GrenadeLauncherClass.method("get_capacity").implementation      = function() { return 9999; }; } catch(_) {}
            try { GrenadeLauncherClass.method("set_capacity").implementation      = function(_v: any) {}; } catch(_) {}
            try { GrenadeLauncherClass.method("get_cappedCapacity").implementation = function() { return 9999; }; } catch(_) {}
        }

        
        
        
        

        console.log("[quiverHook] v5 — bags openable, grenade/salmon as bags, no quiver-in-quiver");
    }
    quiverHook();

   function ArenaItemKilla() {
   const MyHook = AssemblyCSharp.class("AnimalCompany.ArenaItemKiller").method("DespawnIfNecessary");
   MyHook.implementation = function () { return; };
}
const infflareammo = AssemblyCSharp.class("AnimalCompany.FlareGun").method("get_hasAmmo");
infflareammo.implementation = function () {
    if (InfAmmo || rapidFireEnabled) return true;
    return invokeInstance(infflareammo, this);
};
const infrevolverammo = AssemblyCSharp.class("AnimalCompany.Revolver").method("get_ammoLoaded");
infrevolverammo.implementation = function () {
    if (InfAmmo || rapidFireEnabled) return 255;
    return invokeInstance(infrevolverammo, this);
};
const infrevolverammo2 = AssemblyCSharp.class("AnimalCompany.Revolver").method("get_isHammerCocked");
infrevolverammo2.implementation = function () {
    if (InfAmmo || rapidFireEnabled) return true;
    return invokeInstance(infrevolverammo2, this);
};
const ziplineinfammo = AssemblyCSharp.class("AnimalCompany.ZiplineGun").method("get_isLoaded");
ziplineinfammo.implementation = function () {
    if (InfAmmo || rapidFireEnabled) return true;
    return invokeInstance(ziplineinfammo, this);
};
const shotguninfammo = AssemblyCSharp.class("AnimalCompany.Shotgun").method("get__ammoLeft");
shotguninfammo.implementation = function () {
    if (InfAmmo || rapidFireEnabled) return 255;
    return invokeInstance(shotguninfammo, this);
};
const rpginfammo = AssemblyCSharp.class("AnimalCompany.RPG").method("get_loadedState");
rpginfammo.implementation = function () {
    const state = invokeInstance(rpginfammo, this);
    if (InfAmmo || rapidFireEnabled) {
        state.field("isLoaded").value = true;
        try { this.method("set_loadedState").invoke(state); } catch(_) {}
    }
    return state;
};
const arenagunsinfammo = AssemblyCSharp.class("AnimalCompany.AutoReloadGun").method("get__ammoLeft");
arenagunsinfammo.implementation = function () {
    if (InfAmmo || rapidFireEnabled) return 255;
    return invokeInstance(arenagunsinfammo, this);
};
    const InfJetpack = AssemblyCSharp.class("AnimalCompany.JetpackHandy").method("RPC_UseJetpack");
    InfJetpack.implementation = function() {
      if (InfAmmo) {
        invokeInstance(InfJetpack, this);
        this.field("_isUsed").value = false;
      } else {
        return invokeInstance(InfJetpack, this);
      }
    };
const EjectItem = AssemblyCSharp.class("AnimalCompany.StashMachine.StashMachineTrashChuteView").method("EjectItem");
EjectItem.implementation = function(item) {
    if (stashDupeEnabled) {
        for (let i = 0; i < ejectDupeAmount; i++) {
            invokeInstance(EjectItem, this, item);
        }
    } else {
        return invokeInstance(EjectItem, this, item);
    }
};

try {
    const GunClass = AssemblyCSharp.class("AnimalCompany.Gun");
    const gunShootHook = GunClass.method("Shoot");
    gunShootHook.implementation = function() {
        if (noRecoil || infDamage) {
            try {
                const cfg = this.method("get_config").invoke();
                if (cfg && !cfg.isNull()) {
                    
                    const origRecoil     = cfg.field("recoilForceMag").value as number;
                    const origHandRecoil = cfg.field("handRecoilForceMag").value as number;
                    const origSpread     = cfg.field("shotSpread").value as number;
                    let origDmg: number | null = null;
                    
                    if (noRecoil) {
                        cfg.field("recoilForceMag").value     = 0.0;
                        cfg.field("handRecoilForceMag").value = 0.0;
                        cfg.field("shotSpread").value         = 0.0;
                    }
                    
                    if (infDamage) {
                        try { origDmg = cfg.field("damage").value as number; cfg.field("damage").value = 999999.0; } catch(_) {}
                        try { cfg.field("bulletDamage").value = 2147483648.0; } catch(_) {}
                        try { cfg.field("damagePerBullet").value = 2147483648.0; } catch(_) {}
                        try { cfg.field("hitDamage").value = 2147483648.0; } catch(_) {}
                    }
                    const result = invokeInstance(gunShootHook, this);
                    
                    if (noRecoil) {
                        cfg.field("recoilForceMag").value     = origRecoil;
                        cfg.field("handRecoilForceMag").value = origHandRecoil;
                        cfg.field("shotSpread").value         = origSpread;
                    }
                    if (infDamage) {
                        try { if (origDmg !== null) cfg.field("damage").value = origDmg; } catch(_) {}
                        try { cfg.field("bulletDamage").value = 1.0; } catch(_) {}
                        try { cfg.field("damagePerBullet").value = 1.0; } catch(_) {}
                        try { cfg.field("hitDamage").value = 1.0; } catch(_) {}
                    }
                    return result;
                }
            } catch(_) {}
        }
        return invokeInstance(gunShootHook, this);
    };
} catch(e) { console.error("[Gun.Shoot hook failed]:", e); }

try {
    const gbiHandleHit = GBIClass.method("HandleHit");
    gbiHandleHit.implementation = function(other: any, velocity: any) {
        if (infDamage) {
            try {
                const origDmg = this.field("_hitDamage").value as number;
                this.field("_hitDamage").value = 999999.0;
                const result = invokeInstance(gbiHandleHit, this, other, velocity);
                this.field("_hitDamage").value = origDmg;
                return result;
            } catch(_) {}
        }
        return invokeInstance(gbiHandleHit, this, other, velocity);
    };
} catch(_) {} 

try {
    const UserStateClass = AssemblyCSharp.class("AnimalCompany.UserState");
    const userStateGetIsDeveloper = UserStateClass.method("get_isDeveloper");
    userStateGetIsDeveloper.implementation = function() {
        if (!isClassNamed(this, "UserState")) {
            try { return invokeInstance(userStateGetIsDeveloper, this); } catch(_) { return false; }
        }
        const sp = invokeInstance(userStateGetIsDeveloper, this);
        try { if (sp && !sp.isNull()) sp.method("set_value").invoke(true); } catch(_) {}
        try { if (sp && !sp.isNull()) sp.field("_value").value = true; } catch(_) {}
        try { if (sp && !sp.isNull()) sp.field("value").value  = true; } catch(_) {}
        return sp;
    };
    console.log("[DevHook] UserState.get_isDeveloper hooked — always returns true");
} catch(e) { console.error("[DevHook] UserState.get_isDeveloper hook failed:", e); }

try {
    const GISClass2 = AssemblyCSharp.class("AnimalCompany.GameplayItemState");
    
    try {
        GISClass2.method("get_allowBlueprintSaving").implementation = function() { return true; };
    } catch(_) {}
    
    try {
        GISClass2.method("get_maxInBlueprint").implementation = function() { return 9999; };
    } catch(_) {}
    
    try {
        GISClass2.method("get_isPurchasable").implementation = function() { return true; };
    } catch(_) {}
    
    try {
        GISClass2.method("get_isResearchable").implementation = function() { return true; };
    } catch(_) {}
    
    try {
        GISClass2.method("get_canBeSavedToLoadoutTemplate").implementation = function() { return true; };
    } catch(_) {}
    console.log("[Blueprint] GameplayItemState hooks installed — all items blueprintable");
} catch(e) { console.error("[Blueprint] hook failed:", e); }

try {
    const ShotgunClass = AssemblyCSharp.class("AnimalCompany.Shotgun");
    const shotgunUpdateReload = tryMethodName(ShotgunClass, ["UpdateReload", "ReloadUpdate"]);
    if (shotgunUpdateReload) shotgunUpdateReload.implementation = function() {
        if (noShotgunCooldown) {
            try { this.field("_reloadTimer").value = 0.0; } catch(_) {}
        }
        return invokeInstance(shotgunUpdateReload, this);
    };
} catch(_) {}

try {
    const ShotgunClass2 = AssemblyCSharp.class("AnimalCompany.Shotgun");
    const shotgunHandleUse = ShotgunClass2.method("HandleUse");
    shotgunHandleUse.implementation = function() {
        if (noShotgunCooldown) {
            try { this.field("_reloadTimer").value = 0.0; } catch(_) {}
        }
        return invokeInstance(shotgunHandleUse, this);
    };
} catch(e) { console.error("[NoShotgunCooldown] Shotgun.HandleUse hook failed:", e); }
function installMultiBuyHookOnClass(klass: any, methodNames: string[]) {
    if (!klass) return;
    const spawnExtraPurchaseCopiesFromResult = (result: any, loops: number) => {
        try {
            if (!result || result.isNull?.() || loops <= 1) return;
            const rootGo = getRootLikeObject(result);
            if (!rootGo || rootGo.isNull?.()) return;
            const itemId = getGrabbableItemId(result) || getGrabbableItemId(rootGo);
            if (!itemId) return;
            const basePos = getTransform(rootGo).method("get_position").invoke();
            const baseRot = getTransform(rootGo).method("get_rotation").invoke();
            for (let i = 1; i < loops; i++) {
                try {
                    const extraPos = [
                        (basePos.field("x").value as number) + ((i % 3) * 0.14),
                        (basePos.field("y").value as number) + 0.04 + (i * 0.01),
                        (basePos.field("z").value as number) + (Math.floor(i / 3) * 0.14)
                    ];
                    const extra = spawnItemAtPos(itemId, extraPos, baseRot);
                    if (!extra || extra.isNull?.()) continue;
                    trySetObjectVelocity(extra, [0, 0.2 + (i * 0.03), 0]);
                } catch(_) {}
            }
        } catch(_) {}
    };
    for (const methodName of methodNames) {
        try {
            const method = tryMethodName(klass, [methodName]);
            if (!method) continue;
            method.implementation = function(...args: any[]) {
                if (!multiBuyEnabled || multiBuyAmount <= 1 || multiBuyHookGuard) {
                    return invokeInstance(method, this, ...args);
                }
                multiBuyHookGuard = true;
                let result: any = null;
                try {
                    try { this.field("_lastBuyCheck").value = 0.0; } catch(_) {}
                    try { this.field("_switchToBuyViewDelay").value = 0.0; } catch(_) {}
                    try { this.field("_hasReachedPurchaseThreshold").value = false; } catch(_) {}
                    try { this.field("_isPurchaseLimited").value = false; } catch(_) {}
                    try { this.field("_useCooldownPurchase").value = false; } catch(_) {}
                    const loops = Math.max(1, Math.min(50, multiBuyAmount));
                    for (let i = 0; i < loops; i++) {
                        try { result = invokeInstance(method, this, ...args); } catch(_) {}
                        try { this.field("_lastBuyCheck").value = 0.0; } catch(_) {}
                        try { this.field("_switchToBuyViewDelay").value = 0.0; } catch(_) {}
                        try { this.field("_hasReachedPurchaseThreshold").value = false; } catch(_) {}
                        try { this.field("_isPurchaseLimited").value = false; } catch(_) {}
                        tryCallNames(this, ["TryPurchase", "TriggerPurchase", "HandlePurchase", "HandleBuyGameplayItem", "HandleBuyGameplayItemToBackpack"], 0);
                        tryCallNames(this, ["TryToBuy", "TryToBuyToBackpack"], 0);
                    }
                    try { spawnExtraPurchaseCopiesFromResult(result, loops); } catch(_) {}
                } finally {
                    multiBuyHookGuard = false;
                }
                return result;
            };
            console.log("[MultiBuy] hooked " + klass.type.name + "." + methodName);
        } catch(_) {}
    }
}
try {
    installMultiBuyHookOnClass(ItemSellingMachineButtonViewClass, [
        "HandlePurchaseButtonActivated", "TryToBuy", "TryToBuyToBackpack", "TryPurchase", "TriggerPurchase", "PurchaseCallback"
    ]);
    installMultiBuyHookOnClass(ItemSellingMachineController, [
        "HandlePurchaseRequested", "HandleBuyGameplayItem", "HandleBuyGameplayItemToBackpack", "HandlePurchase", "TryPurchase", "TryToBuy", "PurchaseCallback"
    ]);
    installMultiBuyHookOnClass(GrabbablePurchaseClass, ["HandlePurchase", "TryToBuy", "TryPurchase", "PurchaseCallback"]);
    installMultiBuyHookOnClass(ArenaGrabbablePurchaseClass, ["HandlePurchase", "TryToBuy", "TryPurchase", "TestBuy", "PurchaseCallback"]);
} catch(e) { console.error("[MultiBuy] hook setup failed:", e); }
function blockrpc() {
    
    function isMine(self) {
        try { return self.method("get_IsMine").invoke(); } catch(_) { return false; }
    }
    
    function shouldBlock(self) {
        return isMine(self) && !_selfRPCBypass;
    }

    const NetPlayerCls = AssemblyCSharp.class("AnimalCompany.NetPlayer");

    
    try {
        NetPlayerCls.method("RPC_AddForce").implementation = function(force) {
            if (shouldBlock(this)) return;
            return this.method("RPC_AddForce").invoke(force);
        };
    } catch(e) { console.error("[blockrpc] RPC_AddForce:", e); }

    
    try {
        NetPlayerCls.method("RPC_Teleport").implementation = function(position) {
            if (shouldBlock(this)) return;
            try {
                if (this.method("get_IsMine").invoke()) {
                    const x = position.field("x").value.toFixed(2);
                    const y = position.field("y").value.toFixed(2);
                    const z = position.field("z").value.toFixed(2);
                    console.log("[LOGCAT] Teleport (" + x + "," + y + "," + z + ")");
                }
            } catch(_) {}
            return this.method("RPC_Teleport").invoke(position);
        };
    } catch(e) { console.error("[blockrpc] RPC_Teleport:", e); }

    
    try {
        NetPlayerCls.method("RPC_PlayerStun").implementation = function(position, stunRange, duration, attenType) {
            if (shouldBlock(this)) return;
            return this.method("RPC_PlayerStun").invoke(position, stunRange, duration, attenType);
        };
    } catch(e) { console.error("[blockrpc] RPC_PlayerStun:", e); }

    
    try {
        NetPlayerCls.method("RPC_PlayerHit", 3).implementation = function(damage, position, dmgInfo) {
            if (shouldBlock(this)) return;
            return this.method("RPC_PlayerHit", 3).invoke(damage, position, dmgInfo);
        };
    } catch(e) { console.error("[blockrpc] RPC_PlayerHit(3):", e); }

    
    try {
        NetPlayerCls.method("RPC_PlayerHit", 5).implementation = function(damage, position, force, dmgInfo, isDeathHit) {
            if (shouldBlock(this)) return;
            return this.method("RPC_PlayerHit", 5).invoke(damage, position, force, dmgInfo, isDeathHit);
        };
    } catch(e) { console.error("[blockrpc] RPC_PlayerHit(5):", e); }

    
    try {
        NetPlayerCls.method("RPC_DoPlayerDie").implementation = function(isDead) {
            if (shouldBlock(this)) return;
            return this.method("RPC_DoPlayerDie").invoke(isDead);
        };
    } catch(e) { console.error("[blockrpc] RPC_DoPlayerDie:", e); }

    
    try {
        NetPlayerCls.method("RPC_TagAsStinky").implementation = function() {
            if (shouldBlock(this)) return;
            return this.method("RPC_TagAsStinky").invoke();
        };
    } catch(e) { console.error("[blockrpc] RPC_TagAsStinky:", e); }

    
    try {
        NetPlayerCls.method("RPC_SetColorHSV").implementation = function(duration, hue, saturation, brightness) {
            if (shouldBlock(this)) return;
            return this.method("RPC_SetColorHSV").invoke(duration, hue, saturation, brightness);
        };
    } catch(e) { console.error("[blockrpc] RPC_SetColorHSV:", e); }

    
    try {
        NetPlayerCls.method("RPC_ApplyBuff").implementation = function(buffID) {
            if (shouldBlock(this)) return;
            return this.method("RPC_ApplyBuff").invoke(buffID);
        };
    } catch(e) { console.error("[blockrpc] RPC_ApplyBuff:", e); }

    
    try {
        NetPlayerCls.method("RPC_SetTeam").implementation = function(team) {
            if (shouldBlock(this)) return;
            return this.method("RPC_SetTeam").invoke(team);
        };
    } catch(e) { console.error("[blockrpc] RPC_SetTeam:", e); }

    
    try {
        NetPlayerCls.method("RPC_SetHide").implementation = function(hide) {
            if (shouldBlock(this)) return;
            return this.method("RPC_SetHide").invoke(hide);
        };
    } catch(e) { console.error("[blockrpc] RPC_SetHide:", e); }

    
    try {
        NetPlayerCls.method("RPC_AddPlayerMoney").implementation = function(amount) {
            if (shouldBlock(this)) return;
            return this.method("RPC_AddPlayerMoney").invoke(amount);
        };
    } catch(e) { console.error("[blockrpc] RPC_AddPlayerMoney:", e); }

    
    try {
        NetPlayerCls.method("RPC_AttachToGiantHand").implementation = function(attach, giant, moveImmediate, offset) {
            if (shouldBlock(this)) return;
            return this.method("RPC_AttachToGiantHand").invoke(attach, giant, moveImmediate, offset);
        };
    } catch(e) { console.error("[blockrpc] RPC_AttachToGiantHand:", e); }

    
    try {
        NetPlayerCls.method("RPC_AwardKill").implementation = function() {
            if (shouldBlock(this)) return;
            return this.method("RPC_AwardKill").invoke();
        };
    } catch(e) { console.error("[blockrpc] RPC_AwardKill:", e); }

    console.log("[blockrpc] installed - blocking all 14 hostile RPCs on self, self-RPCs allowed via bypass");
}

 ArenaItemKilla();
 blockrpc();

let infHealthEnabled = false;
const infHealthHook = NetPlayer.method("get_maxHealth");
infHealthHook.implementation = function() {
    if (infHealthEnabled && this.method("get_IsMine").invoke()) return 999999;
    return this.method("get_maxHealth").invoke();
};

const MiningLaserClass = AssemblyCSharp.class("AnimalCompany.MiningLaser");

try {
    const miningLaserFuel = tryMethodName(MiningLaserClass, ["get__fuel", "get_fuel"]);
    if (miningLaserFuel) miningLaserFuel.implementation = function() {
        try { this.field("_maxDistance").value = 9999.0; } catch(_) {}
        return this.field("_maxFuel").value;
    };
} catch(_) {}

try {
    const miningLaserOverheat = tryMethodName(MiningLaserClass, ["get__didOverheat", "get_didOverheat"]);
    if (miningLaserOverheat) miningLaserOverheat.implementation = function() {
        return false;
    };
} catch(_) {}

try {
    const miningLaserFuelConsumption = tryMethodName(MiningLaserClass, ["ProcessFuelConsumption"]);
    if (miningLaserFuelConsumption) miningLaserFuelConsumption.implementation = function() {
    };
} catch(_) {}

try {
        const AntiCheatClass = AssemblyCSharp.class("AnimalCompany.AntiCheatSystem");
        const antiCheatTick = tryMethodName(AntiCheatClass, ["Update", "LateUpdate", "FixedUpdate"]);
        if (antiCheatTick) antiCheatTick.implementation = function() {
        };
        console.log("[VPN] AntiCheatSystem.Update hooked — VPN detection disabled");
    } catch(e) { console.error("[VPN] AntiCheatSystem.Update hook failed:", e); }

    try {
        const AppStateClass = AssemblyCSharp.class("AnimalCompany.AppState");
        const appStateGetIsVPNActive = AppStateClass.method("get_isVPNActive");
        appStateGetIsVPNActive.implementation = function() {
            if (!isClassNamed(this, "AppState")) {
                try { return invokeInstance(appStateGetIsVPNActive, this); } catch(_) { return false; }
            }
            const sp = invokeInstance(appStateGetIsVPNActive, this);
            if (sp && !sp.isNull()) {
                try { sp.method("set_value").invoke(false); } catch(_) {}
                try { sp.field("_value").value = false; } catch(_) {}
                try { sp.field("value").value  = false; } catch(_) {}
            }
            return sp;
        };
        console.log("[VPN] AppState.get_isVPNActive hooked — always returns false");
    } catch(e) { console.error("[VPN] AppState.get_isVPNActive hook failed:", e); }

    try {
        const GameplayFishConfigClass = Il2Cpp.domain.assembly("AnimalCompany").image
            .class("AnimalCompany.Fishing.GameplayFishConfig");

        try {
            GameplayFishConfigClass.method("GetRandomFishSize").implementation = function() {
                return 127; 
            };
        } catch(e) { console.error("[G2] GetRandomFishSize:", e); }

        try {
            GameplayFishConfigClass.method("GetPriceByScaleModifier").implementation = function(basePrice: any, scaleModifier: any) {
                return this.method("GetPriceByScaleModifier").invoke(basePrice, 127);
            };
        } catch(e) { console.error("[G2] GetPriceByScaleModifier:", e); }

        console.log("[G2] GameplayFishConfig hooks installed — max size always");
    } catch(e) { console.error("[G2] GameplayFishConfig hook failed:", e); }

    try {
        const FishingBobberViewClass = Il2Cpp.domain.assembly("AnimalCompany").image
            .class("AnimalCompany.Fishing.FishingBobberView");
        FishingBobberViewClass.method("RPC_GrantClaimItem").implementation = function(receivingPlayer: any, itemID: any, scaleModifier: any) {
            return this.method("RPC_GrantClaimItem").invoke(receivingPlayer, itemID, 127);
        };
        console.log("[G2] RPC_GrantClaimItem hooked — always spawns max-size fish");
    } catch(e) { console.error("[G2] RPC_GrantClaimItem hook failed:", e); }

    console.log([
        "================================================================",
        "  ██████╗ ██████╗     ███╗   ███╗███████╗███╗   ██╗██╗   ██╗",
        "  ██╔════╝╚════██╗    ████╗ ████║██╔════╝████╗  ██║██║   ██║",
        "  ██║  ███╗ █████╔╝   ██╔████╔██║█████╗  ██╔██╗ ██║██║   ██║",
        "  ██║   ██║██╔═══╝    ██║╚██╔╝██║██╔══╝  ██║╚██╗██║██║   ██║",
        "  ╚██████╔╝███████╗   ██║ ╚═╝ ██║███████╗██║ ╚████║╚██████╔╝",
        "   ╚═════╝ ╚══════╝   ╚═╝     ╚═╝╚══════╝╚═╝  ╚═══╝ ╚═════╝ ",
        " ",
        "  [G2] > SYSTEM LOADED // MATRIX ACTIVE",
        `  [G2] > version: ${version}`,
        "================================================================"
    ].join("\n"));

}); 
